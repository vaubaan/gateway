import { createRequire as __vaubaanCreateRequire } from 'node:module';
const require = __vaubaanCreateRequire(import.meta.url);

// ../../_temp/work/toolchain/packages/plugin-sdk/src/samples.ts
function samplesOn(resources, samples) {
  return Object.fromEntries(
    Object.entries(samples).map(([tool, calls]) => [
      tool,
      calls.map((call) => call.resources === void 0 ? { ...call, resources } : call)
    ])
  );
}

// ../../_temp/work/toolchain/packages/plugin-sdk/src/credential.ts
var TOKEN_PERMISSION_ACCESS = ["read", "read-write"];
var GUIDE_PATH_MAX_SEGMENTS = 8;
var GUIDE_PATH_SEGMENT_MAX_LENGTH = 40;
var GUIDE_SCREENSHOT_FILE_PATTERN = /^[a-z0-9][a-z0-9-]*\.(png|webp)$/;
var SCREENSHOT_LICENCES = ["CC-BY-4.0", "MIT", "Apache-2.0", "ours"];
var SCREENSHOT_TAKEN_PATTERN = /^\d{4}-(0[1-9]|1[0-2])$/;
var SCREENSHOT_ALT_MAX_LENGTH = 200;
var TOKEN_EXPIRY_KINDS = ["service-reports", "person-types", "none"];
var CREDENTIAL_ALTERNATIVES_MAX = 4;
var CREDENTIAL_ALTERNATIVE_ID_PATTERN = /^[a-z][a-z0-9-]{0,31}$/;
var BROKER_PROVIDER_PATTERN = /^[a-z][a-z0-9-]{0,31}$/;
var OAUTH2_REVOCATION_FORMATS = ["token-form", "client-credentials-json"];
var CredentialKindMismatch = class extends Error {
  constructor(pluginId, expected, actual) {
    super(`plugin '${pluginId}' expects a '${expected}' credential, got '${actual}'`);
    this.pluginId = pluginId;
    this.expected = expected;
    this.actual = actual;
    this.name = "CredentialKindMismatch";
  }
  pluginId;
  expected;
  actual;
};
function expectCredentialKind(pluginId, secret, kind) {
  if (secret.kind !== kind) throw new CredentialKindMismatch(pluginId, kind, secret.kind);
  return secret;
}

// ../../_temp/work/toolchain/packages/plugin-sdk/src/catalog-loader.ts
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";

// ../../_temp/work/toolchain/packages/plugin-sdk/node_modules/js-yaml/dist/js-yaml.mjs
var NOT_RESOLVED = /* @__PURE__ */ Symbol("NOT_RESOLVED");
function defineScalarTag(tagName, options) {
  return {
    tagName,
    nodeKind: "scalar",
    implicit: options.implicit ?? false,
    matchByTagPrefix: options.matchByTagPrefix ?? false,
    implicitFirstChars: options.implicitFirstChars ?? null,
    resolve: options.resolve,
    identify: options.identify,
    represent: options.represent ?? ((data) => String(data)),
    representTagName: options.representTagName ?? (() => tagName)
  };
}
function defineSequenceTag(tagName, options) {
  const carrierIsResult = options.finalize === void 0;
  return {
    tagName,
    nodeKind: "sequence",
    implicit: false,
    matchByTagPrefix: options.matchByTagPrefix ?? false,
    create: options.create,
    addItem: options.addItem,
    finalize: options.finalize ?? ((carrier) => carrier),
    carrierIsResult,
    identify: options.identify,
    represent: options.represent ?? ((data) => data),
    representTagName: options.representTagName ?? (() => tagName)
  };
}
function defineMappingTag(tagName, options) {
  const carrierIsResult = options.finalize === void 0;
  return {
    tagName,
    nodeKind: "mapping",
    implicit: false,
    matchByTagPrefix: options.matchByTagPrefix ?? false,
    create: options.create,
    addPair: options.addPair,
    has: options.has,
    keys: options.keys,
    get: options.get,
    finalize: options.finalize ?? ((carrier) => carrier),
    carrierIsResult,
    identify: options.identify,
    represent: options.represent ?? ((data) => data),
    representTagName: options.representTagName ?? (() => tagName)
  };
}
var strTag = defineScalarTag("tag:yaml.org,2002:str", {
  resolve: (source) => source,
  identify: (data) => typeof data === "string"
});
var NULL_VALUES$1 = [
  "",
  "~",
  "null",
  "Null",
  "NULL"
];
var nullCoreTag = defineScalarTag("tag:yaml.org,2002:null", {
  implicit: true,
  implicitFirstChars: [
    "",
    "~",
    "n",
    "N"
  ],
  resolve: (source) => {
    if (NULL_VALUES$1.indexOf(source) !== -1) return null;
    return NOT_RESOLVED;
  },
  identify: (object) => object === null,
  represent: () => "null"
});
var nullJsonTag = defineScalarTag("tag:yaml.org,2002:null", {
  implicit: true,
  implicitFirstChars: ["n"],
  resolve: (source, isExplicit) => {
    if (source === "null" || isExplicit && source === "") return null;
    return NOT_RESOLVED;
  },
  identify: (object) => object === null,
  represent: () => "null"
});
var NULL_VALUES = [
  "",
  "~",
  "null",
  "Null",
  "NULL"
];
var nullYaml11Tag = defineScalarTag("tag:yaml.org,2002:null", {
  implicit: true,
  implicitFirstChars: [
    "",
    "~",
    "n",
    "N"
  ],
  resolve: (source) => {
    if (NULL_VALUES.indexOf(source) !== -1) return null;
    return NOT_RESOLVED;
  },
  identify: (object) => object === null,
  represent: () => "null"
});
var TRUE_VALUES$2 = [
  "true",
  "True",
  "TRUE"
];
var FALSE_VALUES$2 = [
  "false",
  "False",
  "FALSE"
];
var boolCoreTag = defineScalarTag("tag:yaml.org,2002:bool", {
  implicit: true,
  implicitFirstChars: [
    "t",
    "T",
    "f",
    "F"
  ],
  resolve: (source) => {
    if (TRUE_VALUES$2.indexOf(source) !== -1) return true;
    if (FALSE_VALUES$2.indexOf(source) !== -1) return false;
    return NOT_RESOLVED;
  },
  identify: (object) => Object.prototype.toString.call(object) === "[object Boolean]",
  represent: (object) => object ? "true" : "false"
});
var TRUE_VALUES$1 = ["true"];
var FALSE_VALUES$1 = ["false"];
var boolJsonTag = defineScalarTag("tag:yaml.org,2002:bool", {
  implicit: true,
  implicitFirstChars: ["t", "f"],
  resolve: (source) => {
    if (TRUE_VALUES$1.indexOf(source) !== -1) return true;
    if (FALSE_VALUES$1.indexOf(source) !== -1) return false;
    return NOT_RESOLVED;
  },
  identify: (object) => Object.prototype.toString.call(object) === "[object Boolean]",
  represent: (object) => object ? "true" : "false"
});
var TRUE_VALUES = [
  "true",
  "True",
  "TRUE",
  "y",
  "Y",
  "yes",
  "Yes",
  "YES",
  "on",
  "On",
  "ON"
];
var FALSE_VALUES = [
  "false",
  "False",
  "FALSE",
  "n",
  "N",
  "no",
  "No",
  "NO",
  "off",
  "Off",
  "OFF"
];
var boolYaml11Tag = defineScalarTag("tag:yaml.org,2002:bool", {
  implicit: true,
  implicitFirstChars: [
    "y",
    "Y",
    "n",
    "N",
    "t",
    "T",
    "f",
    "F",
    "o",
    "O"
  ],
  resolve: (source) => {
    if (TRUE_VALUES.indexOf(source) !== -1) return true;
    if (FALSE_VALUES.indexOf(source) !== -1) return false;
    return NOT_RESOLVED;
  },
  identify: (object) => Object.prototype.toString.call(object) === "[object Boolean]",
  represent: (object) => object ? "true" : "false"
});
var YAML_INTEGER_IMPLICIT_PATTERN$1 = /* @__PURE__ */ new RegExp("^(?:0o[0-7]+|0x[0-9a-fA-F]+|[-+]?[0-9]+)$");
var YAML_INTEGER_EXPLICIT_PATTERN$1 = /* @__PURE__ */ new RegExp("^(?:[-+]?0b[0-1]+|[-+]?0o[0-7]+|[-+]?0x[0-9a-fA-F]+|[-+]?[0-9]+)$");
function parseYamlInteger$2(source) {
  let value = source;
  let sign = 1;
  if (value[0] === "-" || value[0] === "+") {
    if (value[0] === "-") sign = -1;
    value = value.slice(1);
  }
  if (value.startsWith("0b")) return sign * parseInt(value.slice(2), 2);
  if (value.startsWith("0o")) return sign * parseInt(value.slice(2), 8);
  if (value.startsWith("0x")) return sign * parseInt(value.slice(2), 16);
  return sign * parseInt(value, 10);
}
function resolveYamlInteger$2(source, isExplicit) {
  if (isExplicit) {
    if (!YAML_INTEGER_EXPLICIT_PATTERN$1.test(source)) return NOT_RESOLVED;
  } else if (!YAML_INTEGER_IMPLICIT_PATTERN$1.test(source)) return NOT_RESOLVED;
  const result = parseYamlInteger$2(source);
  return Number.isFinite(result) ? result : NOT_RESOLVED;
}
var intCoreTag = defineScalarTag("tag:yaml.org,2002:int", {
  implicit: true,
  implicitFirstChars: [
    "-",
    "+",
    ..."0123456789"
  ],
  resolve: resolveYamlInteger$2,
  identify: (object) => Number.isInteger(object) && !Object.is(object, -0) && object.toString(10).indexOf("e") < 0,
  represent: (object) => object.toString(10)
});
var YAML_INTEGER_IMPLICIT_PATTERN = /* @__PURE__ */ new RegExp("^-?(?:0|[1-9][0-9]*)$");
var YAML_INTEGER_EXPLICIT_PATTERN = /* @__PURE__ */ new RegExp("^(?:[-+]?0b[0-1]+|[-+]?0o[0-7]+|[-+]?0x[0-9a-fA-F]+|[-+]?[0-9]+)$");
function parseYamlInteger$1(source) {
  let value = source;
  let sign = 1;
  if (value[0] === "-" || value[0] === "+") {
    if (value[0] === "-") sign = -1;
    value = value.slice(1);
  }
  if (value.startsWith("0b")) return sign * parseInt(value.slice(2), 2);
  if (value.startsWith("0o")) return sign * parseInt(value.slice(2), 8);
  if (value.startsWith("0x")) return sign * parseInt(value.slice(2), 16);
  return sign * parseInt(value, 10);
}
function resolveYamlInteger$1(source, isExplicit) {
  if (isExplicit) {
    if (!YAML_INTEGER_EXPLICIT_PATTERN.test(source)) return NOT_RESOLVED;
  } else if (!YAML_INTEGER_IMPLICIT_PATTERN.test(source)) return NOT_RESOLVED;
  const result = parseYamlInteger$1(source);
  return Number.isFinite(result) ? result : NOT_RESOLVED;
}
var intJsonTag = defineScalarTag("tag:yaml.org,2002:int", {
  implicit: true,
  implicitFirstChars: ["-", ..."0123456789"],
  resolve: resolveYamlInteger$1,
  identify: (object) => Number.isInteger(object) && !Object.is(object, -0) && object.toString(10).indexOf("e") < 0,
  represent: (object) => object.toString(10)
});
var YAML_INTEGER_PATTERN = /* @__PURE__ */ new RegExp("^(?:[-+]?0b[0-1_]+|[-+]?0[0-7_]+|[-+]?0x[0-9a-fA-F_]+|[-+]?[0-9][0-9_]*(?::[0-5]?[0-9])+|[-+]?(?:0|[1-9][0-9_]*))$");
function parseYamlInteger(source) {
  let value = source.replace(/_/g, "");
  let sign = 1;
  if (value[0] === "-" || value[0] === "+") {
    if (value[0] === "-") sign = -1;
    value = value.slice(1);
  }
  if (value.startsWith("0b")) return sign * parseInt(value.slice(2), 2);
  if (value.startsWith("0x")) return sign * parseInt(value.slice(2), 16);
  if (value.includes(":")) {
    let result = 0;
    for (const part of value.split(":")) result = result * 60 + Number(part);
    return sign * result;
  }
  if (value !== "0" && value[0] === "0") return sign * parseInt(value, 8);
  return sign * parseInt(value, 10);
}
function resolveYamlInteger(source) {
  if (!YAML_INTEGER_PATTERN.test(source)) return NOT_RESOLVED;
  const result = parseYamlInteger(source);
  return Number.isFinite(result) ? result : NOT_RESOLVED;
}
var intYaml11Tag = defineScalarTag("tag:yaml.org,2002:int", {
  implicit: true,
  implicitFirstChars: [
    "-",
    "+",
    ..."0123456789"
  ],
  resolve: resolveYamlInteger,
  identify: (object) => Number.isInteger(object) && !Object.is(object, -0) && object.toString(10).indexOf("e") < 0,
  represent: (object) => object.toString(10)
});
var YAML_FLOAT_PATTERN$1 = /* @__PURE__ */ new RegExp("^(?:[-+]?[0-9]+(?:\\.[0-9]*)?(?:[eE][-+]?[0-9]+)?|[-+]?\\.[0-9]+(?:[eE][-+]?[0-9]+)?|[-+]?\\.(?:inf|Inf|INF)|\\.(?:nan|NaN|NAN))$");
var YAML_FLOAT_SPECIAL_PATTERN$1 = /* @__PURE__ */ new RegExp("^(?:[-+]?\\.(?:inf|Inf|INF)|\\.(?:nan|NaN|NAN))$");
function resolveYamlFloat$2(source) {
  if (!YAML_FLOAT_PATTERN$1.test(source)) return NOT_RESOLVED;
  let value = source.toLowerCase();
  const sign = value[0] === "-" ? -1 : 1;
  if ("+-".includes(value[0])) value = value.slice(1);
  if (value === ".inf") return sign === 1 ? Number.POSITIVE_INFINITY : Number.NEGATIVE_INFINITY;
  if (value === ".nan") return NaN;
  const result = sign * parseFloat(value);
  if (Number.isFinite(result) || YAML_FLOAT_SPECIAL_PATTERN$1.test(source)) return result;
  return NOT_RESOLVED;
}
function representYamlFloat$2(object) {
  if (isNaN(object)) return ".nan";
  if (object === Number.POSITIVE_INFINITY) return ".inf";
  if (object === Number.NEGATIVE_INFINITY) return "-.inf";
  if (Object.is(object, -0)) return "-0.0";
  const result = object.toString(10);
  return /^[-+]?[0-9]+e/.test(result) ? result.replace("e", ".e") : result;
}
var floatCoreTag = defineScalarTag("tag:yaml.org,2002:float", {
  implicit: true,
  implicitFirstChars: [
    "-",
    "+",
    ".",
    ..."0123456789"
  ],
  resolve: resolveYamlFloat$2,
  identify: (object) => typeof object === "number" && (!Number.isInteger(object) || Object.is(object, -0) || object.toString(10).indexOf("e") >= 0),
  represent: representYamlFloat$2
});
var YAML_FLOAT_IMPLICIT_PATTERN = /* @__PURE__ */ new RegExp("^-?(?:0|[1-9][0-9]*)(?:\\.[0-9]*)?(?:[eE][-+]?[0-9]+)?$");
var YAML_FLOAT_EXPLICIT_PATTERN = /* @__PURE__ */ new RegExp("^(?:[-+]?[0-9]+(?:\\.[0-9]*)?(?:[eE][-+]?[0-9]+)?|[-+]?\\.[0-9]+(?:[eE][-+]?[0-9]+)?|[-+]?\\.(?:inf|Inf|INF)|\\.(?:nan|NaN|NAN))$");
function resolveYamlFloat$1(source, isExplicit) {
  if (isExplicit) {
    if (!YAML_FLOAT_EXPLICIT_PATTERN.test(source)) return NOT_RESOLVED;
    let value = source.toLowerCase();
    const sign = value[0] === "-" ? -1 : 1;
    if ("+-".includes(value[0])) value = value.slice(1);
    if (value === ".inf") return sign === 1 ? Number.POSITIVE_INFINITY : Number.NEGATIVE_INFINITY;
    if (value === ".nan") return NaN;
    const result2 = sign * parseFloat(value);
    return Number.isFinite(result2) ? result2 : NOT_RESOLVED;
  }
  if (!YAML_FLOAT_IMPLICIT_PATTERN.test(source)) return NOT_RESOLVED;
  const result = Number(source);
  if (Number.isFinite(result)) return result;
  return NOT_RESOLVED;
}
function representYamlFloat$1(object) {
  if (isNaN(object)) return ".nan";
  if (object === Number.POSITIVE_INFINITY) return ".inf";
  if (object === Number.NEGATIVE_INFINITY) return "-.inf";
  if (Object.is(object, -0)) return "-0.0";
  const result = object.toString(10);
  return /^[-+]?[0-9]+e/.test(result) ? result.replace("e", ".e") : result;
}
var floatJsonTag = defineScalarTag("tag:yaml.org,2002:float", {
  implicit: true,
  implicitFirstChars: ["-", ..."0123456789"],
  resolve: resolveYamlFloat$1,
  identify: (object) => typeof object === "number" && (!Number.isInteger(object) || Object.is(object, -0) || object.toString(10).indexOf("e") >= 0),
  represent: representYamlFloat$1
});
var YAML_FLOAT_PATTERN = /* @__PURE__ */ new RegExp("^(?:[-+]?(?:(?:[0-9][0-9_]*)?\\.[0-9_]*)(?:[eE][-+][0-9]+)?|[-+]?[0-9][0-9_]*(?::[0-5]?[0-9])+\\.[0-9_]*|[-+]?\\.(?:inf|Inf|INF)|\\.(?:nan|NaN|NAN))$");
var YAML_FLOAT_SPECIAL_PATTERN = /* @__PURE__ */ new RegExp("^(?:[-+]?\\.(?:inf|Inf|INF)|\\.(?:nan|NaN|NAN))$");
function resolveYamlFloat(source) {
  if (!YAML_FLOAT_PATTERN.test(source)) return NOT_RESOLVED;
  let value = source.toLowerCase().replace(/_/g, "");
  const sign = value[0] === "-" ? -1 : 1;
  if ("+-".includes(value[0])) value = value.slice(1);
  if (value === ".inf") return sign === 1 ? Number.POSITIVE_INFINITY : Number.NEGATIVE_INFINITY;
  if (value === ".nan") return NaN;
  let result = 0;
  if (value.includes(":")) {
    for (const part of value.split(":")) result = result * 60 + Number(part);
    result *= sign;
  } else result = sign * parseFloat(value);
  if (Number.isFinite(result) || YAML_FLOAT_SPECIAL_PATTERN.test(source)) return result;
  return NOT_RESOLVED;
}
function representYamlFloat(object) {
  if (isNaN(object)) return ".nan";
  if (object === Number.POSITIVE_INFINITY) return ".inf";
  if (object === Number.NEGATIVE_INFINITY) return "-.inf";
  if (Object.is(object, -0)) return "-0.0";
  const result = object.toString(10);
  return /^[-+]?[0-9]+e/.test(result) ? result.replace("e", ".e") : result;
}
var floatYaml11Tag = defineScalarTag("tag:yaml.org,2002:float", {
  implicit: true,
  implicitFirstChars: [
    "-",
    "+",
    ".",
    ..."0123456789"
  ],
  resolve: resolveYamlFloat,
  identify: (object) => typeof object === "number" && (!Number.isInteger(object) || Object.is(object, -0) || object.toString(10).indexOf("e") >= 0),
  represent: representYamlFloat
});
var mergeTag = defineScalarTag("tag:yaml.org,2002:merge", {
  implicit: true,
  implicitFirstChars: ["<"],
  resolve: (source, isExplicit) => {
    if (source === "<<" || isExplicit && source === "") return "<<";
    return NOT_RESOLVED;
  },
  identify: () => false
});
var BASE64_PATTERN = /^[A-Za-z0-9+/]*={0,2}$/;
function resolveYamlBinary(source) {
  const input = source.replace(/\s/g, "");
  if (input.length % 4 !== 0 || !BASE64_PATTERN.test(input)) return NOT_RESOLVED;
  const binary = atob(input);
  const result = new Uint8Array(binary.length);
  for (let index = 0; index < binary.length; index++) result[index] = binary.charCodeAt(index);
  return result;
}
function representYamlBinary(object) {
  let binary = "";
  for (let index = 0; index < object.length; index++) binary += String.fromCharCode(object[index]);
  return btoa(binary);
}
var binaryTag = defineScalarTag("tag:yaml.org,2002:binary", {
  resolve: resolveYamlBinary,
  identify: (object) => Object.prototype.toString.call(object) === "[object Uint8Array]",
  represent: representYamlBinary
});
var YAML_DATE_REGEXP = /* @__PURE__ */ new RegExp("^([0-9][0-9][0-9][0-9])-([0-9][0-9])-([0-9][0-9])$");
var YAML_TIMESTAMP_REGEXP = /* @__PURE__ */ new RegExp("^([0-9][0-9][0-9][0-9])-([0-9][0-9]?)-([0-9][0-9]?)(?:[Tt]|[ \\t]+)([0-9][0-9]?):([0-9][0-9]):([0-9][0-9])(?:\\.([0-9]*))?(?:[ \\t]*(Z|([-+])([0-9][0-9]?)(?::([0-9][0-9]))?))?$");
function makeUtcDate(year, month, day, hour = 0, minute = 0, second = 0, fraction = 0) {
  const date = new Date(Date.UTC(year, month, day, hour, minute, second, fraction));
  date.setUTCFullYear(year, month, day);
  return date;
}
function resolveYamlTimestamp(source) {
  let match = YAML_DATE_REGEXP.exec(source);
  if (match === null) match = YAML_TIMESTAMP_REGEXP.exec(source);
  if (match === null) return NOT_RESOLVED;
  const year = +match[1];
  const month = +match[2] - 1;
  const day = +match[3];
  if (!match[4]) {
    const date2 = makeUtcDate(year, month, day);
    if (date2.getUTCFullYear() !== year || date2.getUTCMonth() !== month || date2.getUTCDate() !== day) return NOT_RESOLVED;
    return date2;
  }
  const hour = +match[4];
  const minute = +match[5];
  const second = +match[6];
  let fraction = 0;
  if (hour > 23 || minute > 59 || second > 59) return NOT_RESOLVED;
  if (match[7]) {
    let value = match[7].slice(0, 3);
    while (value.length < 3) value += "0";
    fraction = +value;
  }
  const date = makeUtcDate(year, month, day, hour, minute, second, fraction);
  if (date.getUTCFullYear() !== year || date.getUTCMonth() !== month || date.getUTCDate() !== day) return NOT_RESOLVED;
  if (match[9]) {
    const offsetHour = +match[10];
    const offsetMinute = +(match[11] || 0);
    if (offsetHour > 23 || offsetMinute > 59) return NOT_RESOLVED;
    const offset = (offsetHour * 60 + offsetMinute) * 6e4;
    date.setTime(date.getTime() - (match[9] === "-" ? -offset : offset));
  }
  return date;
}
var timestampTag = defineScalarTag("tag:yaml.org,2002:timestamp", {
  implicit: true,
  implicitFirstChars: [..."0123456789"],
  resolve: resolveYamlTimestamp,
  identify: (object) => object instanceof Date,
  represent: (object) => object.toISOString()
});
var seqTag = defineSequenceTag("tag:yaml.org,2002:seq", {
  create: () => [],
  addItem: (container, item) => {
    container.push(item);
  },
  identify: Array.isArray
});
function isPlainObject(data) {
  if (data === null || typeof data !== "object" || Array.isArray(data)) return false;
  const prototype = Object.getPrototypeOf(data);
  return prototype === null || prototype === Object.prototype;
}
function pick(object, keys) {
  const result = {};
  for (const key of keys) if (object[key] !== void 0) result[key] = object[key];
  return result;
}
var omapTag = defineSequenceTag("tag:yaml.org,2002:omap", {
  create: () => ({
    list: [],
    seen: /* @__PURE__ */ new Set()
  }),
  addItem: (carrier, item) => {
    let key;
    if (item instanceof Map) {
      if (item.size !== 1) return "cannot resolve an ordered map item";
      key = item.keys().next().value;
    } else if (isPlainObject(item)) {
      const itemKeys = Object.keys(item);
      if (itemKeys.length !== 1) return "cannot resolve an ordered map item";
      key = itemKeys[0];
    } else return "cannot resolve an ordered map item";
    if (carrier.seen.has(key)) return "duplicate key in ordered map";
    carrier.seen.add(key);
    carrier.list.push(item);
    return "";
  },
  finalize: (carrier) => carrier.list,
  identify: () => false
});
var pairsTag = defineSequenceTag("tag:yaml.org,2002:pairs", {
  create: () => [],
  addItem: (container, item) => {
    if (item instanceof Map) {
      if (item.size !== 1) return "cannot resolve a pairs item";
      container.push(item.entries().next().value);
      return "";
    }
    if (Object.prototype.toString.call(item) !== "[object Object]") return "cannot resolve a pairs item";
    const object = item;
    const keys = Object.keys(object);
    if (keys.length !== 1) return "cannot resolve a pairs item";
    container.push([keys[0], object[keys[0]]]);
    return "";
  },
  identify: () => false
});
var mapTag = defineMappingTag("tag:yaml.org,2002:map", {
  create: () => ({}),
  identify: isPlainObject,
  represent: (o) => {
    const map = /* @__PURE__ */ new Map();
    for (const key of Object.keys(o)) map.set(key, o[key]);
    return map;
  },
  addPair: (container, key, value) => {
    if (key !== null && typeof key === "object") return "object-based map does not support complex keys";
    const normalizedKey = String(key);
    if (normalizedKey === "__proto__") Object.defineProperty(container, normalizedKey, {
      value,
      enumerable: true,
      configurable: true,
      writable: true
    });
    else container[normalizedKey] = value;
    return "";
  },
  has: (container, key) => {
    if (key !== null && typeof key === "object") return false;
    return Object.prototype.hasOwnProperty.call(container, String(key));
  },
  keys: (container) => Object.keys(container),
  get: (container, key) => {
    const normalizedKey = String(key);
    if (!Object.prototype.hasOwnProperty.call(container, normalizedKey)) return null;
    return container[normalizedKey];
  }
});
var setTag = defineMappingTag("tag:yaml.org,2002:set", {
  create: () => /* @__PURE__ */ new Set(),
  identify: (data) => data instanceof Set,
  represent: (data) => {
    const map = /* @__PURE__ */ new Map();
    for (const key of data) map.set(key, null);
    return map;
  },
  addPair: (container, key, value) => {
    if (value !== null) return "cannot resolve a set item";
    container.add(key);
    return "";
  },
  has: (container, key) => container.has(key),
  keys: (container) => container.keys(),
  get: () => null
});
function createTagDefinitionMap() {
  return {
    scalar: /* @__PURE__ */ Object.create(null),
    sequence: /* @__PURE__ */ Object.create(null),
    mapping: /* @__PURE__ */ Object.create(null)
  };
}
function createTagDefinitionListMap() {
  return {
    scalar: [],
    sequence: [],
    mapping: []
  };
}
function compileTags(tags) {
  const result = [];
  for (const tag of tags) {
    let index = result.length;
    for (let previousIndex = 0; previousIndex < result.length; previousIndex++) {
      const previous = result[previousIndex];
      if (previous.nodeKind === tag.nodeKind && previous.tagName === tag.tagName && previous.matchByTagPrefix === tag.matchByTagPrefix) {
        index = previousIndex;
        break;
      }
    }
    result[index] = tag;
  }
  return result;
}
var Schema = class Schema2 {
  tags;
  /** @internal */
  implicitScalarTags;
  /**
  * Dispatch implicit scalar resolvers by `source.charAt(0)`. Each bucket holds
  * the resolvers that may match that key, in schema order; a key absent from
  * the map uses
  * {@link Schema.implicitScalarAnyFirstChar}
  * (resolvers that declared no first-char constraint, so they apply to any
  * first character).
  */
  implicitScalarByFirstChar;
  implicitScalarAnyFirstChar;
  /**
  * The default scalar tag (`!!str`), resolved once so the composer's fallback
  * for unresolved plain scalars avoids a keyed lookup per scalar.
  *
  * @internal
  */
  defaultScalarTag;
  /**
  * The default container tags (`!!seq` / `!!map`), used by the dumper: when a
  * value is identified by its default tag, the tag is implicit and not
  * printed. Undefined if the schema does not define them (then such values
  * can't be dumped).
  *
  * @internal
  */
  defaultSequenceTag;
  /** @internal */
  defaultMappingTag;
  exact;
  prefix;
  constructor(tags) {
    const compiledTags = compileTags(tags);
    const implicitScalarTags = [];
    const exact = createTagDefinitionMap();
    const prefix2 = createTagDefinitionListMap();
    for (const tag of compiledTags) {
      if (tag.nodeKind === "scalar" && tag.implicit) {
        if (tag.matchByTagPrefix) throw new Error("Implicit scalar tags cannot match by tag prefix");
        implicitScalarTags.push(tag);
      }
      switch (tag.nodeKind) {
        case "scalar":
          if (tag.matchByTagPrefix) prefix2.scalar.push(tag);
          else exact.scalar[tag.tagName] = tag;
          break;
        case "sequence":
          if (tag.matchByTagPrefix) prefix2.sequence.push(tag);
          else exact.sequence[tag.tagName] = tag;
          break;
        case "mapping":
          if (tag.matchByTagPrefix) prefix2.mapping.push(tag);
          else exact.mapping[tag.tagName] = tag;
      }
    }
    const implicitScalarAnyFirstChar = implicitScalarTags.filter((tag) => tag.implicitFirstChars === null);
    const keys = /* @__PURE__ */ new Set();
    for (const tag of implicitScalarTags) if (tag.implicitFirstChars !== null) for (const key of tag.implicitFirstChars) keys.add(key);
    const implicitScalarByFirstChar = /* @__PURE__ */ new Map();
    for (const key of keys) implicitScalarByFirstChar.set(key, implicitScalarTags.filter((tag) => tag.implicitFirstChars === null || tag.implicitFirstChars.indexOf(key) !== -1));
    const defaultScalarTag = exact.scalar["tag:yaml.org,2002:str"];
    if (!defaultScalarTag) throw new Error("schema does not define the default scalar tag (tag:yaml.org,2002:str)");
    this.tags = compiledTags;
    this.implicitScalarTags = implicitScalarTags;
    this.implicitScalarByFirstChar = implicitScalarByFirstChar;
    this.implicitScalarAnyFirstChar = implicitScalarAnyFirstChar;
    this.defaultScalarTag = defaultScalarTag;
    this.defaultSequenceTag = exact.sequence["tag:yaml.org,2002:seq"];
    this.defaultMappingTag = exact.mapping["tag:yaml.org,2002:map"];
    this.exact = exact;
    this.prefix = prefix2;
  }
  /** @internal */
  lookupScalarTag(tagName) {
    const exactTag = this.exact.scalar[tagName];
    if (exactTag) return exactTag;
    for (const tag of this.prefix.scalar) if (tagName.startsWith(tag.tagName)) return tag;
  }
  /** @internal */
  lookupSequenceTag(tagName) {
    const exactTag = this.exact.sequence[tagName];
    if (exactTag) return exactTag;
    for (const tag of this.prefix.sequence) if (tagName.startsWith(tag.tagName)) return tag;
  }
  /** @internal */
  lookupMappingTag(tagName) {
    const exactTag = this.exact.mapping[tagName];
    if (exactTag) return exactTag;
    for (const tag of this.prefix.mapping) if (tagName.startsWith(tag.tagName)) return tag;
  }
  /** @internal */
  resolveImplicitScalarTag(source) {
    const candidates = this.implicitScalarByFirstChar.get(source.charAt(0)) ?? this.implicitScalarAnyFirstChar;
    for (const tag2 of candidates) {
      const value = tag2.resolve(source, false, tag2.tagName);
      if (value !== NOT_RESOLVED) return {
        value,
        tag: tag2
      };
    }
    const tag = this.defaultScalarTag;
    return {
      value: tag.resolve(source, false, tag.tagName),
      tag
    };
  }
  /**
  * Creates a new schema with the specified tags added. If a tag already
  * exists, it is replaced by the specified tag.
  *
  * @example
  *
  * ```javascript
  * import { CORE_SCHEMA, mergeTag, realMapTag } from 'js-yaml'
  *
  * const schema = CORE_SCHEMA.withTags(mergeTag, realMapTag)
  * ```
  */
  withTags(...tags) {
    let flatTags = [];
    for (const tag of tags) flatTags = flatTags.concat(tag);
    return new Schema2([...this.tags, ...flatTags]);
  }
};
var FAILSAFE_SCHEMA = new Schema([
  strTag,
  seqTag,
  mapTag
]);
var JSON_SCHEMA = new Schema([
  ...FAILSAFE_SCHEMA.tags,
  nullJsonTag,
  boolJsonTag,
  intJsonTag,
  floatJsonTag
]);
var CORE_SCHEMA = new Schema([
  ...FAILSAFE_SCHEMA.tags,
  nullCoreTag,
  boolCoreTag,
  intCoreTag,
  floatCoreTag
]);
var YAML11_SCHEMA = new Schema([
  ...FAILSAFE_SCHEMA.tags,
  nullYaml11Tag,
  boolYaml11Tag,
  intYaml11Tag,
  floatYaml11Tag,
  timestampTag,
  mergeTag,
  binaryTag,
  omapTag,
  pairsTag,
  setTag
]);
var DUMP_SCHEMA = YAML11_SCHEMA.withTags({
  ...intYaml11Tag,
  resolve: (source, isExplicit, tagName) => {
    const result = intYaml11Tag.resolve(source, isExplicit, tagName);
    return result === NOT_RESOLVED ? intCoreTag.resolve(source, isExplicit, tagName) : result;
  }
}, {
  ...floatYaml11Tag,
  resolve: (source, isExplicit, tagName) => {
    const result = floatYaml11Tag.resolve(source, isExplicit, tagName);
    return result === NOT_RESOLVED ? floatCoreTag.resolve(source, isExplicit, tagName) : result;
  }
});
var realMapTag = defineMappingTag("tag:yaml.org,2002:map", {
  create: () => /* @__PURE__ */ new Map(),
  addPair: (container, key, value) => {
    container.set(key, value);
    return "";
  },
  has: (container, key) => container.has(key),
  keys: (container) => container.keys(),
  get: (container, key) => container.get(key),
  identify: (data) => data instanceof Map || isPlainObject(data),
  represent: (data) => {
    if (data instanceof Map) return data;
    const map = /* @__PURE__ */ new Map();
    const obj = data;
    for (const key of Object.keys(obj)) map.set(key, obj[key]);
    return map;
  }
});
function normalizeKey(key) {
  if (Array.isArray(key)) {
    const array = Array.prototype.slice.call(key);
    for (let index = 0; index < array.length; index++) {
      if (Array.isArray(array[index])) return null;
      if (typeof array[index] === "object" && Object.prototype.toString.call(array[index]) === "[object Object]") array[index] = "[object Object]";
    }
    return String(array);
  }
  if (typeof key === "object" && Object.prototype.toString.call(key) === "[object Object]") return "[object Object]";
  return String(key);
}
var legacyMapTag = defineMappingTag("tag:yaml.org,2002:map", {
  create: () => ({}),
  identify: isPlainObject,
  represent: (o) => {
    const map = /* @__PURE__ */ new Map();
    for (const key of Object.keys(o)) map.set(key, o[key]);
    return map;
  },
  addPair: (container, key, value) => {
    const normalizedKey = normalizeKey(key);
    if (normalizedKey === null) return "nested arrays are not supported inside keys";
    if (normalizedKey === "__proto__") Object.defineProperty(container, normalizedKey, {
      value,
      enumerable: true,
      configurable: true,
      writable: true
    });
    else container[normalizedKey] = value;
    return "";
  },
  has: (container, key) => {
    const normalizedKey = normalizeKey(key);
    return normalizedKey !== null && Object.prototype.hasOwnProperty.call(container, normalizedKey);
  },
  keys: (container) => Object.keys(container),
  get: (container, key) => {
    const normalizedKey = String(key);
    if (!Object.prototype.hasOwnProperty.call(container, normalizedKey)) return null;
    return container[normalizedKey];
  }
});
var DEFAULT_SNIPPET_OPTIONS = {
  maxLength: 79,
  indent: 1,
  linesBefore: 3,
  linesAfter: 2
};
function getLine(buffer, lineStart, lineEnd, position, maxLineLength) {
  let head = "";
  let tail = "";
  const maxHalfLength = Math.floor(maxLineLength / 2) - 1;
  if (position - lineStart > maxHalfLength) {
    head = " ... ";
    lineStart = position - maxHalfLength + head.length;
  }
  if (lineEnd - position > maxHalfLength) {
    tail = " ...";
    lineEnd = position + maxHalfLength - tail.length;
  }
  return {
    str: head + buffer.slice(lineStart, lineEnd).replace(/\t/g, "\u2192") + tail,
    pos: position - lineStart + head.length
  };
}
function padStart(string, max) {
  return " ".repeat(Math.max(max - string.length, 0)) + string;
}
function makeSnippet(mark, options) {
  if (!mark.buffer) return null;
  const opts = {
    ...DEFAULT_SNIPPET_OPTIONS,
    ...options
  };
  const re = /\r?\n|\r|\0/g;
  const lineStarts = [0];
  const lineEnds = [];
  let match;
  let foundLineNo = -1;
  while (match = re.exec(mark.buffer)) {
    lineEnds.push(match.index);
    lineStarts.push(match.index + match[0].length);
    if (mark.position <= match.index && foundLineNo < 0) foundLineNo = lineStarts.length - 2;
  }
  if (foundLineNo < 0) foundLineNo = lineStarts.length - 1;
  let result = "";
  const lineNoLength = Math.min(mark.line + opts.linesAfter, lineEnds.length).toString().length;
  const maxLineLength = opts.maxLength - (opts.indent + lineNoLength + 3);
  for (let i = 1; i <= opts.linesBefore; i++) {
    if (foundLineNo - i < 0) break;
    const line2 = getLine(mark.buffer, lineStarts[foundLineNo - i], lineEnds[foundLineNo - i], mark.position - (lineStarts[foundLineNo] - lineStarts[foundLineNo - i]), maxLineLength);
    result = `${" ".repeat(opts.indent)}${padStart((mark.line - i + 1).toString(), lineNoLength)} | ${line2.str}
${result}`;
  }
  const line = getLine(mark.buffer, lineStarts[foundLineNo], lineEnds[foundLineNo], mark.position, maxLineLength);
  result += `${" ".repeat(opts.indent)}${padStart((mark.line + 1).toString(), lineNoLength)} | ${line.str}
`;
  result += `${"-".repeat(opts.indent + lineNoLength + 3 + line.pos)}^
`;
  for (let i = 1; i <= opts.linesAfter; i++) {
    if (foundLineNo + i >= lineEnds.length) break;
    const line2 = getLine(mark.buffer, lineStarts[foundLineNo + i], lineEnds[foundLineNo + i], mark.position - (lineStarts[foundLineNo] - lineStarts[foundLineNo + i]), maxLineLength);
    result += `${" ".repeat(opts.indent)}${padStart((mark.line + i + 1).toString(), lineNoLength)} | ${line2.str}
`;
  }
  return result.replace(/\n$/, "");
}
function formatError(exception, compact) {
  let where = "";
  if (!exception.mark) return exception.reason;
  if (exception.mark.name) where += `in "${exception.mark.name}" `;
  where += `(${exception.mark.line + 1}:${exception.mark.column + 1})`;
  if (!compact && exception.mark.snippet) where += `

${exception.mark.snippet}`;
  return `${exception.reason} ${where}`;
}
var YAMLException = class YAMLException2 extends Error {
  reason;
  mark;
  /**
  * Optional `mark` contains source snippet data. Usually, use
  * {@link YAMLException.throwAt} instead of passing it directly.
  */
  constructor(reason, mark) {
    super();
    this.name = "YAMLException";
    this.reason = reason;
    this.mark = mark;
    this.message = formatError(this, false);
    if (Error.captureStackTrace) Error.captureStackTrace(this, this.constructor);
  }
  /**
  * Returns the formatted error, omitting the source snippet in compact mode.
  */
  toString(compact) {
    return `${this.name}: ${formatError(this, compact)}`;
  }
  /**
  * Builds a YAMLException with a source snippet and throws it. `source` is
  * the raw input text; `position` is an offset into it.
  */
  static throwAt(source, position, message, filename = "") {
    let line = 0;
    let lineStart = 0;
    for (let index = 0; index < position; index++) {
      const ch = source.charCodeAt(index);
      if (ch === 10) {
        line++;
        lineStart = index + 1;
      } else if (ch === 13) {
        line++;
        if (source.charCodeAt(index + 1) === 10) index++;
        lineStart = index + 1;
      }
    }
    const mark = {
      name: filename,
      buffer: source,
      position,
      line,
      column: position - lineStart
    };
    mark.snippet = makeSnippet(mark);
    throw new YAMLException2(message, mark);
  }
};
var EVENT_ID = {
  DOCUMENT: 1,
  SEQUENCE: 2,
  MAPPING: 3,
  SCALAR: 4,
  ALIAS: 5,
  POP: 6
};
var SCALAR_STYLE = {
  PLAIN: 1,
  SINGLE_QUOTED: 2,
  DOUBLE_QUOTED: 3,
  LITERAL_BLOCK: 4,
  FOLDED_BLOCK: 5
};
var COLLECTION_STYLE = {
  BLOCK: 1,
  FLOW: 2
};
var CHOMPING_MODE = {
  CLIP: 1,
  STRIP: 2,
  KEEP: 3
};
var NO_RANGE$3 = -1;
function simpleEscapeSequence(c) {
  switch (c) {
    case 48:
      return "\0";
    case 97:
      return "\x07";
    case 98:
      return "\b";
    case 116:
      return "	";
    case 9:
      return "	";
    case 110:
      return "\n";
    case 118:
      return "\v";
    case 102:
      return "\f";
    case 114:
      return "\r";
    case 101:
      return "\x1B";
    case 32:
      return " ";
    case 34:
      return '"';
    case 47:
      return "/";
    case 92:
      return "\\";
    case 78:
      return "\x85";
    case 95:
      return "\xA0";
    case 76:
      return "\u2028";
    case 80:
      return "\u2029";
    default:
      return "";
  }
}
var simpleEscapeCheck = new Array(256);
var simpleEscapeMap = new Array(256);
for (let i = 0; i < 256; i++) {
  simpleEscapeCheck[i] = simpleEscapeSequence(i) ? 1 : 0;
  simpleEscapeMap[i] = simpleEscapeSequence(i);
}
function charFromCodepoint(c) {
  if (c <= 65535) return String.fromCharCode(c);
  return String.fromCharCode((c - 65536 >> 10) + 55296, (c - 65536 & 1023) + 56320);
}
function fromHexCode$1(c) {
  if (c >= 48 && c <= 57) return c - 48;
  return (c | 32) - 97 + 10;
}
function escapedHexLen$1(c) {
  if (c === 120) return 2;
  if (c === 117) return 4;
  return 8;
}
function skipFoldedBreaks(input, position, end) {
  let breaks = 0;
  while (position < end) {
    const ch = input.charCodeAt(position);
    if (ch === 10) {
      breaks++;
      position++;
    } else if (ch === 13) {
      breaks++;
      position++;
      if (input.charCodeAt(position) === 10) position++;
    } else if (ch === 32 || ch === 9) position++;
    else break;
  }
  return {
    position,
    breaks
  };
}
function foldedBreaks(count) {
  if (count === 1) return " ";
  return "\n".repeat(count - 1);
}
function getPlainValue(input, start, end) {
  let result = "";
  let position = start;
  let captureStart = start;
  let captureEnd = start;
  while (position < end) {
    const ch = input.charCodeAt(position);
    if (ch === 10 || ch === 13) {
      result += input.slice(captureStart, captureEnd);
      const fold = skipFoldedBreaks(input, position, end);
      result += foldedBreaks(fold.breaks);
      position = captureStart = captureEnd = fold.position;
    } else {
      position++;
      if (ch !== 32 && ch !== 9) captureEnd = position;
    }
  }
  return result + input.slice(captureStart, captureEnd);
}
function getSingleQuotedValue(input, start, end) {
  let result = "";
  let position = start;
  let captureStart = start;
  let captureEnd = start;
  while (position < end) {
    const ch = input.charCodeAt(position);
    if (ch === 39) {
      result += input.slice(captureStart, position) + "'";
      position += 2;
      captureStart = captureEnd = position;
    } else if (ch === 10 || ch === 13) {
      result += input.slice(captureStart, captureEnd);
      const fold = skipFoldedBreaks(input, position, end);
      result += foldedBreaks(fold.breaks);
      position = captureStart = captureEnd = fold.position;
    } else {
      position++;
      if (ch !== 32 && ch !== 9) captureEnd = position;
    }
  }
  return result + input.slice(captureStart, end);
}
function getDoubleQuotedValue(input, start, end) {
  let result = "";
  let position = start;
  let captureStart = start;
  let captureEnd = start;
  while (position < end) {
    const ch = input.charCodeAt(position);
    if (ch === 92) {
      result += input.slice(captureStart, position);
      position++;
      const escaped = input.charCodeAt(position);
      if (escaped === 10 || escaped === 13) position = skipFoldedBreaks(input, position, end).position;
      else if (escaped < 256 && simpleEscapeCheck[escaped]) {
        result += simpleEscapeMap[escaped];
        position++;
      } else {
        let hexLength = escapedHexLen$1(escaped);
        let hexResult = 0;
        for (; hexLength > 0; hexLength--) {
          position++;
          const digit = fromHexCode$1(input.charCodeAt(position));
          hexResult = (hexResult << 4) + digit;
        }
        result += charFromCodepoint(hexResult);
        position++;
      }
      captureStart = captureEnd = position;
    } else if (ch === 10 || ch === 13) {
      result += input.slice(captureStart, captureEnd);
      const fold = skipFoldedBreaks(input, position, end);
      result += foldedBreaks(fold.breaks);
      position = captureStart = captureEnd = fold.position;
    } else {
      position++;
      if (ch !== 32 && ch !== 9) captureEnd = position;
    }
  }
  return result + input.slice(captureStart, end);
}
function getBlockValue(input, start, end, indent, chomping, folded) {
  const textIndent = indent < 0 ? 0 : indent;
  const region = input.slice(start, end).replace(/\r\n?/g, "\n");
  const lines = region === "" ? [] : (region.endsWith("\n") ? region.slice(0, -1) : region).split("\n");
  let result = "";
  let didReadContent = false;
  let emptyLines = 0;
  let atMoreIndented = false;
  for (const line of lines) {
    let column = 0;
    while (column < textIndent && line.charCodeAt(column) === 32) column++;
    if (indent < 0 || column >= line.length) {
      emptyLines++;
      continue;
    }
    const content = line.slice(textIndent);
    const first = content.charCodeAt(0);
    if (folded) {
      if (first === 32 || first === 9) {
        atMoreIndented = true;
        result += "\n".repeat(didReadContent ? 1 + emptyLines : emptyLines);
      } else if (atMoreIndented) {
        atMoreIndented = false;
        result += "\n".repeat(emptyLines + 1);
      } else if (emptyLines === 0) {
        if (didReadContent) result += " ";
      } else result += "\n".repeat(emptyLines);
    } else result += "\n".repeat(didReadContent ? 1 + emptyLines : emptyLines);
    result += content;
    didReadContent = true;
    emptyLines = 0;
  }
  if (chomping === CHOMPING_MODE.KEEP) result += "\n".repeat(didReadContent ? 1 + emptyLines : emptyLines);
  else if (chomping !== CHOMPING_MODE.STRIP) {
    if (didReadContent) result += "\n";
  }
  return result;
}
function getScalarValue(input, scalar) {
  if (scalar.valueStart === NO_RANGE$3) return "";
  const { valueStart, valueEnd } = scalar;
  if (scalar.fast) return input.slice(valueStart, valueEnd);
  switch (scalar.style) {
    case SCALAR_STYLE.SINGLE_QUOTED:
      return getSingleQuotedValue(input, valueStart, valueEnd);
    case SCALAR_STYLE.DOUBLE_QUOTED:
      return getDoubleQuotedValue(input, valueStart, valueEnd);
    case SCALAR_STYLE.LITERAL_BLOCK:
      return getBlockValue(input, valueStart, valueEnd, scalar.indent, scalar.chomping, false);
    case SCALAR_STYLE.FOLDED_BLOCK:
      return getBlockValue(input, valueStart, valueEnd, scalar.indent, scalar.chomping, true);
    default:
      return getPlainValue(input, valueStart, valueEnd);
  }
}
var DEFAULT_TAG_HANDLERS = Object.assign(/* @__PURE__ */ Object.create(null), {
  "!": "!",
  "!!": "tag:yaml.org,2002:"
});
var TAG_SUFFIX_CHARS = "-#;/?:@&=+$_.~*'()";
var TAG_URI_CHARS = TAG_SUFFIX_CHARS + "!,[]";
function tagPercentDecode(source) {
  let result = "";
  let index = 0;
  while (index < source.length) {
    if (source.charCodeAt(index) !== 37) {
      result += source[index++];
      continue;
    }
    let ch = parseInt(source.slice(index + 1, index + 3), 16);
    index += 3;
    if (ch >= 192) {
      let remaining = ch < 224 ? 1 : ch < 240 ? 2 : 3;
      ch &= (1 << 6 - remaining) - 1;
      while (remaining-- > 0) {
        ch = ch << 6 | parseInt(source.slice(index + 1, index + 3), 16) & 63;
        index += 3;
      }
    }
    if (ch < 65536) result += String.fromCharCode(ch);
    else {
      ch -= 65536;
      result += String.fromCharCode(55296 | ch >> 10, 56320 | ch & 1023);
    }
  }
  return result;
}
function tagNameFull(rawTag, tagHandlers) {
  if (rawTag.startsWith("!<") && rawTag.endsWith(">")) return tagPercentDecode(rawTag.slice(2, -1));
  const handleEnd = rawTag.indexOf("!", 1);
  const handle = handleEnd === -1 ? "!" : rawTag.slice(0, handleEnd + 1);
  return tagPercentDecode(tagHandlers?.[handle] ?? DEFAULT_TAG_HANDLERS[handle] ?? handle) + tagPercentDecode(rawTag.slice(handle.length));
}
var NO_RANGE$2 = -1;
var MERGE_TAG_NAME = "tag:yaml.org,2002:merge";
var DEFAULT_CONSTRUCTOR_OPTIONS = {
  filename: "",
  schema: CORE_SCHEMA,
  json: false,
  maxTotalMergeKeys: 1e4,
  maxAliases: -1
};
function eventPosition$1(event) {
  if ("tagStart" in event && event.tagStart !== NO_RANGE$2) return event.tagStart;
  if ("anchorStart" in event && event.anchorStart !== NO_RANGE$2) return event.anchorStart;
  if ("valueStart" in event && event.valueStart !== NO_RANGE$2) return event.valueStart;
  if ("start" in event) return event.start;
  return 0;
}
function throwError$1(state, message) {
  YAMLException.throwAt(state.source, state.position, message, state.filename);
}
function finalizeCollection(state, position, tag, carrier) {
  try {
    return tag.finalize(carrier);
  } catch (error) {
    if (error instanceof YAMLException) throw error;
    YAMLException.throwAt(state.source, position, error instanceof Error ? error.message : String(error), state.filename);
  }
}
function constructScalar(state, event) {
  const source = getScalarValue(state.source, event);
  const rawTag = event.tagStart === NO_RANGE$2 ? "" : state.source.slice(event.tagStart, event.tagEnd);
  const strTag2 = state.schema.defaultScalarTag;
  if (rawTag !== "") {
    if (rawTag === "!") return {
      value: source,
      tag: strTag2
    };
    const tagName = tagNameFull(rawTag, state.tagHandlers);
    const scalarTag = state.schema.lookupScalarTag(tagName);
    if (scalarTag) {
      const result = scalarTag.resolve(source, true, tagName);
      if (result === NOT_RESOLVED) throwError$1(state, `cannot resolve a node with !<${tagName}> explicit tag`);
      return {
        value: result,
        tag: scalarTag
      };
    }
    const collectionTagDef = state.schema.lookupMappingTag(tagName) ?? state.schema.lookupSequenceTag(tagName);
    if (collectionTagDef) {
      if (source !== "") throwError$1(state, `cannot resolve a node with !<${tagName}> explicit tag`);
      const carrier = collectionTagDef.create(tagName);
      return {
        value: collectionTagDef.carrierIsResult ? carrier : finalizeCollection(state, state.position, collectionTagDef, carrier),
        tag: collectionTagDef
      };
    }
    throwError$1(state, `unknown scalar tag !<${tagName}>`);
  }
  if (event.style === SCALAR_STYLE.PLAIN) return state.schema.resolveImplicitScalarTag(source);
  return {
    value: strTag2.resolve(source, false, strTag2.tagName),
    tag: strTag2
  };
}
function collectionTagName(state, event, defaultTagName) {
  const rawTag = event.tagStart === NO_RANGE$2 ? "" : state.source.slice(event.tagStart, event.tagEnd);
  return rawTag === "" || rawTag === "!" ? defaultTagName : tagNameFull(rawTag, state.tagHandlers);
}
function isMappingTag(tag) {
  return tag.nodeKind === "mapping";
}
function chargeMergeWork(state) {
  state.totalMergeKeys++;
  if (state.maxTotalMergeKeys !== -1 && state.totalMergeKeys > state.maxTotalMergeKeys) throwError$1(state, `merge keys exceeded maxTotalMergeKeys (${state.maxTotalMergeKeys})`);
}
function mergeKeys(state, frame, source, sourceTag) {
  chargeMergeWork(state);
  for (const sourceKey of sourceTag.keys(source)) {
    chargeMergeWork(state);
    if (frame.tag.has(frame.value, sourceKey)) continue;
    const err = frame.tag.addPair(frame.value, sourceKey, sourceTag.get(source, sourceKey));
    if (err) throwError$1(state, err);
    frame.overridable ??= /* @__PURE__ */ new Set();
    frame.overridable.add(sourceKey);
  }
}
function mergeSource(state, frame, source, sourceTag) {
  state.position = frame.keyPosition;
  if (isMappingTag(sourceTag)) mergeKeys(state, frame, source, sourceTag);
  else if (sourceTag.nodeKind === "sequence" && Array.isArray(source)) {
    if (source.length > 100) throwError$1(state, "abnormal merge sequence size");
    for (const element of source) {
      const elementTag = state.nodeTags.get(element);
      if (!elementTag) throwError$1(state, "cannot merge mappings; the provided source object is unacceptable");
      mergeKeys(state, frame, element, elementTag);
    }
  } else throwError$1(state, "cannot merge mappings; the provided source object is unacceptable");
}
function addMappingValue(state, frame, key, value, tag) {
  state.position = frame.keyPosition;
  if (frame.keyIsMerge) {
    mergeSource(state, frame, value, tag);
    return;
  }
  if (!state.json && frame.tag.has(frame.value, key) && !frame.overridable?.has(key)) throwError$1(state, "duplicated mapping key");
  const err = frame.tag.addPair(frame.value, key, value);
  if (err) throwError$1(state, err);
  frame.overridable?.delete(key);
}
function addValue(state, value, tag) {
  const frame = state.frames[state.frames.length - 1];
  if (frame.kind === "document") {
    frame.value = value;
    frame.hasValue = true;
  } else if (frame.kind === "sequence") {
    if (isMappingTag(tag)) state.nodeTags.set(value, tag);
    const err = frame.tag.addItem(frame.value, value, frame.index++);
    if (err) throwError$1(state, err);
  } else if (frame.hasKey) {
    const key = frame.key;
    frame.key = void 0;
    frame.hasKey = false;
    addMappingValue(state, frame, key, value, tag);
  } else {
    frame.key = value;
    frame.keyPosition = state.position;
    frame.hasKey = true;
    frame.keyIsMerge = tag.tagName === MERGE_TAG_NAME;
  }
}
function storeAnchor(state, event, value, tag, isValueFinal) {
  if (event.anchorStart !== NO_RANGE$2) {
    const anchor = {
      value,
      tag,
      isValueFinal
    };
    state.anchors.set(state.source.slice(event.anchorStart, event.anchorEnd), anchor);
    return anchor;
  }
  return null;
}
function constructFromEvents(events, options) {
  const state = {
    ...DEFAULT_CONSTRUCTOR_OPTIONS,
    ...options,
    events,
    documents: [],
    eventIndex: 0,
    position: 0,
    frames: [],
    anchors: /* @__PURE__ */ new Map(),
    nodeTags: /* @__PURE__ */ new Map(),
    tagHandlers: /* @__PURE__ */ Object.create(null),
    totalMergeKeys: 0,
    aliasCount: 0
  };
  while (state.eventIndex < state.events.length) {
    const event = state.events[state.eventIndex++];
    state.position = eventPosition$1(event);
    switch (event.type) {
      case EVENT_ID.DOCUMENT:
        state.anchors = /* @__PURE__ */ new Map();
        state.nodeTags = /* @__PURE__ */ new Map();
        state.aliasCount = 0;
        state.tagHandlers = /* @__PURE__ */ Object.create(null);
        for (const directive of event.directives) if (directive.kind === "tag") state.tagHandlers[directive.handle] = directive.prefix;
        state.frames.push({
          kind: "document",
          position: state.position,
          value: void 0,
          hasValue: false
        });
        break;
      case EVENT_ID.SCALAR: {
        const { value, tag } = constructScalar(state, event);
        storeAnchor(state, event, value, tag, true);
        addValue(state, value, tag);
        break;
      }
      case EVENT_ID.SEQUENCE: {
        const tagName = collectionTagName(state, event, "tag:yaml.org,2002:seq");
        const tag = state.schema.lookupSequenceTag(tagName);
        if (!tag) throwError$1(state, `unknown sequence tag !<${tagName}>`);
        const value = tag.create(tagName);
        const anchor = storeAnchor(state, event, value, tag, tag.carrierIsResult);
        state.frames.push({
          kind: "sequence",
          position: state.position,
          value,
          tag,
          anchor,
          index: 0
        });
        break;
      }
      case EVENT_ID.MAPPING: {
        const tagName = collectionTagName(state, event, "tag:yaml.org,2002:map");
        const tag = state.schema.lookupMappingTag(tagName);
        if (!tag) throwError$1(state, `unknown mapping tag !<${tagName}>`);
        const value = tag.create(tagName);
        const anchor = storeAnchor(state, event, value, tag, tag.carrierIsResult);
        state.frames.push({
          kind: "mapping",
          position: state.position,
          value,
          tag,
          anchor,
          key: void 0,
          keyPosition: state.position,
          hasKey: false,
          keyIsMerge: false,
          overridable: null
        });
        break;
      }
      case EVENT_ID.ALIAS: {
        if (state.maxAliases !== -1 && ++state.aliasCount > state.maxAliases) throwError$1(state, `aliases exceeded maxAliases (${state.maxAliases})`);
        const name = state.source.slice(event.anchorStart, event.anchorEnd);
        const anchor = state.anchors.get(name);
        if (!anchor) throwError$1(state, `unidentified alias "${name}"`);
        if (!anchor.isValueFinal) throwError$1(state, `recursive alias "${name}" is not supported for tag ${anchor.tag.tagName} because it uses finalize()`);
        addValue(state, anchor.value, anchor.tag);
        break;
      }
      case EVENT_ID.POP: {
        const frame = state.frames.pop();
        if (frame.kind === "mapping" && frame.hasKey) {
          state.position = frame.keyPosition;
          throwError$1(state, "incomplete mapping pair in event stream");
        }
        if (frame.kind === "document") state.documents.push(frame.value);
        else {
          const value = frame.tag.carrierIsResult ? frame.value : finalizeCollection(state, frame.position, frame.tag, frame.value);
          if (frame.anchor) {
            frame.anchor.value = value;
            frame.anchor.isValueFinal = true;
          }
          addValue(state, value, frame.tag);
        }
        break;
      }
    }
  }
  return state.documents;
}
var NO_RANGE$1 = -1;
var HAS_OWN = Object.prototype.hasOwnProperty;
var CONTEXT_FLOW_IN = 1;
var CONTEXT_FLOW_OUT = 2;
var CONTEXT_BLOCK_IN = 3;
var CONTEXT_BLOCK_OUT = 4;
var PATTERN_NON_PRINTABLE = /[\x00-\x08\x0B\x0C\x0E-\x1F\x7F-\x84\x86-\x9F\uFFFE\uFFFF]|[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF]/;
var PATTERN_FLOW_INDICATORS = /[,\[\]{}]/;
var PATTERN_TAG_HANDLE = /^(?:!|!!|![0-9A-Za-z-]+!)$/;
var NS_URI_CHAR = String.raw`(?:%[0-9A-Fa-f]{2}|[0-9A-Za-z\-#;/?:@&=+$,_.!~*'()\[\]])`;
var NS_TAG_CHAR = String.raw`(?:%[0-9A-Fa-f]{2}|[0-9A-Za-z\-#;/?:@&=+$.~*'()_])`;
var PATTERN_TAG_URI = new RegExp(`^(?:${NS_URI_CHAR})*$`);
var PATTERN_TAG_SUFFIX = new RegExp(`^(?:${NS_TAG_CHAR})+$`);
var PATTERN_TAG_PREFIX = new RegExp(`^(?:!(?:${NS_URI_CHAR})*|${NS_TAG_CHAR}(?:${NS_URI_CHAR})*)$`);
var DEFAULT_PARSER_OPTIONS = {
  filename: "",
  maxDepth: 100
};
function addDocumentEvent(state, explicitStart, explicitEnd) {
  state.events.push({
    type: EVENT_ID.DOCUMENT,
    explicitStart,
    explicitEnd,
    directives: state.directives
  });
}
function addSequenceEvent(state, start, anchorStart, anchorEnd, tagStart, tagEnd, style) {
  state.events.push({
    type: EVENT_ID.SEQUENCE,
    start,
    anchorStart,
    anchorEnd,
    tagStart,
    tagEnd,
    style
  });
}
function addMappingEvent(state, start, anchorStart, anchorEnd, tagStart, tagEnd, style) {
  state.events.push({
    type: EVENT_ID.MAPPING,
    start,
    anchorStart,
    anchorEnd,
    tagStart,
    tagEnd,
    style
  });
}
function insertFlowPairMappingEvent(state, snapshot) {
  state.events.splice(snapshot.eventsLength, 0, {
    type: EVENT_ID.MAPPING,
    start: snapshot.position,
    anchorStart: NO_RANGE$1,
    anchorEnd: NO_RANGE$1,
    tagStart: NO_RANGE$1,
    tagEnd: NO_RANGE$1,
    style: COLLECTION_STYLE.FLOW
  });
}
function addScalarEvent(state, valueStart, valueEnd, anchorStart, anchorEnd, tagStart, tagEnd, style, chomping = CHOMPING_MODE.CLIP, indent = -1, fast = false) {
  state.events.push({
    type: EVENT_ID.SCALAR,
    valueStart,
    valueEnd,
    anchorStart,
    anchorEnd,
    tagStart,
    tagEnd,
    style,
    chomping,
    indent,
    fast
  });
}
function addAliasEvent(state, anchorStart, anchorEnd) {
  state.events.push({
    type: EVENT_ID.ALIAS,
    anchorStart,
    anchorEnd
  });
}
function addPopEvent(state) {
  state.events.push({ type: EVENT_ID.POP });
}
function addEmptyScalarEvent(state) {
  addScalarEvent(state, NO_RANGE$1, NO_RANGE$1, NO_RANGE$1, NO_RANGE$1, NO_RANGE$1, NO_RANGE$1, SCALAR_STYLE.PLAIN);
}
function emptyProperties() {
  return {
    anchorStart: NO_RANGE$1,
    anchorEnd: NO_RANGE$1,
    tagStart: NO_RANGE$1,
    tagEnd: NO_RANGE$1
  };
}
function snapshotState(state) {
  return {
    position: state.position,
    line: state.line,
    lineStart: state.lineStart,
    lineIndent: state.lineIndent,
    firstTabInLine: state.firstTabInLine,
    eventsLength: state.events.length
  };
}
function restoreState(state, snapshot) {
  state.position = snapshot.position;
  state.line = snapshot.line;
  state.lineStart = snapshot.lineStart;
  state.lineIndent = snapshot.lineIndent;
  state.firstTabInLine = snapshot.firstTabInLine;
  state.events.length = snapshot.eventsLength;
}
function throwError(state, message) {
  YAMLException.throwAt(state.input.slice(0, state.length), state.position, message, state.filename);
}
function isEol(c) {
  return c === 10 || c === 13;
}
function isWhiteSpace(c) {
  return c === 9 || c === 32;
}
function isWsOrEol(c) {
  return isWhiteSpace(c) || isEol(c);
}
function isWsOrEolOrEnd(c) {
  return c === 0 || isWsOrEol(c);
}
function isFlowIndicator(c) {
  return c === 44 || c === 91 || c === 93 || c === 123 || c === 125;
}
function fromDecimalCode(c) {
  return c >= 48 && c <= 57 ? c - 48 : -1;
}
function fromHexCode(c) {
  if (c >= 48 && c <= 57) return c - 48;
  const lc = c | 32;
  if (lc >= 97 && lc <= 102) return lc - 97 + 10;
  return -1;
}
function escapedHexLen(c) {
  if (c === 120) return 2;
  if (c === 117) return 4;
  if (c === 85) return 8;
  return 0;
}
function isSimpleEscape(c) {
  return c === 48 || c === 97 || c === 98 || c === 116 || c === 9 || c === 110 || c === 118 || c === 102 || c === 114 || c === 101 || c === 32 || c === 34 || c === 47 || c === 92 || c === 78 || c === 95 || c === 76 || c === 80;
}
function consumeLineBreak(state) {
  if (state.input.charCodeAt(state.position) === 10) state.position++;
  else {
    state.position++;
    if (state.input.charCodeAt(state.position) === 10) state.position++;
  }
  state.line++;
  state.lineStart = state.position;
  state.lineIndent = 0;
  state.firstTabInLine = -1;
}
function skipSeparationSpace(state, allowComments) {
  let lineBreaks = 0;
  let ch = state.input.charCodeAt(state.position);
  let hasSeparation = state.position === state.lineStart || isWsOrEol(state.input.charCodeAt(state.position - 1));
  while (ch !== 0) {
    while (isWhiteSpace(ch)) {
      hasSeparation = true;
      if (ch === 9 && state.firstTabInLine === -1) state.firstTabInLine = state.position;
      ch = state.input.charCodeAt(++state.position);
    }
    if (allowComments && hasSeparation && ch === 35) do
      ch = state.input.charCodeAt(++state.position);
    while (!isEol(ch) && ch !== 0);
    if (!isEol(ch)) break;
    consumeLineBreak(state);
    lineBreaks++;
    hasSeparation = true;
    ch = state.input.charCodeAt(state.position);
    while (ch === 32) {
      state.lineIndent++;
      ch = state.input.charCodeAt(++state.position);
    }
  }
  return lineBreaks;
}
function testDocumentSeparator(state, position = state.position) {
  const ch = state.input.charCodeAt(position);
  if ((ch === 45 || ch === 46) && ch === state.input.charCodeAt(position + 1) && ch === state.input.charCodeAt(position + 2)) {
    const following = state.input.charCodeAt(position + 3);
    return following === 0 || isWsOrEol(following);
  }
  return false;
}
function skipByteOrderMark(state) {
  if (state.position === state.lineStart && state.input.charCodeAt(state.position) === 65279) {
    state.position++;
    state.lineStart = state.position;
  }
}
function testDocumentBoundary(state) {
  if (state.position !== state.lineStart) return false;
  if (testDocumentSeparator(state)) return true;
  if (state.input.charCodeAt(state.position) !== 65279) return false;
  const snapshot = snapshotState(state);
  skipByteOrderMark(state);
  skipSeparationSpace(state, true);
  const ch = state.input.charCodeAt(state.position);
  const result = state.position === state.lineStart && (ch === 37 || ch === 45 && testDocumentSeparator(state));
  restoreState(state, snapshot);
  return result;
}
function skipUntilLineEnd(state) {
  let ch = state.input.charCodeAt(state.position);
  while (ch !== 0 && !isEol(ch)) ch = state.input.charCodeAt(++state.position);
}
function checkPrintable(state, start, end) {
  const match = PATTERN_NON_PRINTABLE.exec(state.input.slice(start, end));
  if (match !== null) {
    state.position = start + match.index + match[0].length - 1;
    throwError(state, "the stream contains non-printable characters");
  }
}
function readTagProperty(state, props, inFlow) {
  if (state.input.charCodeAt(state.position) !== 33) return false;
  if (props.tagStart !== NO_RANGE$1) throwError(state, "duplication of a tag property");
  const start = state.position;
  let isVerbatim = false;
  let isNamed = false;
  let tagHandle = "!";
  let ch = state.input.charCodeAt(++state.position);
  if (ch === 60) {
    isVerbatim = true;
    ch = state.input.charCodeAt(++state.position);
  } else if (ch === 33) {
    isNamed = true;
    tagHandle = "!!";
    ch = state.input.charCodeAt(++state.position);
  }
  let suffixStart = state.position;
  let tagName;
  if (isVerbatim) {
    while (ch !== 0 && ch !== 62) ch = state.input.charCodeAt(++state.position);
    if (ch !== 62) throwError(state, "unexpected end of the stream within a verbatim tag");
    tagName = state.input.slice(suffixStart, state.position);
    state.position++;
  } else {
    while (ch !== 0 && !isWsOrEol(ch) && !(inFlow && isFlowIndicator(ch))) {
      if (ch === 33) {
        if (!isNamed) {
          tagHandle = state.input.slice(suffixStart - 1, state.position + 1);
          if (!PATTERN_TAG_HANDLE.test(tagHandle)) throwError(state, "named tag handle cannot contain such characters");
          isNamed = true;
          suffixStart = state.position + 1;
        } else throwError(state, "tag suffix cannot contain exclamation marks");
      }
      ch = state.input.charCodeAt(++state.position);
    }
    tagName = state.input.slice(suffixStart, state.position);
    if (PATTERN_FLOW_INDICATORS.test(tagName)) throwError(state, "tag suffix cannot contain flow indicator characters");
  }
  if (tagName && !(isVerbatim ? PATTERN_TAG_URI.test(tagName) : PATTERN_TAG_SUFFIX.test(tagName))) throwError(state, `tag name cannot contain such characters: ${tagName}`);
  if (!isVerbatim && tagHandle !== "!" && tagHandle !== "!!" && !HAS_OWN.call(state.tagHandlers, tagHandle)) throwError(state, `undeclared tag handle "${tagHandle}"`);
  props.tagStart = start;
  props.tagEnd = state.position;
  return true;
}
function readAnchorProperty(state, props) {
  if (state.input.charCodeAt(state.position) !== 38) return false;
  if (props.anchorStart !== NO_RANGE$1) throwError(state, "duplication of an anchor property");
  state.position++;
  const start = state.position;
  while (state.input.charCodeAt(state.position) !== 0 && !isWsOrEol(state.input.charCodeAt(state.position)) && !isFlowIndicator(state.input.charCodeAt(state.position))) state.position++;
  if (state.position === start) throwError(state, "name of an anchor node must contain at least one character");
  props.anchorStart = start;
  props.anchorEnd = state.position;
  return true;
}
function readAlias(state, props) {
  if (state.input.charCodeAt(state.position) !== 42) return false;
  if (props.anchorStart !== NO_RANGE$1 || props.tagStart !== NO_RANGE$1) throwError(state, "alias node should not have any properties");
  state.position++;
  const start = state.position;
  while (state.input.charCodeAt(state.position) !== 0 && !isWsOrEol(state.input.charCodeAt(state.position)) && !isFlowIndicator(state.input.charCodeAt(state.position))) state.position++;
  if (state.position === start) throwError(state, "name of an alias node must contain at least one character");
  addAliasEvent(state, start, state.position);
  return true;
}
function readFlowScalarBreak(state, nodeIndent) {
  skipSeparationSpace(state, false);
  if (state.lineIndent < nodeIndent) throwError(state, "deficient indentation");
}
function readSingleQuotedScalar(state, nodeIndent, props) {
  if (state.input.charCodeAt(state.position) !== 39) return false;
  state.position++;
  const start = state.position;
  let simple = true;
  while (state.input.charCodeAt(state.position) !== 0) {
    const ch = state.input.charCodeAt(state.position);
    if (ch === 39) {
      if (state.input.charCodeAt(state.position + 1) === 39) {
        simple = false;
        state.position += 2;
        continue;
      }
      const end = state.position;
      state.position++;
      addScalarEvent(state, start, end, props.anchorStart, props.anchorEnd, props.tagStart, props.tagEnd, SCALAR_STYLE.SINGLE_QUOTED, CHOMPING_MODE.CLIP, -1, simple);
      return true;
    }
    if (isEol(ch)) {
      simple = false;
      readFlowScalarBreak(state, nodeIndent);
    } else if (state.position === state.lineStart && testDocumentSeparator(state)) throwError(state, "unexpected end of the document within a single quoted scalar");
    else if (ch !== 9 && ch < 32) throwError(state, "expected valid JSON character");
    else state.position++;
  }
  throwError(state, "unexpected end of the stream within a single quoted scalar");
}
function readDoubleQuotedScalar(state, nodeIndent, props) {
  if (state.input.charCodeAt(state.position) !== 34) return false;
  state.position++;
  const start = state.position;
  let simple = true;
  while (state.input.charCodeAt(state.position) !== 0) {
    const ch = state.input.charCodeAt(state.position);
    if (ch === 34) {
      const end = state.position;
      state.position++;
      addScalarEvent(state, start, end, props.anchorStart, props.anchorEnd, props.tagStart, props.tagEnd, SCALAR_STYLE.DOUBLE_QUOTED, CHOMPING_MODE.CLIP, -1, simple);
      return true;
    }
    if (ch === 92) {
      simple = false;
      const escaped = state.input.charCodeAt(++state.position);
      if (isEol(escaped)) readFlowScalarBreak(state, nodeIndent);
      else if (isSimpleEscape(escaped)) state.position++;
      else {
        let hexLength = escapedHexLen(escaped);
        if (hexLength === 0) throwError(state, "unknown escape sequence");
        while (hexLength-- > 0) {
          state.position++;
          if (fromHexCode(state.input.charCodeAt(state.position)) < 0) throwError(state, "expected hexadecimal character");
        }
        state.position++;
      }
    } else if (isEol(ch)) {
      simple = false;
      readFlowScalarBreak(state, nodeIndent);
    } else if (state.position === state.lineStart && testDocumentSeparator(state)) throwError(state, "unexpected end of the document within a double quoted scalar");
    else if (ch !== 9 && ch < 32) throwError(state, "expected valid JSON character");
    else state.position++;
  }
  throwError(state, "unexpected end of the stream within a double quoted scalar");
}
function readBlockScalar(state, parentIndent, props) {
  const ch = state.input.charCodeAt(state.position);
  let chomping = CHOMPING_MODE.CLIP;
  let indent = -1;
  let detectedIndent = false;
  if (ch !== 124 && ch !== 62) return false;
  const style = ch === 124 ? SCALAR_STYLE.LITERAL_BLOCK : SCALAR_STYLE.FOLDED_BLOCK;
  state.position++;
  while (state.input.charCodeAt(state.position) !== 0) {
    const current = state.input.charCodeAt(state.position);
    const digit = fromDecimalCode(current);
    if (current === 43 || current === 45) {
      if (chomping !== CHOMPING_MODE.CLIP) throwError(state, "repeat of a chomping mode identifier");
      chomping = current === 43 ? CHOMPING_MODE.KEEP : CHOMPING_MODE.STRIP;
      state.position++;
    } else if (digit >= 0) {
      if (digit === 0) throwError(state, "bad explicit indentation width of a block scalar; it cannot be less than one");
      if (detectedIndent) throwError(state, "repeat of an indentation width identifier");
      indent = parentIndent + digit - 1;
      detectedIndent = true;
      state.position++;
    } else break;
  }
  let hadWhitespace = false;
  while (isWhiteSpace(state.input.charCodeAt(state.position))) {
    hadWhitespace = true;
    state.position++;
  }
  if (hadWhitespace && state.input.charCodeAt(state.position) === 35) skipUntilLineEnd(state);
  if (isEol(state.input.charCodeAt(state.position))) consumeLineBreak(state);
  else if (state.input.charCodeAt(state.position) !== 0) throwError(state, "a line break is expected");
  let contentIndent = detectedIndent ? indent : -1;
  let maxLeadingIndent = 0;
  const valueStart = state.position;
  let valueEnd = state.position;
  while (state.input.charCodeAt(state.position) !== 0) {
    const linePosition = state.position;
    let column = 0;
    while (state.input.charCodeAt(linePosition + column) === 32) column++;
    const first = state.input.charCodeAt(linePosition + column);
    if (first === 0) {
      if (contentIndent >= 0) {
        if (column > contentIndent) valueEnd = linePosition + column;
      } else if (column > 0) valueEnd = linePosition + column;
      break;
    }
    if (testDocumentBoundary(state)) break;
    if (!detectedIndent && contentIndent === -1 && isEol(first)) maxLeadingIndent = Math.max(maxLeadingIndent, column);
    if (!detectedIndent && contentIndent === -1 && !isEol(first)) {
      if (first === 9 && column < parentIndent) {
        state.position = linePosition + column;
        throwError(state, "tab characters must not be used in indentation");
      }
      if (column >= parentIndent && column < maxLeadingIndent) {
        state.position = linePosition + column;
        throwError(state, "bad indentation of a mapping entry");
      }
    }
    if (contentIndent === -1 && first !== 0 && !isEol(first) && column < parentIndent) {
      state.lineIndent = column;
      state.position = linePosition + column;
      break;
    }
    if (!detectedIndent && first !== 0 && !isEol(first) && contentIndent === -1) contentIndent = column;
    const requiredIndent = contentIndent === -1 ? parentIndent + 1 : contentIndent;
    if (first !== 0 && !isEol(first) && column < requiredIndent) {
      state.lineIndent = column;
      state.position = linePosition + column;
      break;
    }
    skipUntilLineEnd(state);
    valueEnd = state.position;
    if (isEol(state.input.charCodeAt(state.position))) {
      consumeLineBreak(state);
      valueEnd = state.position;
    }
  }
  checkPrintable(state, valueStart, valueEnd);
  addScalarEvent(state, valueStart, valueEnd, props.anchorStart, props.anchorEnd, props.tagStart, props.tagEnd, style, chomping, contentIndent);
  return true;
}
function canStartPlainScalar(state, nodeContext) {
  const ch = state.input.charCodeAt(state.position);
  const inFlow = nodeContext === CONTEXT_FLOW_IN;
  if (ch === 0 || isWsOrEol(ch) || ch === 35 || ch === 38 || ch === 42 || ch === 33 || ch === 124 || ch === 62 || ch === 39 || ch === 34 || ch === 37 || ch === 64 || ch === 96 || isFlowIndicator(ch)) return false;
  if (ch === 63 || ch === 45) {
    const following = state.input.charCodeAt(state.position + 1);
    if (isWsOrEolOrEnd(following) || inFlow && isFlowIndicator(following)) return false;
  }
  return true;
}
function readPlainScalar(state, nodeIndent, nodeContext, props) {
  if (!canStartPlainScalar(state, nodeContext)) return false;
  const start = state.position;
  let end = state.position;
  let ch = state.input.charCodeAt(state.position);
  const inFlow = nodeContext === CONTEXT_FLOW_IN;
  let multiline = false;
  while (ch !== 0) {
    if (testDocumentBoundary(state)) break;
    if (ch === 58) {
      const following = state.input.charCodeAt(state.position + 1);
      if (isWsOrEolOrEnd(following) || inFlow && isFlowIndicator(following)) break;
    } else if (ch === 35) {
      if (isWsOrEol(state.input.charCodeAt(state.position - 1))) break;
    } else if (inFlow && isFlowIndicator(ch)) break;
    else if (isEol(ch)) {
      const savedPosition = state.position;
      const savedLine = state.line;
      const savedLineStart = state.lineStart;
      const savedLineIndent = state.lineIndent;
      skipSeparationSpace(state, false);
      if (state.lineIndent >= nodeIndent) {
        multiline = true;
        ch = state.input.charCodeAt(state.position);
        continue;
      }
      state.position = savedPosition;
      state.line = savedLine;
      state.lineStart = savedLineStart;
      state.lineIndent = savedLineIndent;
      break;
    }
    if (!isWhiteSpace(ch)) end = state.position + 1;
    ch = state.input.charCodeAt(++state.position);
  }
  if (end === start) return false;
  checkPrintable(state, start, end);
  addScalarEvent(state, start, end, props.anchorStart, props.anchorEnd, props.tagStart, props.tagEnd, SCALAR_STYLE.PLAIN, CHOMPING_MODE.CLIP, -1, !multiline);
  return true;
}
function skipFlowSeparationSpace(state, nodeIndent) {
  const startLine = state.line;
  skipSeparationSpace(state, true);
  if (state.line > startLine && state.lineIndent < nodeIndent || state.firstTabInLine !== -1 && state.lineIndent < nodeIndent) throwError(state, "deficient indentation");
}
function readFlowCollection(state, nodeIndent, props) {
  const ch = state.input.charCodeAt(state.position);
  const isMapping = ch === 123;
  const start = state.position;
  let readNext = true;
  if (ch !== 91 && ch !== 123) return false;
  const terminator = isMapping ? 125 : 93;
  if (isMapping) addMappingEvent(state, start, props.anchorStart, props.anchorEnd, props.tagStart, props.tagEnd, COLLECTION_STYLE.FLOW);
  else addSequenceEvent(state, start, props.anchorStart, props.anchorEnd, props.tagStart, props.tagEnd, COLLECTION_STYLE.FLOW);
  state.position++;
  while (state.input.charCodeAt(state.position) !== 0) {
    skipFlowSeparationSpace(state, nodeIndent);
    let ch2 = state.input.charCodeAt(state.position);
    if (ch2 === terminator) {
      state.position++;
      addPopEvent(state);
      return true;
    } else if (!readNext) throwError(state, "missed comma between flow collection entries");
    else if (ch2 === 44) throwError(state, "expected the node content, but found ','");
    let isPair = false;
    let isExplicitPair = false;
    if (ch2 === 63 && isWsOrEol(state.input.charCodeAt(state.position + 1))) {
      isPair = isExplicitPair = true;
      state.position += 1;
      skipFlowSeparationSpace(state, nodeIndent);
    }
    const entryLine = state.line;
    const entryStart = snapshotState(state);
    const keyWasRead = parseNode(state, nodeIndent, CONTEXT_FLOW_IN, false, true);
    skipFlowSeparationSpace(state, nodeIndent);
    ch2 = state.input.charCodeAt(state.position);
    if ((isMapping || isExplicitPair || state.line === entryLine) && ch2 === 58) {
      isPair = true;
      state.position++;
      skipFlowSeparationSpace(state, nodeIndent);
      if (!isMapping) {
        insertFlowPairMappingEvent(state, entryStart);
        if (!keyWasRead) addEmptyScalarEvent(state);
      } else if (!keyWasRead) addEmptyScalarEvent(state);
      if (!parseNode(state, nodeIndent, CONTEXT_FLOW_IN, false, true)) addEmptyScalarEvent(state);
      skipFlowSeparationSpace(state, nodeIndent);
      if (!isMapping) addPopEvent(state);
    } else if (isMapping && isPair) {
      if (!keyWasRead) addEmptyScalarEvent(state);
      addEmptyScalarEvent(state);
    } else if (isMapping) addEmptyScalarEvent(state);
    else if (isPair) {
      insertFlowPairMappingEvent(state, entryStart);
      if (!keyWasRead) addEmptyScalarEvent(state);
      addEmptyScalarEvent(state);
      addPopEvent(state);
    }
    ch2 = state.input.charCodeAt(state.position);
    if (ch2 === 44) {
      readNext = true;
      state.position++;
    } else readNext = false;
  }
  throwError(state, "unexpected end of the stream within a flow collection");
}
function readBlockSequence(state, nodeIndent, props) {
  if (state.firstTabInLine !== -1 || state.input.charCodeAt(state.position) !== 45 || !isWsOrEolOrEnd(state.input.charCodeAt(state.position + 1))) return false;
  addSequenceEvent(state, state.position, props.anchorStart, props.anchorEnd, props.tagStart, props.tagEnd, COLLECTION_STYLE.BLOCK);
  while (state.input.charCodeAt(state.position) === 45 && isWsOrEolOrEnd(state.input.charCodeAt(state.position + 1))) {
    if (state.firstTabInLine !== -1) {
      state.position = state.firstTabInLine;
      throwError(state, "tab characters must not be used in indentation");
    }
    const entryLine = state.line;
    state.position++;
    const hadBreak = skipSeparationSpace(state, true) > 0;
    if (state.firstTabInLine !== -1 && state.input.charCodeAt(state.position) === 45 && isWsOrEolOrEnd(state.input.charCodeAt(state.position + 1))) throwError(state, "bad indentation of a sequence entry");
    if (hadBreak && state.lineIndent <= nodeIndent) addEmptyScalarEvent(state);
    else parseNode(state, nodeIndent, CONTEXT_BLOCK_IN, false, true);
    skipSeparationSpace(state, true);
    if (state.lineIndent < nodeIndent || state.position >= state.length) break;
    if (state.lineIndent > nodeIndent) throwError(state, "bad indentation of a sequence entry");
    if (state.line === entryLine && state.input.charCodeAt(state.position) === 45 && isWsOrEolOrEnd(state.input.charCodeAt(state.position + 1))) throwError(state, "bad indentation of a sequence entry");
  }
  addPopEvent(state);
  return true;
}
function readBlockMapping(state, nodeIndent, flowIndent, props) {
  let atExplicitKey = false;
  let detected = false;
  let mappingOpened = false;
  let pendingExplicitKey = false;
  if (state.firstTabInLine !== -1) return false;
  let ch = state.input.charCodeAt(state.position);
  while (ch !== 0) {
    if (!atExplicitKey && state.firstTabInLine !== -1) {
      state.position = state.firstTabInLine;
      throwError(state, "tab characters must not be used in indentation");
    }
    const following = state.input.charCodeAt(state.position + 1);
    const entryLine = state.line;
    if ((ch === 63 || ch === 58) && isWsOrEolOrEnd(following)) {
      if (!mappingOpened) {
        addMappingEvent(state, state.position, props.anchorStart, props.anchorEnd, props.tagStart, props.tagEnd, COLLECTION_STYLE.BLOCK);
        mappingOpened = true;
      }
      if (ch === 63) {
        if (atExplicitKey) addEmptyScalarEvent(state);
        detected = true;
        atExplicitKey = true;
      } else if (atExplicitKey) atExplicitKey = false;
      else {
        addEmptyScalarEvent(state);
        detected = true;
        atExplicitKey = false;
      }
      state.position += 1;
      pendingExplicitKey = true;
    } else {
      if (atExplicitKey) {
        addEmptyScalarEvent(state);
        atExplicitKey = false;
      }
      const beforeKey = snapshotState(state);
      if (!parseNode(state, flowIndent, CONTEXT_FLOW_OUT, false, true)) break;
      if (state.line === entryLine) {
        ch = state.input.charCodeAt(state.position);
        while (isWhiteSpace(ch)) ch = state.input.charCodeAt(++state.position);
        if (ch === 58) {
          ch = state.input.charCodeAt(++state.position);
          if (!isWsOrEolOrEnd(ch)) throwError(state, "a whitespace character is expected after the key-value separator within a block mapping");
          if (!mappingOpened) {
            state.events.splice(beforeKey.eventsLength, 0, {
              type: EVENT_ID.MAPPING,
              start: beforeKey.position,
              anchorStart: props.anchorStart,
              anchorEnd: props.anchorEnd,
              tagStart: props.tagStart,
              tagEnd: props.tagEnd,
              style: COLLECTION_STYLE.BLOCK
            });
            mappingOpened = true;
          }
          detected = true;
          atExplicitKey = false;
          pendingExplicitKey = false;
        } else if (detected) throwError(state, "expected ':' after a mapping key");
        else {
          if (props.anchorStart !== NO_RANGE$1 || props.tagStart !== NO_RANGE$1) {
            restoreState(state, beforeKey);
            return false;
          }
          return true;
        }
      } else if (detected) throwError(state, "can not read a block mapping entry; a multiline key may not be an implicit key");
      else {
        if (props.anchorStart !== NO_RANGE$1 || props.tagStart !== NO_RANGE$1) {
          restoreState(state, beforeKey);
          return false;
        }
        return true;
      }
    }
    if (parseNode(state, nodeIndent, CONTEXT_BLOCK_OUT, true, pendingExplicitKey)) pendingExplicitKey = false;
    if (!atExplicitKey) {
      if (pendingExplicitKey) {
        addEmptyScalarEvent(state);
        pendingExplicitKey = false;
      }
    }
    skipSeparationSpace(state, true);
    ch = state.input.charCodeAt(state.position);
    if ((state.line === entryLine || state.lineIndent > nodeIndent) && ch !== 0) throwError(state, "bad indentation of a mapping entry");
    else if (state.lineIndent < nodeIndent) break;
  }
  if (!detected) return false;
  if (atExplicitKey) addEmptyScalarEvent(state);
  if (mappingOpened) addPopEvent(state);
  return true;
}
function parseNode(state, parentIndent, nodeContext, allowToSeek, allowCompact, allowPropertyMapping = true) {
  if (state.depth >= state.maxDepth) throwError(state, `nesting exceeded maxDepth (${state.maxDepth})`);
  state.depth++;
  let indentStatus = 1;
  let atNewLine = false;
  let hasContent = false;
  let propertyStart = null;
  const props = emptyProperties();
  let allowBlockScalars = nodeContext === CONTEXT_BLOCK_OUT || nodeContext === CONTEXT_BLOCK_IN;
  let allowBlockCollections = allowBlockScalars;
  const allowBlockStyles = allowBlockScalars;
  if (allowToSeek && skipSeparationSpace(state, true)) {
    atNewLine = true;
    if (state.lineIndent > parentIndent) indentStatus = 1;
    else if (state.lineIndent === parentIndent) indentStatus = 0;
    else indentStatus = -1;
  }
  if (indentStatus === 1) while (true) {
    const ch = state.input.charCodeAt(state.position);
    const propertyState = snapshotState(state);
    if (atNewLine && indentStatus !== 1 && (ch === 33 || ch === 38)) break;
    if (atNewLine && allowBlockStyles && (props.tagStart !== NO_RANGE$1 || props.anchorStart !== NO_RANGE$1) && (ch === 33 || ch === 38)) {
      const fallbackState = snapshotState(state);
      const flowIndent = parentIndent + 1;
      if (readBlockMapping(state, state.position - state.lineStart, flowIndent, props) && state.events[fallbackState.eventsLength]?.type === EVENT_ID.MAPPING) {
        state.depth--;
        return true;
      }
      restoreState(state, fallbackState);
    }
    if (atNewLine && (ch === 33 && props.tagStart !== NO_RANGE$1 || ch === 38 && props.anchorStart !== NO_RANGE$1)) break;
    if (!readTagProperty(state, props, nodeContext === CONTEXT_FLOW_IN) && !readAnchorProperty(state, props)) break;
    if (propertyStart === null) propertyStart = propertyState;
    if (skipSeparationSpace(state, true)) {
      atNewLine = true;
      allowBlockCollections = allowBlockStyles;
      if (state.lineIndent > parentIndent) indentStatus = 1;
      else if (state.lineIndent === parentIndent) indentStatus = 0;
      else indentStatus = -1;
    } else allowBlockCollections = false;
  }
  if (allowBlockCollections) allowBlockCollections = atNewLine || allowCompact;
  if (indentStatus === 1 || nodeContext === CONTEXT_BLOCK_OUT) {
    const flowIndent = nodeContext === CONTEXT_FLOW_IN || nodeContext === CONTEXT_FLOW_OUT ? parentIndent : parentIndent + 1;
    const blockIndent = state.position - state.lineStart;
    if (indentStatus === 1) {
      if (allowBlockCollections && (readBlockSequence(state, blockIndent, props) || readBlockMapping(state, blockIndent, flowIndent, props)) || readFlowCollection(state, flowIndent, props)) hasContent = true;
      else {
        const ch = state.input.charCodeAt(state.position);
        if (propertyStart !== null && allowPropertyMapping && allowBlockStyles && !allowBlockCollections && ch !== 124 && ch !== 62) {
          const fallbackState = snapshotState(state);
          const propertyIndent = propertyStart.position - propertyStart.lineStart;
          restoreState(state, propertyStart);
          if (readBlockMapping(state, propertyIndent, flowIndent, emptyProperties()) && state.events[fallbackState.eventsLength]?.type === EVENT_ID.MAPPING) hasContent = true;
          else restoreState(state, fallbackState);
        }
        if (!hasContent && (allowBlockScalars && readBlockScalar(state, flowIndent, props) || readSingleQuotedScalar(state, flowIndent, props) || readDoubleQuotedScalar(state, flowIndent, props) || readAlias(state, props) || readPlainScalar(state, flowIndent, nodeContext, props))) hasContent = true;
      }
    } else if (indentStatus === 0) hasContent = allowBlockCollections && readBlockSequence(state, blockIndent, props);
  }
  allowBlockScalars = allowBlockScalars && !hasContent;
  if (!hasContent && (props.anchorStart !== NO_RANGE$1 || props.tagStart !== NO_RANGE$1 || allowBlockScalars)) {
    addScalarEvent(state, NO_RANGE$1, NO_RANGE$1, props.anchorStart, props.anchorEnd, props.tagStart, props.tagEnd, SCALAR_STYLE.PLAIN);
    hasContent = true;
  }
  state.depth--;
  return hasContent || props.anchorStart !== NO_RANGE$1 || props.tagStart !== NO_RANGE$1;
}
function readDirective(state) {
  if (state.lineIndent > 0 || state.input.charCodeAt(state.position) !== 37) return false;
  state.position++;
  const nameStart = state.position;
  while (state.input.charCodeAt(state.position) !== 0 && !isWsOrEol(state.input.charCodeAt(state.position))) state.position++;
  const name = state.input.slice(nameStart, state.position);
  const args = [];
  if (name.length === 0) throwError(state, "directive name must not be less than one character in length");
  while (state.input.charCodeAt(state.position) !== 0 && !isEol(state.input.charCodeAt(state.position))) {
    while (isWhiteSpace(state.input.charCodeAt(state.position))) state.position++;
    if (state.input.charCodeAt(state.position) === 35 || isEol(state.input.charCodeAt(state.position)) || state.input.charCodeAt(state.position) === 0) break;
    const start = state.position;
    while (state.input.charCodeAt(state.position) !== 0 && !isWsOrEol(state.input.charCodeAt(state.position))) state.position++;
    args.push(state.input.slice(start, state.position));
  }
  if (isEol(state.input.charCodeAt(state.position))) consumeLineBreak(state);
  if (name === "YAML") {
    if (state.directives.some((directive) => directive.kind === "yaml")) throwError(state, "duplication of %YAML directive");
    if (args.length !== 1) throwError(state, "YAML directive accepts exactly one argument");
    const match = /^([0-9]+)\.([0-9]+)$/.exec(args[0]);
    if (match === null) throwError(state, "ill-formed argument of the YAML directive");
    if (parseInt(match[1], 10) !== 1) throwError(state, "unacceptable YAML version of the document");
    state.directives.push({
      kind: "yaml",
      version: args[0]
    });
  } else if (name === "TAG") {
    if (args.length !== 2) throwError(state, "TAG directive accepts exactly two arguments");
    const [handle, prefix2] = args;
    if (!PATTERN_TAG_HANDLE.test(handle)) throwError(state, "ill-formed tag handle (first argument) of the TAG directive");
    if (HAS_OWN.call(state.tagHandlers, handle)) throwError(state, `there is a previously declared suffix for "${handle}" tag handle`);
    if (!PATTERN_TAG_PREFIX.test(prefix2)) throwError(state, "ill-formed tag prefix (second argument) of the TAG directive");
    state.tagHandlers[handle] = prefix2;
    state.directives.push({
      kind: "tag",
      handle,
      prefix: prefix2
    });
  }
  return true;
}
function readDocument(state) {
  state.directives = [];
  state.tagHandlers = /* @__PURE__ */ Object.create(null);
  let hasDirectives = false;
  skipSeparationSpace(state, true);
  while (readDirective(state)) {
    hasDirectives = true;
    skipSeparationSpace(state, true);
  }
  let explicitStart = false;
  let explicitEnd = false;
  let allowCompact = true;
  if (state.lineIndent === 0 && state.input.charCodeAt(state.position) === 45 && state.input.charCodeAt(state.position + 1) === 45 && state.input.charCodeAt(state.position + 2) === 45 && isWsOrEolOrEnd(state.input.charCodeAt(state.position + 3))) {
    explicitStart = true;
    const markerLine = state.line;
    state.position += 3;
    skipSeparationSpace(state, true);
    allowCompact = state.line > markerLine;
  } else if (hasDirectives) throwError(state, "directives end mark is expected");
  const documentEventIndex = state.events.length;
  if (!explicitStart && state.position === state.lineStart && state.input.charCodeAt(state.position) === 46 && testDocumentSeparator(state)) {
    state.position += 3;
    skipSeparationSpace(state, true);
    return;
  }
  addDocumentEvent(state, explicitStart, false);
  if (!parseNode(state, state.lineIndent - 1, CONTEXT_BLOCK_OUT, false, allowCompact, allowCompact)) addEmptyScalarEvent(state);
  skipSeparationSpace(state, true);
  if (state.position === state.lineStart && testDocumentSeparator(state)) {
    explicitEnd = state.input.charCodeAt(state.position) === 46;
    if (explicitEnd) {
      const markerLine = state.line;
      state.position += 3;
      skipSeparationSpace(state, true);
      if (state.line === markerLine && state.position < state.length) throwError(state, "end of the stream or a document separator is expected");
    }
  }
  const documentEvent = state.events[documentEventIndex];
  if (documentEvent?.type === EVENT_ID.DOCUMENT) documentEvent.explicitEnd = explicitEnd;
  addPopEvent(state);
  if (!explicitEnd && state.position < state.length && !testDocumentBoundary(state)) throwError(state, "end of the stream or a document separator is expected");
}
function parseEvents(input, options) {
  const length = input.length;
  const state = {
    ...DEFAULT_PARSER_OPTIONS,
    ...options,
    input: `${input}\0`,
    length,
    position: 0,
    line: 0,
    lineStart: 0,
    lineIndent: 0,
    firstTabInLine: -1,
    depth: 0,
    directives: [],
    tagHandlers: /* @__PURE__ */ Object.create(null),
    events: []
  };
  const nullpos = input.indexOf("\0");
  if (nullpos !== -1) YAMLException.throwAt(input, nullpos, "null byte is not allowed in input", state.filename);
  while (state.position < state.length) {
    skipByteOrderMark(state);
    skipSeparationSpace(state, true);
    if (state.position >= state.length) break;
    const documentStart = state.position;
    readDocument(state);
    if (state.position === documentStart)
      throwError(state, "can not read a document");
  }
  return state.events;
}
var DEFAULT_LOAD_OPTIONS = {
  ...DEFAULT_PARSER_OPTIONS,
  ...DEFAULT_CONSTRUCTOR_OPTIONS
};
function loadDocuments(input, options = {}) {
  const opts = {
    ...DEFAULT_LOAD_OPTIONS,
    ...options
  };
  const source = String(input);
  const PARSER_OPT_KEYS = Object.keys(DEFAULT_PARSER_OPTIONS);
  const CONSTRUCTOR_OPT_KEYS = Object.keys(DEFAULT_CONSTRUCTOR_OPTIONS);
  return constructFromEvents(parseEvents(source, pick(opts, PARSER_OPT_KEYS)), {
    ...pick(opts, CONSTRUCTOR_OPT_KEYS),
    source
  });
}
function load(input, options) {
  const documents = loadDocuments(input, options);
  if (documents.length === 0) throw new YAMLException("expected a document, but the input is empty");
  if (documents.length === 1) return documents[0];
  throw new YAMLException("expected a single document in the stream, but found more");
}
function hasBit(mask, bit) {
  return (mask & 1 << bit) !== 0;
}
var DEFAULT_SCALAR_STYLE_RULES = {
  applyQuoteFlowKeysOption,
  doubleQuoteForInvisibles,
  doubleQuoteWhitespaceOnly,
  applyForceQuotesOption,
  tryLongOrMultilineAsBlock,
  quoteInvalidPlain,
  fallbackToDoubleQuoted
};
function _preferredQuotedStyle(layout) {
  if (layout.presenterOptions.quoteStyle === "single" && hasBit(layout.allowedStylesMask, SCALAR_STYLE.SINGLE_QUOTED)) return SCALAR_STYLE.SINGLE_QUOTED;
  return SCALAR_STYLE.DOUBLE_QUOTED;
}
function applyQuoteFlowKeysOption(layout) {
  if (!layout.presenterOptions.quoteFlowKeys) return;
  if (!layout.isKey || !layout.flowOnly || layout.style !== SCALAR_STYLE.PLAIN) return;
  layout.style = SCALAR_STYLE.DOUBLE_QUOTED;
}
function doubleQuoteForInvisibles(layout) {
  if (layout.style === SCALAR_STYLE.PLAIN && /[\t\x7F-\xA0\u2028\u2029\uFEFF\uFFFE\uFFFF]/.test(layout.node.value)) layout.style = SCALAR_STYLE.DOUBLE_QUOTED;
}
function doubleQuoteWhitespaceOnly(layout) {
  if (layout.style === SCALAR_STYLE.PLAIN && /^\s+$/.test(layout.node.value)) layout.style = SCALAR_STYLE.DOUBLE_QUOTED;
}
function applyForceQuotesOption(layout) {
  if (!layout.presenterOptions.forceQuotes) return;
  if (layout.isKey || layout.style !== SCALAR_STYLE.PLAIN) return;
  if (layout.node.tag !== layout.presenterOptions.schema.defaultScalarTag.tagName) return;
  layout.style = layout.node.value.includes("\n") ? SCALAR_STYLE.DOUBLE_QUOTED : _preferredQuotedStyle(layout);
}
function tryLongOrMultilineAsBlock(layout) {
  if (layout.style !== SCALAR_STYLE.PLAIN || layout.isKey) return;
  const value = layout.node.value;
  const multiline = value.indexOf("\n") !== -1;
  if (!hasBit(layout.allowedStylesMask, SCALAR_STYLE.LITERAL_BLOCK)) {
    if (multiline) layout.style = SCALAR_STYLE.DOUBLE_QUOTED;
    return;
  }
  const w = layout.presenterOptions.lineWidth;
  if (w === -1) {
    if (multiline) layout.style = SCALAR_STYLE.LITERAL_BLOCK;
    return;
  }
  const availableWidth = Math.max(Math.min(w, 40), w - layout.shiftOfContent);
  let position = 0;
  let shouldFold = false;
  while (position <= value.length) {
    let lineEnd = value.length;
    const nextLineBreak = value.indexOf("\n", position);
    if (nextLineBreak !== -1) lineEnd = nextLineBreak;
    const line = value.slice(position, lineEnd);
    if (line.length > availableWidth && line[0] !== " " && / [^ \t]/.test(line)) shouldFold = true;
    if (nextLineBreak === -1) break;
    position = nextLineBreak + 1;
  }
  if (shouldFold) layout.style = SCALAR_STYLE.FOLDED_BLOCK;
  else if (multiline) layout.style = SCALAR_STYLE.LITERAL_BLOCK;
}
function quoteInvalidPlain(layout) {
  if (layout.style === SCALAR_STYLE.PLAIN && !hasBit(layout.allowedStylesMask, SCALAR_STYLE.PLAIN)) layout.style = _preferredQuotedStyle(layout);
}
function fallbackToDoubleQuoted(layout) {
  if (!hasBit(layout.allowedStylesMask, layout.style)) layout.style = SCALAR_STYLE.DOUBLE_QUOTED;
}
var SRC_C_PRINTABLE = "[\\x09\\x0A\\x0D\\x20-\\x7E\\x85\\xA0-\\uD7FF\\uE000-\\uFFFD\\u{10000}-\\u{10FFFF}]";
var SRC_B_CHAR = "[\\n\\r]";
var SRC_C_BYTE_ORDER_MARK = "\\uFEFF";
var SRC_S_WHITE = "[ \\t]";
var SRC_NB_CHAR = `(?:(?!(?:${SRC_B_CHAR}|${SRC_C_BYTE_ORDER_MARK}))${SRC_C_PRINTABLE})`;
var SRC_NS_CHAR = `(?:(?!${SRC_S_WHITE})${SRC_NB_CHAR})`;
var SRC_NB_JSON = "[\\x09\\x20-\\uD7FF\\uE000-\\uFFFF\\u{10000}-\\u{10FFFF}]";
var SRC_C_INDICATOR = "[-?:,\\[\\]{}#&*!|>'\"%@`]";
var SRC_C_FLOW_INDICATOR = "[,\\[\\]{}]";
var SRC_NS_PLAIN_SAFE_FLOW_OUT = SRC_NS_CHAR;
var SRC_NS_PLAIN_SAFE_FLOW_IN = `(?:(?!${SRC_C_FLOW_INDICATOR})${SRC_NS_CHAR})`;
var SRC_NS_PLAIN_FIRST_FLOW_OUT = `(?:(?:(?!${SRC_C_INDICATOR})${SRC_NS_CHAR})|[?:-](?=${SRC_NS_PLAIN_SAFE_FLOW_OUT}))`;
var SRC_NS_PLAIN_FIRST_FLOW_IN = `(?:(?:(?!${SRC_C_INDICATOR})${SRC_NS_CHAR})|[?:-](?=${SRC_NS_PLAIN_SAFE_FLOW_IN}))`;
var SRC_NS_PLAIN_CHAR_FLOW_OUT = `(?:(?:(?![:#])${SRC_NS_PLAIN_SAFE_FLOW_OUT})|:(?=${SRC_NS_PLAIN_SAFE_FLOW_OUT}))#*`;
var SRC_NS_PLAIN_CHAR_FLOW_IN = `(?:(?:(?![:#])${SRC_NS_PLAIN_SAFE_FLOW_IN})|:(?=${SRC_NS_PLAIN_SAFE_FLOW_IN}))#*`;
var SRC_NB_NS_PLAIN_IN_LINE_FLOW_OUT = `(?:${SRC_S_WHITE}*${SRC_NS_PLAIN_CHAR_FLOW_OUT})*`;
var SRC_NB_NS_PLAIN_IN_LINE_FLOW_IN = `(?:${SRC_S_WHITE}*${SRC_NS_PLAIN_CHAR_FLOW_IN})*`;
var SRC_NS_PLAIN_ONE_LINE_FLOW_OUT = `${SRC_NS_PLAIN_FIRST_FLOW_OUT}#*${SRC_NB_NS_PLAIN_IN_LINE_FLOW_OUT}`;
var SRC_NS_PLAIN_ONE_LINE_FLOW_IN = `${SRC_NS_PLAIN_FIRST_FLOW_IN}#*${SRC_NB_NS_PLAIN_IN_LINE_FLOW_IN}`;
var SRC_NS_PLAIN_ONE_LINE_BLOCK_KEY = SRC_NS_PLAIN_ONE_LINE_FLOW_OUT;
var SRC_NS_PLAIN_ONE_LINE_FLOW_KEY = SRC_NS_PLAIN_ONE_LINE_FLOW_IN;
var SRC_S_NS_PLAIN_NEXT_LINE_FLOW_OUT = `\\n+${SRC_NS_PLAIN_CHAR_FLOW_OUT}${SRC_NB_NS_PLAIN_IN_LINE_FLOW_OUT}`;
var SRC_S_NS_PLAIN_NEXT_LINE_FLOW_IN = `\\n+${SRC_NS_PLAIN_CHAR_FLOW_IN}${SRC_NB_NS_PLAIN_IN_LINE_FLOW_IN}`;
var SRC_NS_PLAIN_MULTI_LINE_FLOW_OUT = `${SRC_NS_PLAIN_ONE_LINE_FLOW_OUT}(?:${SRC_S_NS_PLAIN_NEXT_LINE_FLOW_OUT})*`;
var SRC_NS_PLAIN_MULTI_LINE_FLOW_IN = `${SRC_NS_PLAIN_ONE_LINE_FLOW_IN}(?:${SRC_S_NS_PLAIN_NEXT_LINE_FLOW_IN})*`;
var NS_PLAIN_FLOW_OUT = new RegExp(`^(?:${SRC_NS_PLAIN_MULTI_LINE_FLOW_OUT})$`, "u");
var NS_PLAIN_FLOW_IN = new RegExp(`^(?:${SRC_NS_PLAIN_MULTI_LINE_FLOW_IN})$`, "u");
var NS_PLAIN_BLOCK_KEY = new RegExp(`^(?:${SRC_NS_PLAIN_ONE_LINE_BLOCK_KEY})$`, "u");
var NS_PLAIN_FLOW_KEY = new RegExp(`^(?:${SRC_NS_PLAIN_ONE_LINE_FLOW_KEY})$`, "u");
var NB_SINGLE_ONE_LINE = new RegExp(`^(?:${SRC_NB_JSON})*$`, "u");
var NB_SINGLE_MULTI_LINE = new RegExp(`^(?:${SRC_NB_JSON}|\\n)*$`, "u");
var BLOCK_SCALAR_CONTENT = new RegExp(`^(?:${SRC_NB_CHAR}|\\n)*$`, "u");
var DEFAULT_PRESENTER_OPTIONS = {
  indent: 2,
  seqNoIndent: false,
  seqInlineFirst: true,
  lineWidth: 80,
  flowBracketPadding: false,
  flowSkipCommaSpace: false,
  flowSkipColonSpace: false,
  quoteFlowKeys: false,
  quoteStyle: "single",
  forceQuotes: false,
  scalarStyleRules: Object.keys(DEFAULT_SCALAR_STYLE_RULES).map((name) => Reflect.get(DEFAULT_SCALAR_STYLE_RULES, name)),
  tagBeforeAnchor: false
};
var DEFAULT_DUMP_OPTIONS = {
  ...DEFAULT_PRESENTER_OPTIONS,
  schema: DUMP_SCHEMA,
  skipInvalid: false,
  noRefs: false,
  flowLevel: -1,
  sortKeys: false,
  transform: () => {
  }
};
var EVENT_DOCUMENT = EVENT_ID.DOCUMENT;
var EVENT_SEQUENCE = EVENT_ID.SEQUENCE;
var EVENT_MAPPING = EVENT_ID.MAPPING;
var EVENT_SCALAR = EVENT_ID.SCALAR;
var EVENT_ALIAS = EVENT_ID.ALIAS;
var EVENT_POP = EVENT_ID.POP;
var SCALAR_STYLE_PLAIN = SCALAR_STYLE.PLAIN;
var SCALAR_STYLE_SINGLE_QUOTED = SCALAR_STYLE.SINGLE_QUOTED;
var SCALAR_STYLE_DOUBLE_QUOTED = SCALAR_STYLE.DOUBLE_QUOTED;
var SCALAR_STYLE_LITERAL_BLOCK = SCALAR_STYLE.LITERAL_BLOCK;
var SCALAR_STYLE_FOLDED_BLOCK = SCALAR_STYLE.FOLDED_BLOCK;
var COLLECTION_STYLE_BLOCK = COLLECTION_STYLE.BLOCK;
var COLLECTION_STYLE_FLOW = COLLECTION_STYLE.FLOW;
var CHOMPING_CLIP = CHOMPING_MODE.CLIP;
var CHOMPING_STRIP = CHOMPING_MODE.STRIP;
var CHOMPING_KEEP = CHOMPING_MODE.KEEP;

// ../../_temp/work/toolchain/packages/policy-engine/src/slice-dsl.ts
var BARE_NAME_CHARS = /^[a-zA-Z0-9_/-]+$/;
var BRACKET_IDENT_CHAR_CLASS = "[a-zA-Z0-9_./~-]";
var BRACKET_IDENT_OR_GLOB = new RegExp(`^(?:${BRACKET_IDENT_CHAR_CLASS}|\\*)+$`);
var SliceParseError = class extends Error {
  constructor(input, position, message) {
    super(`SliceParseError at position ${position} of "${input}": ${message}`);
    this.input = input;
    this.position = position;
    this.name = "SliceParseError";
  }
  input;
  position;
};
function parseSlice(input) {
  const dot = input.indexOf(".");
  if (dot <= 0) {
    throw new SliceParseError(input, 0, "expected '<service>.<segments>.<action>'");
  }
  const service = input.slice(0, dot);
  if (!BARE_NAME_CHARS.test(service) || service.includes("/")) {
    throw new SliceParseError(input, 0, `invalid service name '${service}'`);
  }
  const cursor2 = { input, rest: input.slice(dot + 1), pos: dot + 1 };
  const segments = [];
  let i = 0;
  while (i < cursor2.rest.length) {
    const read = cursor2.rest[i] === "[" ? readBracketSegment(cursor2, i) : readBareToken(cursor2, i);
    if ("action" in read) return { service, path: segments, action: read.action };
    segments.push(read.segment);
    i = skipSeparator(cursor2, read.next);
  }
  throw new SliceParseError(input, input.length, "missing terminal action ('.R' or '.W')");
}
function readBracketSegment(cursor2, i) {
  const { input, rest, pos } = cursor2;
  const close = rest.indexOf("]", i);
  if (close < 0) {
    throw new SliceParseError(input, pos + i, "unterminated '['");
  }
  const inner = rest.slice(i + 1, close);
  if (inner.length === 0) {
    throw new SliceParseError(input, pos + i, "empty bracket");
  }
  return { segment: parseBracket(inner, input, pos + i + 1), next: close + 1 };
}
function readBareToken(cursor2, i) {
  const { input, rest, pos } = cursor2;
  let j = i;
  while (j < rest.length && rest[j] !== "." && rest[j] !== "[") j++;
  const tok = rest.slice(i, j);
  if (tok.length === 0) {
    throw new SliceParseError(input, pos + i, "empty segment ('..')");
  }
  if ((tok === "R" || tok === "W") && j === rest.length) return { action: tok };
  if (tok === "**") return { segment: { kind: "wild-rec" }, next: j };
  if (tok === "*") return { segment: { kind: "wild-one" }, next: j };
  if (BARE_NAME_CHARS.test(tok)) return { segment: { kind: "name", value: tok }, next: j };
  throw new SliceParseError(input, pos + i, `invalid segment name '${tok}'`);
}
function skipSeparator(cursor2, i) {
  const { input, rest, pos } = cursor2;
  if (i >= rest.length || rest[i] === "[") return i;
  if (rest[i] === ".") return i + 1;
  throw new SliceParseError(input, pos + i, `expected '.' or '[' after segment, got '${rest[i]}'`);
}
function parseBracket(inner, input, position) {
  if (inner === "*") return { kind: "wild-one" };
  if (inner === "**") return { kind: "wild-rec" };
  if (inner.includes(",")) {
    const values = inner.split(",").map((s) => s.trim());
    for (const v of values) {
      if (v.length === 0 || !BRACKET_IDENT_OR_GLOB.test(v)) {
        throw new SliceParseError(input, position, `invalid list entry '${v}'`);
      }
    }
    return { kind: "list", values };
  }
  if (!BRACKET_IDENT_OR_GLOB.test(inner)) {
    throw new SliceParseError(input, position, `invalid bracket content '${inner}'`);
  }
  return { kind: "ident", value: inner };
}

// ../../_temp/work/toolchain/packages/shared/src/wildcard.ts
var WILDCARD_ONE = Object.freeze({ kind: "one" });
var WILDCARD_ANY = Object.freeze({ kind: "any" });

// ../../_temp/work/toolchain/packages/policy-engine/src/slice-matcher.ts
var IDENT_VALUE = new RegExp(`^${BRACKET_IDENT_CHAR_CLASS}*$`);

// ../../_temp/work/toolchain/packages/policy-engine/src/risk-evaluator.ts
function fallbackRiskPrefix(service) {
  return `${service}.uncategorized-`;
}
function isCatchAllWritePattern(pattern) {
  return pattern.action === "W" && pattern.path.length === 1 && pattern.path[0].kind === "wild-rec";
}
function isFallbackEntry(entry, service, patterns) {
  if (entry.fallback !== void 0) return entry.fallback;
  if (entry.id.startsWith(fallbackRiskPrefix(service))) return true;
  const parsed = patterns ?? parsePatternsLeniently(entry);
  return parsed.some(isCatchAllWritePattern);
}
function hasCatchAllWritePattern(entry) {
  return parsePatternsLeniently(entry).some(isCatchAllWritePattern);
}
function fallbackEntriesOf(catalog) {
  return catalog.risks.filter((entry) => isFallbackEntry(entry, catalog.service));
}
function hasFallbackRisk(catalog) {
  return fallbackEntriesOf(catalog).length > 0;
}
function parsePatternsLeniently(entry) {
  const raw = typeof entry.matches === "string" ? [entry.matches] : entry.matches;
  const out = [];
  for (const pattern of raw) {
    try {
      out.push(parseSlice(pattern));
    } catch {
    }
  }
  return out;
}
function indexCatalog(catalog) {
  const seen = /* @__PURE__ */ new Set();
  const entries = catalog.risks.map((entry) => {
    if (seen.has(entry.id)) {
      throw new Error(`Duplicate risk id '${entry.id}' in catalog '${catalog.service}'`);
    }
    seen.add(entry.id);
    const rawPatterns = typeof entry.matches === "string" ? [entry.matches] : entry.matches;
    const patterns = rawPatterns.map((raw) => {
      let pattern;
      try {
        pattern = parseSlice(raw);
      } catch (e) {
        throw new Error(
          `Invalid 'matches' pattern in risk '${entry.id}' of service '${catalog.service}': ${e instanceof Error ? e.message : String(e)}`,
          { cause: e }
        );
      }
      if (pattern.service !== catalog.service) {
        throw new Error(
          `Risk '${entry.id}' declares pattern for service '${pattern.service}' but is in '${catalog.service}'s catalog`
        );
      }
      return pattern;
    });
    return { entry, patterns, fallback: isFallbackEntry(entry, catalog.service, patterns) };
  });
  return { service: catalog.service, entries };
}

// ../../_temp/work/toolchain/packages/shared/src/risk-id.ts
var SERVICE_ID_PATTERN = /^[a-z][a-z0-9]*(?:-[a-z][a-z0-9]*)*$/;
var ENV_LABEL_PATTERN = /^[a-z][a-z0-9-]*$/;
var RISK_ID_PATTERN = /^([a-z][a-z0-9]*(?:-[a-z][a-z0-9]*)*)(?:\[([a-z][a-z0-9-]*)\])?((?:\.[a-z][a-z0-9-]+)+)$/;
function parseRiskId(raw) {
  const m = RISK_ID_PATTERN.exec(raw);
  if (!m) return null;
  return { service: m[1], env: m[2] ?? null, name: m[3].slice(1) };
}
function isRiskId(raw) {
  return RISK_ID_PATTERN.test(raw);
}
function isServiceId(raw) {
  return SERVICE_ID_PATTERN.test(raw);
}
var WILDCARD_CHARS = /[*?]/;

// ../../_temp/work/toolchain/packages/policy-engine/src/risk-policy.ts
function prepareCatalog(catalog, options = {}) {
  const warn = options.warn ?? ((message) => console.warn(message));
  const indexed = indexCatalog(catalog);
  for (const { entry } of indexed.entries) {
    if (!isRiskId(entry.id)) {
      throw new Error(
        `Risk id '${entry.id}' in catalog '${catalog.service}' does not match expected format '<service>[<env>].<name>' or '<service>.<name>'`
      );
    }
  }
  if (!hasFallbackRisk(catalog)) {
    warn(
      `[risk-policy] catalog '${catalog.service}' has no '<service>.uncategorized-*' fallback risk \u2014 concrete slices not matching any catalog entry will silently produce empty risks_touched, which the runtime treats as 'deny' (safe-by-default). Add a fallback.`
    );
  }
  return indexed;
}

// ../../_temp/work/toolchain/packages/shared/src/domain.ts
var CREDENTIAL_KINDS = ["api-key", "oauth2", "ssh-key", "host"];
function isCredentialKind(raw) {
  return CREDENTIAL_KINDS.includes(raw);
}
var GATES = ["auto", "approval"];
function isGate(raw) {
  return GATES.includes(raw);
}

// ../../_temp/work/toolchain/packages/policy-engine/src/budget.ts
function isPositiveInteger(value) {
  return typeof value === "number" && Number.isInteger(value) && value >= 1;
}
function budgetIssues(entry) {
  const issues = [];
  if (!isPositiveInteger(entry.quota)) {
    issues.push({
      field: "quota",
      message: "expected a positive integer (no infinite budget, spec \xA73.2)"
    });
  }
  const rate = entry.rate_limit;
  if (!isRateLimitShape(rate)) {
    issues.push({ field: "rate_limit", message: "expected { max, window_seconds }" });
  } else {
    if (!isPositiveInteger(rate.max)) {
      issues.push({ field: "rate_limit.max", message: "expected a positive integer" });
    }
    if (!isPositiveInteger(rate.window_seconds)) {
      issues.push({ field: "rate_limit.window_seconds", message: "expected a positive integer" });
    }
  }
  if (typeof entry.gate !== "string" || !isGate(entry.gate)) {
    issues.push({ field: "gate", message: `expected one of ${GATES.join(" | ")}` });
  }
  return issues;
}
function isValidBudget(entry) {
  return budgetIssues(entry).length === 0;
}
function isRateLimitShape(x) {
  return typeof x === "object" && x !== null && !Array.isArray(x);
}

// ../../_temp/work/toolchain/packages/policy-engine/src/trust-level.ts
var ANYTHING_ELSE_MACRO_ACTION = "anything-else";

// ../../_temp/work/toolchain/packages/shared/src/brand.ts
var BRAND_PREFIX = "@vaubaan/plugin-sdk/";
function errorBrand(className) {
  return /* @__PURE__ */ Symbol.for(`${BRAND_PREFIX}${className}`);
}
function brandError(target, className) {
  Object.defineProperty(target, errorBrand(className), {
    value: true,
    enumerable: false,
    configurable: false,
    writable: false
  });
}
function hasErrorBrand(x, className) {
  if (typeof x !== "object" || x === null) return false;
  const record = x;
  return record[errorBrand(className)] === true && typeof record["message"] === "string";
}

// ../../_temp/work/toolchain/packages/shared/src/mcp.ts
var TOOL_NAME_SEPARATOR = "__";
function toolPrefixFor(serviceId) {
  return `${serviceId.replaceAll("-", "_")}${TOOL_NAME_SEPARATOR}`;
}
var UpstreamAuthError = class extends Error {
  upstreamStatus;
  constructor(message, status) {
    super(message);
    this.name = "UpstreamAuthError";
    this.upstreamStatus = status;
    brandError(this, "UpstreamAuthError");
  }
};
var CredentialRefusal = class extends UpstreamAuthError {
  constructor(message, status = 401) {
    super(message, status);
    this.name = "CredentialRefusal";
    brandError(this, "CredentialRefusal");
  }
};
var UpstreamHttpError = class extends Error {
  status;
  constructor(message, status) {
    super(message);
    this.name = "UpstreamHttpError";
    this.status = status;
    brandError(this, "UpstreamHttpError");
  }
};

// ../../_temp/work/toolchain/packages/shared/src/api-key.ts
var PREFIX_LEN = 8;
var SECRET_LEN = 32;
var API_KEY_PATTERN = new RegExp(
  `vbn_(live|test)_([A-Za-z0-9]{${PREFIX_LEN}})_[A-Za-z0-9]{${SECRET_LEN}}`
);

// ../../_temp/work/toolchain/packages/shared/src/risk.ts
var RISK_VECTOR_AXES = {
  reversibility: ["reversible", "costly", "irreversible"],
  blast: ["single", "env", "account", "bulk"],
  data: ["metadata", "data", "secret", "pii"],
  cost: ["free", "moderate", "unbounded"],
  visibility: ["internal", "team", "public"]
};

// ../../_temp/work/toolchain/packages/shared/src/data-model.ts
function validateDataModel(model) {
  const errors = [];
  for (const plane of model.planes) {
    const names = new Set(plane.entities.map((e) => e.name));
    for (const entity of plane.entities) {
      if (entity.parent === null) continue;
      if (!names.has(entity.parent)) {
        errors.push(
          `service '${model.service}' plane '${plane.slug}': entity '${entity.name}' has parent '${entity.parent}' which is not declared in this plane.`
        );
      }
    }
  }
  return errors;
}

// ../../_temp/work/toolchain/packages/plugin-sdk/src/guards.ts
function isRecord(x) {
  return typeof x === "object" && x !== null && !Array.isArray(x);
}
function isList(x) {
  return Array.isArray(x);
}

// ../../_temp/work/toolchain/packages/plugin-sdk/src/catalog-parse.ts
function child(ctx, key) {
  return { at: ctx.at ? `${ctx.at}.${key}` : key, issues: ctx.issues };
}
function scoped(ctx) {
  const own = [];
  return {
    at: ctx.at,
    issues: own,
    commit: () => {
      ctx.issues.push(...own);
      return own.length === 0;
    }
  };
}
function notAMapping(ctx) {
  ctx.issues.push(`${ctx.at}: expected a mapping`);
  return void 0;
}
function unknownKeys(rec, allowed, ctx) {
  for (const key of Object.keys(rec)) {
    if (!allowed.has(key)) ctx.issues.push(`${child(ctx, key).at}: unknown key`);
  }
}
function isPositiveInt(x) {
  return typeof x === "number" && Number.isInteger(x) && x > 0;
}
function isNonEmptyStringList(x) {
  return isList(x) && x.length > 0 && x.every((m) => typeof m === "string" && m.length > 0);
}
function normalizeDate(x) {
  if (x === void 0) return void 0;
  if (x instanceof Date && !Number.isNaN(x.getTime())) return x.toISOString().slice(0, 10);
  if (typeof x === "string" && /^\d{4}-\d{2}-\d{2}$/.test(x)) return x;
  return void 0;
}
function requireString(rec, key, ctx) {
  const v = rec[key];
  if (typeof v !== "string" || v.trim().length === 0) {
    ctx.issues.push(`${ctx.at}.${key}: expected a non-empty string`);
    return void 0;
  }
  return v;
}

// ../../_temp/work/toolchain/packages/plugin-sdk/src/catalog-risk-entry.ts
var RISK_KEYS = /* @__PURE__ */ new Set([
  "id",
  "label",
  "reason",
  "matches",
  "vector",
  "vector_overrides",
  "acceptable_in_envs",
  "caps",
  "infra_limits",
  "fallback",
  "deprecated",
  "replaced_by"
]);
var SCOPE_CAP_KEYS = [
  "temporal_window_days",
  "items_per_call_max",
  "bytes_per_call_max",
  "calls_per_minute_max",
  "calls_per_session_max"
];
var CAP_KEYS = new Set(SCOPE_CAP_KEYS);
var AXES = Object.keys(RISK_VECTOR_AXES);
var RETIRED_AXIS = "persistence";
function isAxisValue(axis, value) {
  const allowed = RISK_VECTOR_AXES[axis];
  return typeof value === "string" && allowed.includes(value);
}
function readAxis(raw, axis, out, ctx, required) {
  const allowed = RISK_VECTOR_AXES[axis];
  const value = raw[axis];
  if (value === void 0) {
    if (required) ctx.issues.push(`${ctx.at}.${axis}: missing (one of ${allowed.join(" | ")})`);
    return;
  }
  if (!isAxisValue(axis, value)) {
    ctx.issues.push(`${ctx.at}.${axis}: expected one of ${allowed.join(" | ")}`);
    return;
  }
  out[axis] = value;
}
function partialVectorFrom(raw, ctx, required) {
  if (!isRecord(raw)) {
    ctx.issues.push(`${ctx.at}: expected a mapping of the five risk axes`);
    return void 0;
  }
  const out = {};
  for (const axis of AXES) readAxis(raw, axis, out, ctx, required);
  for (const key of Object.keys(raw)) {
    if (key in RISK_VECTOR_AXES) continue;
    ctx.issues.push(
      key === RETIRED_AXIS ? `${ctx.at}.${key}: unknown axis (retired on 2026-11-13, spec gateway-risk-model \xA74.2: remove the line)` : `${ctx.at}.${key}: unknown axis`
    );
  }
  return out;
}
function isCompleteVector(vector) {
  return AXES.every((axis) => vector[axis] !== void 0);
}
function vectorFrom(raw, ctx) {
  const vector = partialVectorFrom(raw, ctx, true);
  return vector && isCompleteVector(vector) ? vector : void 0;
}
function vectorOverridesFrom(raw, ctx) {
  if (raw.vector_overrides === void 0) return void 0;
  const at = child(ctx, "vector_overrides");
  if (!isRecord(raw.vector_overrides)) {
    ctx.issues.push(`${at.at}: expected a mapping env \u2192 partial vector`);
    return void 0;
  }
  const overrides = {};
  for (const [env, value] of Object.entries(raw.vector_overrides)) {
    const envCtx = child(at, env);
    if (!ENV_LABEL_PATTERN.test(env)) ctx.issues.push(`${envCtx.at}: invalid env label`);
    const partial = partialVectorFrom(value, envCtx, false);
    if (partial) overrides[env] = partial;
  }
  return overrides;
}
function capsFrom(raw, ctx) {
  if (!isRecord(raw)) return notAMapping(ctx);
  unknownKeys(raw, CAP_KEYS, ctx);
  const caps = {};
  for (const key of SCOPE_CAP_KEYS) {
    const value = raw[key];
    if (value === void 0 && !(key in raw)) continue;
    if (isPositiveInt(value)) caps[key] = value;
    else ctx.issues.push(`${ctx.at}.${key}: expected a positive integer`);
  }
  return caps;
}
function riskIdFrom(raw, ctx, service) {
  const id3 = requireString(raw, "id", ctx);
  if (id3 === void 0) return void 0;
  const parsed = parseRiskId(id3);
  if (!parsed) {
    ctx.issues.push(
      `${ctx.at}.id '${id3}' does not match '<service>.<name>' or '<service>[<env>].<name>'`
    );
    return void 0;
  }
  if (service && parsed.service !== service) {
    ctx.issues.push(
      `${ctx.at}.id '${id3}' belongs to service '${parsed.service}', not '${service}'`
    );
    return void 0;
  }
  return id3;
}
function matchesFrom(raw, ctx) {
  const matches2 = raw.matches;
  if (typeof matches2 === "string" && matches2.length > 0) return matches2;
  if (isNonEmptyStringList(matches2)) return matches2;
  ctx.issues.push(`${ctx.at}.matches: expected a slice pattern or a non-empty list of patterns`);
  return void 0;
}
function acceptableEnvsFrom(raw, ctx) {
  const envs = raw.acceptable_in_envs;
  if (envs === void 0) return void 0;
  if (!isList(envs) || envs.length === 0) {
    ctx.issues.push(`${ctx.at}.acceptable_in_envs: expected a non-empty list of env labels`);
    return void 0;
  }
  const labels = [];
  envs.forEach((env, j) => {
    if (typeof env === "string" && ENV_LABEL_PATTERN.test(env)) labels.push(env);
    else ctx.issues.push(`${ctx.at}.acceptable_in_envs[${j}]: invalid env label`);
  });
  return labels;
}
function optionalBoolean(raw, key, ctx) {
  const value = raw[key];
  if (value === void 0 || typeof value === "boolean") return value;
  ctx.issues.push(`${ctx.at}.${key}: expected a boolean`);
  return void 0;
}
function replacedByFrom(raw, ctx) {
  const value = raw.replaced_by;
  if (value === void 0) return void 0;
  if (typeof value === "string" && isRiskId(value)) return value;
  ctx.issues.push(`${ctx.at}.replaced_by: expected a RiskId`);
  return void 0;
}
function riskFrom(raw, ctx, service) {
  if (!isRecord(raw)) return notAMapping(ctx);
  const own = scoped(ctx);
  unknownKeys(raw, RISK_KEYS, own);
  const id3 = riskIdFrom(raw, own, service);
  const label = requireString(raw, "label", own);
  const reason = requireString(raw, "reason", own);
  const matches2 = matchesFrom(raw, own);
  const vector = vectorFrom(raw.vector, child(own, "vector"));
  const vectorOverrides = vectorOverridesFrom(raw, own);
  const acceptableInEnvs = acceptableEnvsFrom(raw, own);
  const caps = raw.caps !== void 0 ? capsFrom(raw.caps, child(own, "caps")) : void 0;
  const infra = raw.infra_limits !== void 0 ? capsFrom(raw.infra_limits, child(own, "infra_limits")) : void 0;
  const fallback = optionalBoolean(raw, "fallback", own);
  const deprecated = optionalBoolean(raw, "deprecated", own);
  const replacedBy = replacedByFrom(raw, own);
  if (!own.commit() || !id3 || !label || !reason || !matches2 || !vector) return void 0;
  return {
    id: id3,
    label,
    reason,
    matches: matches2,
    vector,
    ...vectorOverrides ? { vector_overrides: vectorOverrides } : {},
    ...acceptableInEnvs ? { acceptable_in_envs: acceptableInEnvs } : {},
    ...caps ? { caps } : {},
    ...infra ? { infra_limits: infra } : {},
    ...fallback !== void 0 ? { fallback } : {},
    ...deprecated !== void 0 ? { deprecated } : {},
    ...replacedBy !== void 0 ? { replaced_by: replacedBy } : {}
  };
}

// ../../_temp/work/toolchain/packages/plugin-sdk/src/catalog-rules.ts
var RETIRED_PRESETS_ISSUE = "presets: presets were retired (ADR macro-actions-and-trust-levels-prefill-the-policy) ; group the risks in macro_actions and remove the presets key";
function semanticIssues(catalog, options = {}) {
  const issues = [];
  const requireFallback = options.requireFallback ?? true;
  const requireMacroActions = options.requireMacroActions ?? true;
  if (Object.hasOwn(catalog, "presets")) issues.push(RETIRED_PRESETS_ISSUE);
  issues.push(...fallbackIssues(catalog, { requireFallback }));
  issues.push(...wildcardIssues(catalog));
  issues.push(...macroActionIssues(catalog, { requireMacroActions }));
  return issues;
}
function macroActionIssues(catalog, options = {}) {
  const issues = [];
  const actions = catalog.macro_actions ?? [];
  if (actions.length === 0) {
    if (options.requireMacroActions ?? true) {
      issues.push(
        "macro_actions: every catalog groups its risks into macro-actions (ADR macro-actions-and-trust-levels-prefill-the-policy)"
      );
    }
    return issues;
  }
  const byId = new Map(catalog.risks.map((r) => [r.id, r]));
  const fallbackIds = new Set(fallbackEntriesOf(catalog).map((r) => r.id));
  const owner = /* @__PURE__ */ new Map();
  const actionIds = /* @__PURE__ */ new Set();
  actions.forEach((action, a) => {
    const at = `macro_actions[${a}]`;
    if (action.id === ANYTHING_ELSE_MACRO_ACTION)
      issues.push(`${at}.id '${action.id}' is the gateway's own macro-action for the fallback`);
    if (actionIds.has(action.id)) issues.push(`${at}.id '${action.id}' is declared twice`);
    actionIds.add(action.id);
    if (action.entries.length === 0) issues.push(`${at}.entries is empty`);
    action.entries.forEach((entry, e) => {
      const where = `${at}.entries[${e}]`;
      issues.push(
        ...budgetIssues({ ...entry, gate: "auto" }).map((i) => `${where}.${i.field}: ${i.message}`)
      );
      const risk = byId.get(entry.risk_id);
      if (!risk) {
        issues.push(
          `${where}.risk_id '${entry.risk_id}' is not an unqualified risk of the '${catalog.service}' catalog`
        );
        return;
      }
      if (fallbackIds.has(risk.id))
        issues.push(
          `${where}.risk_id '${entry.risk_id}' is the fallback, which belongs to no macro-action`
        );
      const previous = owner.get(entry.risk_id);
      if (previous !== void 0)
        issues.push(
          `${where}.risk_id '${entry.risk_id}' already belongs to macro-action '${previous}'`
        );
      else owner.set(entry.risk_id, action.id);
    });
  });
  for (const risk of catalog.risks) {
    if (fallbackIds.has(risk.id) || risk.deprecated === true || owner.has(risk.id)) continue;
    issues.push(`risks: '${risk.id}' belongs to no macro-action`);
  }
  return issues;
}
function fallbackIssues(catalog, options = {}) {
  const issues = [];
  const fallbacks = fallbackEntriesOf(catalog);
  const prefix2 = fallbackRiskPrefix(catalog.service);
  const catchAll = `${catalog.service}.**.W`;
  if (fallbacks.length === 0) {
    if (options.requireFallback ?? true) {
      issues.push(
        `missing fallback risk: declare a '${prefix2}*' entry matching '${catchAll}' with fallback: true (risk-model spec \xA74.3)`
      );
    }
    return issues;
  }
  if (fallbacks.length > 1) {
    issues.push(
      `fallback: exactly one fallback entry per catalog, found ${fallbacks.length} (${fallbacks.map((r) => `'${r.id}'`).join(", ")}) \u2014 only one entry may be flagged fallback: true or match '${catchAll}'`
    );
  }
  for (const entry of fallbacks) {
    const i = catalog.risks.indexOf(entry);
    if (!entry.id.startsWith(prefix2)) {
      issues.push(`risks[${i}].id '${entry.id}' is the fallback and must be named '${prefix2}*'`);
    }
    if (!hasCatchAllWritePattern(entry)) {
      issues.push(
        `risks[${i}].matches: the fallback '${entry.id}' must match the catch-all write '${catchAll}'`
      );
    }
  }
  return issues;
}
function fallbackFlagIssues(catalog) {
  return fallbackEntriesOf(catalog).filter((entry) => entry.fallback !== true).map((entry) => {
    const i = catalog.risks.indexOf(entry);
    return `risks[${i}].id '${entry.id}' is the fallback by convention only \u2014 set fallback: true on it`;
  });
}
function catalogWarnings(catalog) {
  return fallbackFlagIssues(catalog);
}
function wildcardIssues(catalog) {
  return riskIdWildcardIssues(catalog);
}
function riskIdWildcardIssues(catalog) {
  const issues = [];
  catalog.risks.forEach((risk, i) => {
    if (WILDCARD_CHARS.test(risk.id))
      issues.push(`risks[${i}].id '${risk.id}' contains a wildcard`);
  });
  return issues;
}

// ../../_temp/work/toolchain/packages/plugin-sdk/src/catalog-document.ts
var CATALOG_KEYS = /* @__PURE__ */ new Set([
  "service",
  "risks",
  "macro_actions",
  "catalog_version",
  "catalog_date"
]);
var CATALOG_KEYS_AND_RETIRED = /* @__PURE__ */ new Set([...CATALOG_KEYS, "presets"]);
var MACRO_ACTION_KEYS = /* @__PURE__ */ new Set(["id", "label", "description", "narrative", "entries"]);
var NARRATIVE_MAX_LENGTH = 600;
var MACRO_ENTRY_KEYS = /* @__PURE__ */ new Set(["risk_id", "quota", "rate_limit"]);
var RATE_LIMIT_KEYS = /* @__PURE__ */ new Set(["max", "window_seconds"]);
var MACRO_ACTION_ID_PATTERN = /^[a-z][a-z0-9-]*$/;
var DEPRECATED_SERVICE_KEY = "provider";
function withCurrentServiceKey(doc, issues) {
  if (!(DEPRECATED_SERVICE_KEY in doc)) return doc;
  const { [DEPRECATED_SERVICE_KEY]: deprecated, ...rest } = doc;
  if ("service" in doc) {
    issues.push(`${DEPRECATED_SERVICE_KEY}: the former name of service; write service only`);
    return rest;
  }
  return { ...rest, service: deprecated };
}
function structuralIssues(raw) {
  const issues = [];
  const doc = isRecord(raw) ? withCurrentServiceKey(raw, issues) : raw;
  if (!isRecord(doc))
    return {
      issues: ["document: expected a mapping with `service`, `risks` and `macro_actions`"]
    };
  const root2 = { at: "", issues };
  if ("presets" in doc) issues.push(RETIRED_PRESETS_ISSUE);
  unknownKeys(doc, CATALOG_KEYS_AND_RETIRED, root2);
  const service = serviceFrom(doc, root2);
  const catalogVersion = catalogVersionFrom(doc, root2);
  const catalogDate = catalogDateFrom(doc, root2);
  const declaredService = typeof doc.service === "string" ? doc.service : null;
  const risks = risksFrom(doc.risks, child(root2, "risks"), declaredService);
  const macroActions = macroActionsFrom(doc.macro_actions, child(root2, "macro_actions"));
  if (issues.length > 0 || service === void 0) return { issues };
  const catalog = {
    service,
    risks,
    macro_actions: macroActions,
    ...catalogVersion !== void 0 ? { catalog_version: catalogVersion } : {},
    ...catalogDate !== void 0 ? { catalog_date: catalogDate } : {}
  };
  return { catalog, issues };
}
function serviceFrom(doc, ctx) {
  const service = doc.service;
  if (typeof service === "string" && isServiceId(service)) return service;
  ctx.issues.push(`service: expected a lowercase slug such as 'github' or 'cloudflare-dns'`);
  return void 0;
}
function catalogVersionFrom(doc, ctx) {
  const version = doc.catalog_version;
  if (version === void 0) return void 0;
  if (isPositiveInt(version)) return version;
  ctx.issues.push("catalog_version: expected a positive integer");
  return void 0;
}
function catalogDateFrom(doc, ctx) {
  if (doc.catalog_date === void 0) return void 0;
  const date = normalizeDate(doc.catalog_date);
  if (date === void 0) ctx.issues.push("catalog_date: expected an ISO date (YYYY-MM-DD)");
  return date;
}
function risksFrom(raw, ctx, service) {
  if (!isList(raw) || raw.length === 0) {
    ctx.issues.push(`${ctx.at}: expected a non-empty list`);
    return [];
  }
  return raw.flatMap((item, i) => {
    const risk = riskFrom(item, { at: `${ctx.at}[${i}]`, issues: ctx.issues }, service);
    return risk ? [risk] : [];
  });
}
function macroEntryFrom(raw, ctx) {
  if (!isRecord(raw)) return notAMapping(ctx);
  unknownKeys(raw, MACRO_ENTRY_KEYS, ctx);
  if (isRecord(raw.rate_limit))
    unknownKeys(raw.rate_limit, RATE_LIMIT_KEYS, child(ctx, "rate_limit"));
  const riskId = requireString(raw, "risk_id", ctx);
  const budget = { quota: raw.quota, rate_limit: raw.rate_limit, gate: "auto" };
  for (const issue of budgetIssues(budget)) {
    ctx.issues.push(`${ctx.at}.${issue.field}: ${issue.message}`);
  }
  if (!riskId || !isValidBudget(budget)) return void 0;
  return {
    risk_id: riskId,
    quota: budget.quota,
    rate_limit: {
      max: budget.rate_limit.max,
      window_seconds: budget.rate_limit.window_seconds
    }
  };
}
function macroEntriesFrom(raw, ctx) {
  if (!isList(raw) || raw.length === 0) {
    ctx.issues.push(`${ctx.at}: expected a non-empty list`);
    return [];
  }
  return raw.flatMap((item, j) => {
    const entry = macroEntryFrom(item, { at: `${ctx.at}[${j}]`, issues: ctx.issues });
    return entry ? [entry] : [];
  });
}
function macroActionsFrom(raw, ctx) {
  if (raw === void 0) return [];
  if (!isList(raw)) {
    ctx.issues.push(`${ctx.at}: expected a list`);
    return [];
  }
  return raw.flatMap((item, i) => {
    const action = macroActionFrom(item, { at: `${ctx.at}[${i}]`, issues: ctx.issues });
    return action ? [action] : [];
  });
}
function macroActionFrom(raw, ctx) {
  if (!isRecord(raw)) return notAMapping(ctx);
  const own = scoped(ctx);
  unknownKeys(raw, MACRO_ACTION_KEYS, own);
  const id3 = requireString(raw, "id", own);
  if (id3 !== void 0 && !MACRO_ACTION_ID_PATTERN.test(id3))
    own.issues.push(`${own.at}.id '${id3}' must be a lowercase slug`);
  const label = requireString(raw, "label", own);
  const description = requireString(raw, "description", own);
  const narrative = narrativeFrom(raw, own);
  const entries = macroEntriesFrom(raw.entries, child(own, "entries"));
  if (!own.commit() || !id3 || !label || !description) return void 0;
  return narrative === void 0 ? { id: id3, label, description, entries } : { id: id3, label, description, narrative, entries };
}
function narrativeFrom(raw, ctx) {
  if (raw.narrative === void 0) return void 0;
  const narrative = requireString(raw, "narrative", ctx);
  if (narrative === void 0) return void 0;
  const text2 = narrative.trim();
  if (text2.length > NARRATIVE_MAX_LENGTH) {
    ctx.issues.push(
      `${ctx.at}.narrative: ${text2.length} characters, at most ${NARRATIVE_MAX_LENGTH} (spec \xA74.6)`
    );
    return void 0;
  }
  return text2;
}

// ../../_temp/work/toolchain/packages/plugin-sdk/src/catalog-loader.ts
var CatalogError = class extends Error {
  constructor(source, issues) {
    super(`Invalid risk catalog '${source}':
  - ${issues.join("\n  - ")}`);
    this.source = source;
    this.issues = issues;
    this.name = "CatalogError";
  }
  source;
  issues;
};
function parseCatalogYaml(text2, options = {}) {
  const source = options.source ?? "<inline>";
  let doc;
  try {
    doc = load(text2, { filename: source, schema: CORE_SCHEMA });
  } catch (e) {
    const detail = e instanceof YAMLException ? e.reason : errorMessage(e);
    throw new CatalogError(source, [`YAML syntax: ${detail}`]);
  }
  return validateCatalog(doc, { ...options, source });
}
function loadCatalogFile(path, options = {}) {
  const filePath = typeof path === "string" ? path : fileURLToPath(path);
  const text2 = readFileSync(filePath, "utf8");
  return parseCatalogYaml(text2, { source: filePath, ...options });
}
function validateCatalog(doc, options = {}) {
  const source = options.source ?? "<inline>";
  const structural = structuralIssues(doc);
  if (structural.issues.length > 0 || !structural.catalog) {
    throw new CatalogError(source, structural.issues);
  }
  const catalog = structural.catalog;
  const issues = [];
  let indexed;
  try {
    indexed = prepareCatalog(catalog, {
      warn: () => {
      }
    });
  } catch (e) {
    issues.push(errorMessage(e));
  }
  issues.push(...semanticIssues(catalog, options));
  if (issues.length > 0 || !indexed) throw new CatalogError(source, issues);
  const warn = options.warn ?? ((message) => console.warn(message));
  for (const warning of catalogWarnings(catalog))
    warn(`[plugin-sdk] catalog '${source}': ${warning}`);
  return { catalog, indexed };
}
function errorMessage(e) {
  return e instanceof Error ? e.message : String(e);
}

// ../../_temp/work/toolchain/packages/plugin-sdk/src/catalog-path.ts
import { dirname, join } from "node:path";
import { fileURLToPath as fileURLToPath2 } from "node:url";
var CATALOG_FILE_NAME = "risk-catalog.yaml";
function catalogPathNextTo(moduleUrl, fileName = CATALOG_FILE_NAME) {
  const url = typeof moduleUrl === "string" ? parseModuleUrl(moduleUrl) : moduleUrl;
  if (url.protocol !== "file:") {
    throw new Error(
      `catalogPathNextTo: expected a file: URL (import.meta.url), got '${url.href}' \u2014 a bundler rewrote the module URL; load the catalog from a plain filesystem path`
    );
  }
  return join(
    /* turbopackIgnore: true */
    dirname(fileURLToPath2(url)),
    fileName
  );
}
function parseModuleUrl(raw) {
  try {
    return new URL(raw);
  } catch {
    throw new Error(
      `catalogPathNextTo: '${raw}' is not a URL \u2014 pass import.meta.url, not a relative path`
    );
  }
}

// ../../_temp/work/toolchain/packages/plugin-sdk/src/arguments.ts
function declaredArgumentsOf(tools) {
  return new Map(
    tools.map((tool) => [tool.name, new Set(Object.keys(tool.inputSchema.properties ?? {}))])
  );
}
function undeclaredArgumentDenial(declared, tool, args, routing = NO_ROUTING_ARGUMENT) {
  const names = declared.get(tool);
  if (!names) return null;
  for (const [key, value] of Object.entries(args)) {
    if (value !== void 0 && !names.has(key) && !routing.has(key)) {
      return `${argumentLabel(key)}: not an argument of '${tool}' \u2014 nothing classifies it, so it is not sent.`;
    }
  }
  return null;
}
var NO_ROUTING_ARGUMENT = /* @__PURE__ */ new Set();
var ARGUMENT_NAME = /^[A-Za-z_][A-Za-z0-9_-]{0,63}$/;
function argumentLabel(key) {
  return ARGUMENT_NAME.test(key) ? key : "an argument with a malformed name";
}

// ../../_temp/work/toolchain/packages/plugin-sdk/src/slices.ts
var SLICE_IDENT = new RegExp(`^${BRACKET_IDENT_CHAR_CLASS}+$`);

// ../../_temp/work/toolchain/packages/plugin-sdk/src/refusal.ts
var ExecutorRefusal = class extends Error {
  constructor(message) {
    super(message);
    this.name = "ExecutorRefusal";
    brandError(this, "ExecutorRefusal");
  }
};
function isExecutorRefusal(x) {
  return hasErrorBrand(x, "ExecutorRefusal");
}
function refusalResult(message) {
  return { content: [{ type: "text", text: message }], isError: true };
}
async function declining(run2) {
  try {
    return await run2();
  } catch (error) {
    if (isExecutorRefusal(error)) return refusalResult(error.message);
    throw error;
  }
}

// ../../_temp/work/toolchain/packages/plugin-sdk/src/results.ts
function textResult(text2) {
  return { content: [{ type: "text", text: text2 }] };
}
function jsonResult(payload) {
  return textResult(JSON.stringify(payload, null, 2));
}

// ../../_temp/work/toolchain/packages/plugin-sdk/src/transport/errors.ts
var PROTOCOL_FAILURE_STATUS = 502;
var UpstreamProtocolError = class extends UpstreamHttpError {
  constructor(message, status = PROTOCOL_FAILURE_STATUS) {
    super(message, status);
    this.name = "UpstreamProtocolError";
    brandError(this, "UpstreamProtocolError");
  }
};
var UpstreamAnswerTooLarge = class extends UpstreamProtocolError {
  constructor(what, maxBytes) {
    super(`${what}: the service answered more than ${maxBytes} bytes; the answer was not read`);
    this.maxBytes = maxBytes;
    this.name = "UpstreamAnswerTooLarge";
  }
  maxBytes;
};

// ../../_temp/work/toolchain/packages/plugin-sdk/src/transport/read-bounded.ts
var DEFAULT_MAX_ANSWER_BYTES = 1e7;
async function readBounded(res, maxBytes, what = "the answer") {
  const declared = Number(res.headers.get("content-length") ?? Number.NaN);
  if (Number.isFinite(declared) && declared > maxBytes) {
    await res.body?.cancel().catch(() => void 0);
    throw new UpstreamAnswerTooLarge(what, maxBytes);
  }
  if (!res.body) return new Uint8Array(0);
  const reader = res.body.getReader();
  const chunks = [];
  let size = 0;
  try {
    for (; ; ) {
      const { done, value } = await reader.read();
      if (done) break;
      size += value.byteLength;
      if (size > maxBytes) {
        await reader.cancel().catch(() => void 0);
        throw new UpstreamAnswerTooLarge(what, maxBytes);
      }
      chunks.push(value);
    }
  } finally {
    reader.releaseLock();
  }
  const bytes = new Uint8Array(size);
  let at = 0;
  for (const chunk of chunks) {
    bytes.set(chunk, at);
    at += chunk.byteLength;
  }
  return bytes;
}
async function readBoundedText(res, maxBytes, what = "the answer") {
  return new TextDecoder().decode(await readBounded(res, maxBytes, what));
}
async function readPrefixText(res, maxBytes) {
  if (!res.body) return "";
  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let text2 = "";
  let size = 0;
  try {
    while (size < maxBytes) {
      const { done, value } = await reader.read();
      if (done) return text2 + decoder.decode();
      const room = maxBytes - size;
      const part = value.byteLength > room ? value.subarray(0, room) : value;
      size += part.byteLength;
      text2 += decoder.decode(part, { stream: true });
    }
    await reader.cancel().catch(() => void 0);
    return text2;
  } finally {
    reader.releaseLock();
  }
}

// ../../_temp/work/toolchain/packages/plugin-sdk/src/transport/shape.ts
function readShape(value, guard, what) {
  if (guard(value)) return value;
  throw new UpstreamProtocolError(`${what}: unexpected answer`);
}
function anyJson(value) {
  return value !== void 0;
}

// ../../_temp/work/toolchain/packages/plugin-sdk/src/transport/http.ts
var QUOTED_LENGTH = 300;
var FAILURE_READ_BYTES = QUOTED_LENGTH * 4;
async function httpJson(io, request2, guard) {
  const method = (request2.method ?? "GET").toUpperCase();
  const what = request2.what ?? `${method} ${describeUrl(request2.url)}`;
  const json = request2.body !== void 0;
  const body = request2.rawBody ?? (json ? JSON.stringify(request2.body) : void 0);
  const res = await io.fetch(request2.url, {
    method,
    redirect: "error",
    headers: {
      accept: "application/json",
      ...json ? { "content-type": "application/json" } : {},
      ...request2.headers
    },
    ...body !== void 0 ? { body } : {},
    ...io.signal ? { signal: io.signal } : {}
  });
  if (!res.ok) throw await upstreamFailure(res, what);
  const text2 = await readBoundedText(res, request2.maxBytes ?? DEFAULT_MAX_ANSWER_BYTES, what);
  return readShape(parseJson(text2, what), guard, what);
}
async function upstreamFailure(res, what) {
  const excerpt = await quotedExcerpt(res);
  const message = `${what} failed with HTTP ${res.status}${excerpt ? `: ${excerpt}` : ""}`;
  if (res.status === 401 || res.status === 403) return new UpstreamAuthError(message, res.status);
  return new UpstreamHttpError(message, res.status);
}
async function quotedExcerpt(res) {
  try {
    return (await readPrefixText(res, FAILURE_READ_BYTES)).trim().slice(0, QUOTED_LENGTH);
  } catch {
    return "";
  }
}
function parseJson(text2, what) {
  if (text2.trim() === "") return null;
  try {
    return JSON.parse(text2);
  } catch {
    throw new UpstreamProtocolError(`${what}: the answer is not JSON`);
  }
}
function describeUrl(url) {
  try {
    const parsed = new URL(url);
    return `${parsed.origin}${parsed.pathname}`;
  } catch {
    return "<invalid URL>";
  }
}

// ../../_temp/work/toolchain/packages/plugin-sdk/src/credential-issues.ts
var CREDENTIAL_SENTENCE_MAX_LENGTH = 300;
function credentialSpecIssues(spec, tools) {
  const at = "credential";
  const issues = kindSpecIssues(spec);
  if (!isRecord(spec) || typeof spec.kind !== "string") return issues;
  if (spec.kind === "api-key") {
    if (!isSentence(spec.label, CREDENTIAL_SENTENCE_MAX_LENGTH)) {
      issues.push(`${at}.label: expected what the person creates, in the service's words`);
    }
    if (typeof spec.verify !== "function") {
      issues.push(`${at}.verify: expected the check at paste, a function`);
    }
    if (!isHttpsUrl(spec.createUrl)) {
      issues.push(`${at}.createUrl: expected the https URL of the token page`);
    }
    issues.push(...guideIssues(spec.guide, tools, `${at}.guide`));
    if (spec.alternatives !== void 0) {
      issues.push(...alternativesIssues(spec.alternatives, spec.fields, `${at}.alternatives`));
    }
    issues.push(...screenshotsIssues(spec.guide, spec.alternatives, `${at}.guide.screenshots`));
  }
  return issues;
}
function screenshotsIssues(guide, alternatives, at) {
  if (!isRecord(guide)) return [];
  const steps = [
    ...isList(alternatives) ? alternatives.flatMap((alt) => isRecord(alt) && isList(alt.steps) ? alt.steps : []) : [],
    ...isList(guide.steps) ? guide.steps : []
  ];
  const named = /* @__PURE__ */ new Map();
  for (const step of steps) {
    if (isRecord(step) && typeof step.screenshot === "string") {
      named.set(step.screenshot, (named.get(step.screenshot) ?? 0) + 1);
    }
  }
  const declared = guide.screenshots;
  if (declared === void 0) {
    return [...named.keys()].map((file) => `${at}: '${file}' is named by a step but not declared`);
  }
  if (!isRecord(declared)) return [`${at}: expected { '<file>': { source, licence, taken, alt } }`];
  const issues = [];
  for (const [file, shot] of Object.entries(declared)) {
    const where = `${at}['${file}']`;
    if (!GUIDE_SCREENSHOT_FILE_PATTERN.test(file)) {
      issues.push(`${where}: expected a file name such as 'token-form.webp' (.png or .webp)`);
    }
    issues.push(...screenshotIssues(shot, where));
    const uses = named.get(file) ?? 0;
    if (uses === 0) issues.push(`${where}: declared but named by no step`);
    if (uses > 1) issues.push(`${where}: named by ${uses} steps, expected one`);
  }
  for (const file of named.keys()) {
    if (!Object.hasOwn(declared, file)) {
      issues.push(`${at}: '${file}' is named by a step but not declared`);
    }
  }
  return issues;
}
function screenshotIssues(shot, at) {
  if (!isRecord(shot)) return [`${at}: expected { source, licence, taken, alt }`];
  const issues = [];
  if (shot.source !== "ours" && !isHttpsUrl(shot.source)) {
    issues.push(`${at}.source: expected the https URL of the page it was taken from, or 'ours'`);
  }
  if (!SCREENSHOT_LICENCES.includes(shot.licence)) {
    issues.push(
      `${at}.licence: expected one of ${SCREENSHOT_LICENCES.join(" | ")} (a licence that forbids commercial use or changes never ships)`
    );
  } else if (shot.source === "ours" !== (shot.licence === "ours")) {
    issues.push(`${at}.licence: 'ours' goes with the source 'ours', and only with it`);
  }
  if (typeof shot.taken !== "string" || !SCREENSHOT_TAKEN_PATTERN.test(shot.taken)) {
    issues.push(`${at}.taken: expected the month it was taken, YYYY-MM`);
  }
  if (!isSentence(shot.alt, SCREENSHOT_ALT_MAX_LENGTH)) {
    issues.push(
      `${at}.alt: expected what the image shows, 1 to ${SCREENSHOT_ALT_MAX_LENGTH} characters`
    );
  }
  return issues;
}
function pathIssues(path, at) {
  if (!isList(path) || path.length === 0 || path.length > GUIDE_PATH_MAX_SEGMENTS) {
    return [`${at}: expected 1 to ${GUIDE_PATH_MAX_SEGMENTS} menu labels when present`];
  }
  return path.flatMap(
    (segment, i) => isSentence(segment, GUIDE_PATH_SEGMENT_MAX_LENGTH) ? [] : [`${at}[${i}]: expected a menu label of 1 to ${GUIDE_PATH_SEGMENT_MAX_LENGTH} characters`]
  );
}
function alternativesIssues(alternatives, fields, at) {
  if (!isList(alternatives) || alternatives.length < 2 || alternatives.length > CREDENTIAL_ALTERNATIVES_MAX) {
    return [`${at}: expected 2 to ${CREDENTIAL_ALTERNATIVES_MAX} alternatives`];
  }
  const declared = new Map(fields.map((f) => [f.name, f]));
  const owner = /* @__PURE__ */ new Map();
  const ids = /* @__PURE__ */ new Set();
  const issues = [];
  alternatives.forEach((alt, i) => {
    const where = `${at}[${i}]`;
    if (!isRecord(alt)) {
      issues.push(`${where}: expected { id, label, fields, steps }`);
      return;
    }
    if (typeof alt.id !== "string" || !CREDENTIAL_ALTERNATIVE_ID_PATTERN.test(alt.id)) {
      issues.push(`${where}.id: expected a lowercase slug such as 'team'`);
    } else if (ids.has(alt.id)) {
      issues.push(`${where}.id: '${alt.id}' is already the id of another alternative`);
    }
    ids.add(alt.id);
    if (!isSentence(alt.label, CREDENTIAL_SENTENCE_MAX_LENGTH)) {
      issues.push(`${where}.label: expected a few words`);
    }
    if (alt.help !== void 0 && !isSentence(alt.help, CREDENTIAL_SENTENCE_MAX_LENGTH)) {
      issues.push(`${where}.help: expected one sentence when present`);
    }
    issues.push(...stepIssues(alt.steps, `${where}.steps`));
    if (!isList(alt.fields) || alt.fields.length === 0) {
      issues.push(`${where}.fields: expected at least one field of its own`);
      return;
    }
    for (const name of alt.fields) {
      if (typeof name !== "string" || !declared.has(name)) {
        issues.push(`${where}.fields: '${String(name)}' is not a field of this spec`);
      } else if (owner.has(name)) {
        issues.push(`${where}.fields: '${name}' already belongs to another alternative`);
      } else {
        owner.set(name, i);
      }
    }
  });
  alternatives.forEach((alt, i) => {
    if (!isRecord(alt)) return;
    const asked = fields.filter((f) => !owner.has(f.name) || owner.get(f.name) === i);
    if (!asked.some((f) => f.secret)) {
      issues.push(`${at}[${i}]: asks for no secret field`);
    }
  });
  return issues;
}
function guideIssues(guide, tools, at) {
  if (!isRecord(guide)) {
    return [`${at}: expected { steps, reach, permissions, expiry, docsUrl }`];
  }
  return [
    ...stepIssues(guide.steps, `${at}.steps`),
    ...reachIssues(guide.reach, `${at}.reach`),
    ...expiryIssues(guide.expiry, `${at}.expiry`),
    ...isHttpsUrl(guide.docsUrl) ? [] : [`${at}.docsUrl: expected an https URL`],
    ...permissionIssues(guide.permissions, tools, `${at}.permissions`)
  ];
}
function stepIssues(steps, at) {
  if (!isList(steps) || steps.length === 0) return [`${at}: expected at least one step`];
  const issues = [];
  steps.forEach((step, i) => {
    const where = `${at}[${i}]`;
    if (!isRecord(step)) {
      issues.push(`${where}: expected { do, path?, url?, code?, screenshot? }`);
      return;
    }
    if (!isSentence(step.do, CREDENTIAL_SENTENCE_MAX_LENGTH)) {
      issues.push(`${where}.do: expected one plain sentence`);
    }
    if (step.url !== void 0 && !isHttpsUrl(step.url)) {
      issues.push(`${where}.url: expected an https URL when present`);
    }
    if (step.code !== void 0 && !isSentence(step.code, CREDENTIAL_SENTENCE_MAX_LENGTH)) {
      issues.push(`${where}.code: expected a non-empty command when present`);
    }
    if (step.path !== void 0) issues.push(...pathIssues(step.path, `${where}.path`));
    if (step.screenshot !== void 0 && (typeof step.screenshot !== "string" || !GUIDE_SCREENSHOT_FILE_PATTERN.test(step.screenshot))) {
      issues.push(`${where}.screenshot: expected a file name such as 'token-form.webp'`);
    }
  });
  return issues;
}
function reachIssues(reach, at) {
  if (!isRecord(reach)) return [`${at}: expected { what, grant, why }`];
  return ["what", "grant", "why"].filter((key) => !isSentence(reach[key], CREDENTIAL_SENTENCE_MAX_LENGTH)).map((key) => `${at}.${key}: expected one plain sentence`);
}
function expiryIssues(expiry, at) {
  if (!isRecord(expiry) || !TOKEN_EXPIRY_KINDS.includes(expiry.kind)) {
    return [`${at}.kind: expected one of ${TOKEN_EXPIRY_KINDS.join(" | ")}`];
  }
  if (expiry.kind === "person-types") {
    const days = expiry.recommendedDays;
    if (typeof days !== "number" || !Number.isInteger(days) || days < 1) {
      return [`${at}.recommendedDays: expected a positive number of days`];
    }
  }
  if (expiry.kind === "none" && !isSentence(expiry.reason, CREDENTIAL_SENTENCE_MAX_LENGTH)) {
    return [`${at}.reason: expected one sentence saying how the token is ended`];
  }
  return [];
}
function permissionIssues(permissions, tools, at) {
  if (!isList(permissions)) {
    return [`${at}: expected a list (empty when the token carries no choice)`];
  }
  if (permissions.length === 0) return [];
  const issues = [];
  const served = /* @__PURE__ */ new Set();
  permissions.forEach((permission, i) => {
    const where = `${at}[${i}]`;
    if (!isRecord(permission)) {
      issues.push(`${where}: expected { name, access, tools }`);
      return;
    }
    if (!isName(permission.name)) issues.push(`${where}.name: expected the service's name`);
    if (!TOKEN_PERMISSION_ACCESS.includes(permission.access)) {
      issues.push(`${where}.access: expected one of ${TOKEN_PERMISSION_ACCESS.join(" | ")}`);
    }
    if (!isList(permission.tools) || permission.tools.length === 0) {
      issues.push(`${where}.tools: expected at least one tool`);
      return;
    }
    for (const tool of permission.tools) {
      if (!tools.has(tool))
        issues.push(`${where}.tools: '${String(tool)}' is not a tool of this plugin`);
      served.add(tool);
    }
  });
  for (const tool of tools) {
    if (typeof tool === "string" && !served.has(tool)) {
      issues.push(`${at}: no permission serves '${tool}'`);
    }
  }
  return issues;
}
function isSentence(x, max) {
  return typeof x === "string" && x.trim().length > 0 && x.length <= max;
}
function kindSpecIssues(spec) {
  if (!spec || typeof spec !== "object") return ["credential: missing CredentialSpec"];
  if (typeof spec.kind !== "string" || !isCredentialKind(spec.kind)) {
    return [`credential.kind: expected one of ${CREDENTIAL_KINDS.join(" | ")}`];
  }
  const issues = [];
  switch (spec.kind) {
    case "api-key":
      if (!isList(spec.fields) || spec.fields.length === 0)
        issues.push("credential.fields: expected at least one field");
      else if (!spec.fields.some((f) => f.secret))
        issues.push("credential.fields: an api-key spec needs at least one secret field");
      break;
    case "oauth2":
      issues.push(...oauth2Issues(spec));
      break;
    case "ssh-key":
      if (spec.algorithm !== "ed25519")
        issues.push("credential.algorithm: only 'ed25519' is supported");
      if (!Array.isArray(spec.fields))
        issues.push("credential.fields: expected a list (host, port, user)");
      break;
    case "host": {
      const extra = Object.keys(spec).filter((key) => key !== "kind");
      if (extra.length > 0) {
        issues.push(
          `credential: a host account declares nothing but its kind (${extra.join(", ")})`
        );
      }
      break;
    }
  }
  return issues;
}
var REGISTERED_CLIENT_ONLY_FIELDS = [
  "authorizationUrl",
  "tokenUrl",
  "pkce",
  "resourceIndicator",
  "clientAuthMethod",
  "refreshable",
  "extraAuthorizationParams",
  "revocation"
];
function oauth2Issues(spec) {
  const record = spec;
  const hasBroker = record.broker !== void 0;
  const hasRegistration = record.clientRegistration !== void 0;
  if (hasBroker && hasRegistration) {
    return ["credential: declare one client source, clientRegistration or broker, not both"];
  }
  const issues = [];
  if (!Array.isArray(spec.scopes)) issues.push("credential.scopes: expected a list (may be empty)");
  if (hasBroker) {
    const broker = record.broker;
    if (!isRecord(broker) || typeof broker.provider !== "string" || !BROKER_PROVIDER_PATTERN.test(broker.provider)) {
      issues.push(
        "credential.broker: expected { provider } with a lowercase slug such as 'google'"
      );
    }
    for (const field of REGISTERED_CLIENT_ONLY_FIELDS) {
      if (record[field] !== void 0) {
        issues.push(`credential.${field}: a brokered spec leaves it to the broker`);
      }
    }
    return issues;
  }
  return [...issues, ...registeredClientIssues(spec)];
}
function registeredClientIssues(spec) {
  const issues = [];
  for (const key of ["authorizationUrl", "tokenUrl"]) {
    if (!isHttpsUrl(spec[key])) issues.push(`credential.${key}: expected an https URL`);
  }
  if (spec.clientAuthMethod === "none" && !spec.pkce)
    issues.push("credential.pkce: a public client (clientAuthMethod none) must use PKCE");
  if (spec.revocation !== void 0) issues.push(...revocationIssues(spec));
  issues.push(...registrationIssues(spec));
  return issues;
}
function isName(x) {
  return typeof x === "string" && x.trim().length > 0;
}
function isHttpsUrl(x) {
  if (typeof x !== "string") return false;
  try {
    return new URL(x).protocol === "https:";
  } catch {
    return false;
  }
}
function registrationIssues(spec) {
  const registration = spec.clientRegistration;
  if (!isRecord(registration))
    return ["credential.clientRegistration: expected { registrationUrl }"];
  const issues = [];
  if (!isHttpsUrl(registration.registrationUrl)) {
    issues.push("credential.clientRegistration.registrationUrl: expected an https URL");
  }
  return issues;
}
function revocationIssues(spec) {
  const revocation = spec.revocation;
  if (!isRecord(revocation)) return ["credential.revocation: expected { url, format }"];
  const issues = [];
  if (!isHttpsUrl(revocation.url)) issues.push("credential.revocation.url: expected an https URL");
  if (!OAUTH2_REVOCATION_FORMATS.includes(revocation.format)) {
    issues.push(
      `credential.revocation.format: expected one of ${OAUTH2_REVOCATION_FORMATS.join(" | ")}`
    );
  }
  if (revocation.format === "client-credentials-json" && (spec.clientAuthMethod === "none" || !spec.refreshable)) {
    issues.push(
      "credential.revocation.format: 'client-credentials-json' needs a confidential client and refresh tokens"
    );
  }
  return issues;
}

// ../../_temp/work/toolchain/packages/plugin-sdk/src/data-model-paths.ts
function slicePathIssue(model, slice, mode, options = {}) {
  const cardinalities = mode === "slice" && (options.cardinalities ?? true);
  const entities = model.planes.flatMap((plane) => plane.entities);
  let at = "service";
  let afterAnything = false;
  let identified = false;
  for (const segment of slice.path) {
    if (segment.kind === "wild-rec") {
      if (mode === "slice") return "'[**]' in a slice : a classifier names what a call touches";
      afterAnything = true;
      continue;
    }
    if (segment.kind === "name") {
      if (isLeaf(at)) {
        return `'${at.leaf}' is not below '${at.under}' in the data model, and a virtual leaf ends the path`;
      }
      if (cardinalities && isEntities(at) && !identified) {
        const issue = cardinalityIssue(at, "one");
        if (issue) return issue;
      }
      const next = entitiesNamed(entities, at, segment.value, afterAnything);
      if (next.length === 0) {
        if (at === "service") return `'${segment.value}' is not an entity of the data model`;
        const near = nearestEntity(entities, segment.value);
        if (near)
          return `'${segment.value}' is not below '${at[0].name}' : did you mean '${near}' ?`;
        at = { leaf: segment.value, under: at[0].name };
      } else at = next;
      afterAnything = false;
      identified = false;
      continue;
    }
    if (afterAnything) continue;
    if (at === "service") return `identifier '${render(segment)}' before any entity`;
    const name = isLeaf(at) ? at.leaf : at[0].name;
    if (identified) return `two identifiers in a row after '${name}'`;
    if (cardinalities && isEntities(at)) {
      const issue = cardinalityIssue(at, cardinalityOf(segment));
      if (issue) return issue;
    }
    identified = true;
  }
  if (cardinalities && isEntities(at) && !identified) return cardinalityIssue(at, "one");
  return null;
}
var TYPO_MIN_LENGTH = 4;
var TYPO_MAX_DISTANCE = 2;
function nearestEntity(entities, name) {
  if (name.length < TYPO_MIN_LENGTH || entities.some((e) => e.name === name)) return null;
  const near = entities.find((e) => {
    if (e.name.length < TYPO_MIN_LENGTH) return false;
    return editDistance(e.name, name) <= TYPO_MAX_DISTANCE;
  });
  return near?.name ?? null;
}
function editDistance(a, b) {
  let previous = Array.from({ length: b.length + 1 }, (_, j) => j);
  for (let i = 1; i <= a.length; i++) {
    const current = [i];
    for (let j = 1; j <= b.length; j++) {
      const substitution = previous[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1);
      current.push(Math.min(previous[j] + 1, current[j - 1] + 1, substitution));
    }
    previous = current;
  }
  return previous[b.length];
}
function isLeaf(at) {
  return typeof at === "object" && "leaf" in at;
}
function isEntities(at) {
  return Array.isArray(at);
}
function entitiesNamed(entities, at, name, afterAnything) {
  const named = entities.filter((e) => e.name === name);
  if (at === "service") return named;
  const parents = new Set(at.map((e) => e.name));
  return named.filter(
    (e) => afterAnything ? hasAncestorIn(entities, e, parents) : e.parent !== null && parents.has(e.parent)
  );
}
function hasAncestorIn(entities, entity, names) {
  const seen = /* @__PURE__ */ new Set();
  let parent = entity.parent;
  while (parent !== null && !seen.has(parent)) {
    if (names.has(parent)) return true;
    seen.add(parent);
    parent = entities.find((e) => e.name === parent)?.parent ?? null;
  }
  return false;
}
function cardinalityOf(segment) {
  if (segment.kind === "list") return "bounded";
  if (segment.kind === "wild-one") return "unbounded";
  return "one";
}
function cardinalityIssue(at, wanted) {
  if (at.some((e) => e.cardinalities.includes(wanted))) return null;
  const entity = at[0];
  const how = wanted === "one" ? "one identifier, or none" : wanted === "bounded" ? "a list" : "[*]";
  return `'${entity.name}' is named by ${how}, but declares only ${entity.cardinalities.join(", ")}`;
}
function render(segment) {
  switch (segment.kind) {
    case "ident":
    case "name":
      return segment.value;
    case "list":
      return segment.values.join(",");
    case "wild-one":
      return "*";
    case "wild-rec":
      return "**";
  }
}
function catalogPathIssues(plugin) {
  const issues = [];
  plugin.catalog.risks.forEach((risk, i) => {
    if (risk.deprecated === true) return;
    for (const pattern of [risk.matches].flat()) {
      let issue;
      try {
        issue = slicePathIssue(plugin.dataModel, parseSlice(pattern), "pattern");
      } catch {
        continue;
      }
      if (issue) issues.push(`risks[${i}] '${risk.id}' matches '${pattern}': ${issue}`);
    }
  });
  return issues;
}

// ../../_temp/work/toolchain/packages/plugin-sdk/src/define-plugin.ts
var PLUGIN_VERSION_PATTERN = /^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$/;
var PLUGIN_SUMMARY_MAX_LENGTH = 600;
var SVG_PATH_DATA_PATTERN = /^[Mm][0-9A-Za-z.,\s+-]*$/;
var HEX_COLOUR_PATTERN = /^#[0-9A-Fa-f]{6}$/;
var TOOL_TITLE_MAX_LENGTH = 60;
var PluginDefinitionError = class extends Error {
  constructor(pluginId, issues) {
    super(`Invalid plugin definition '${pluginId}':
  - ${issues.join("\n  - ")}`);
    this.pluginId = pluginId;
    this.issues = issues;
    this.name = "PluginDefinitionError";
  }
  pluginId;
  issues;
};
function pluginIssues(plugin) {
  return [
    ...identityIssues(plugin),
    ...resourceNounIssues(plugin),
    ...toolIssues(plugin),
    ...toolTitleIssues(plugin),
    ...secretArgumentIssues(plugin),
    ...dataModelIssues(plugin),
    ...catalogIssues(plugin),
    ...credentialSpecIssues(plugin.credential, declaredToolNames(plugin)),
    ...hookIssues(plugin),
    ...retiredTokenHandoutIssues(plugin),
    ...resourceCreatingToolIssues(plugin),
    ...gitRemoteIssues(plugin),
    ...toolReasonIssues(plugin.unboundTools, declaredToolNames(plugin), "unboundTools"),
    ...excludedToolIssues(plugin),
    ...sampleIssues(plugin.examples, declaredToolNames(plugin))
  ];
}
function declaredToolNames(plugin) {
  const names = new Set(isList(plugin.tools) ? plugin.tools.map((t) => t?.name) : []);
  if (plugin.gitRemote) {
    names.add(plugin.gitRemote.fetchTool);
    names.add(plugin.gitRemote.pushTool);
  }
  return names;
}
function gitRemoteIssues(plugin) {
  const remote = plugin.gitRemote;
  if (remote === void 0) return [];
  if (!isRecord(remote)) return ["gitRemote: expected an object when present"];
  const issues = [];
  const prefix2 = typeof plugin.id === "string" ? toolPrefixFor(plugin.id) : "";
  const mcp = new Set(isList(plugin.tools) ? plugin.tools.map((t) => t?.name) : []);
  for (const key of ["fetchTool", "pushTool"]) {
    const name = remote[key];
    if (typeof name !== "string" || !name.startsWith(prefix2) || name.length === prefix2.length) {
      issues.push(`gitRemote.${key} must be a tool name starting with '${prefix2}'`);
      continue;
    }
    if (mcp.has(name)) issues.push(`gitRemote.${key} '${name}' must not be an MCP tool`);
  }
  if (remote.fetchTool === remote.pushTool) {
    issues.push("gitRemote.fetchTool and gitRemote.pushTool must differ");
  }
  for (const fn of ["repositoryOf", "upstream", "review"]) {
    if (typeof remote[fn] !== "function") issues.push(`gitRemote.${fn}: expected a function`);
  }
  const risks = new Set((plugin.catalog?.risks ?? []).map((r) => r.id));
  if (typeof remote.pushRisk !== "string" || !risks.has(remote.pushRisk)) {
    issues.push(`gitRemote.pushRisk '${String(remote.pushRisk)}' is not a risk of the catalog`);
  }
  const abilities = remote.abilities;
  if (abilities !== void 0) {
    if (!isList(abilities)) issues.push("gitRemote.abilities: expected a list when present");
    else
      abilities.forEach((ability, i) => {
        if (!isRecord(ability) || typeof ability.words !== "string" || ability.words === "") {
          issues.push(`gitRemote.abilities[${i}]: expected { risk_id, words }`);
        } else if (typeof ability.risk_id !== "string" || !risks.has(ability.risk_id)) {
          issues.push(
            `gitRemote.abilities[${i}].risk_id '${String(ability.risk_id)}' is not a risk of the catalog`
          );
        }
      });
  }
  return issues;
}
function retiredTokenHandoutIssues(plugin) {
  return Object.hasOwn(plugin, "tokenHandouts") ? [RETIRED_TOKEN_HANDOUTS_ISSUE] : [];
}
var RETIRED_TOKEN_HANDOUTS_ISSUE = "tokenHandouts: retired, no tool may hand the agent a service token (spec \xA72.4) ; remove the key and route the work through the gateway";
function identityIssues(plugin) {
  const issues = [];
  if (typeof plugin.id !== "string" || !isServiceId(plugin.id)) {
    issues.push(`id: expected a lowercase slug such as 'github' or 'cloudflare-dns'`);
  }
  if (typeof plugin.displayName !== "string" || plugin.displayName.trim().length === 0) {
    issues.push("displayName: expected a non-empty string");
  }
  if (typeof plugin.version !== "string" || !PLUGIN_VERSION_PATTERN.test(plugin.version)) {
    issues.push(`version: expected semver (MAJOR.MINOR.PATCH), got '${String(plugin.version)}'`);
  }
  if (plugin.icon !== void 0) {
    if (typeof plugin.icon !== "string" || !SVG_PATH_DATA_PATTERN.test(plugin.icon)) {
      issues.push("icon: expected the path data of one SVG path (`M\u2026`) when present");
    }
  }
  if (plugin.iconColor !== void 0) {
    if (typeof plugin.iconColor !== "string" || !HEX_COLOUR_PATTERN.test(plugin.iconColor)) {
      issues.push("iconColor: expected a colour as `#RRGGBB` when present");
    }
  }
  if (plugin.summary !== void 0) {
    if (typeof plugin.summary !== "string" || plugin.summary.trim().length === 0) {
      issues.push("summary: expected a non-empty string when present");
    } else if (plugin.summary.length > PLUGIN_SUMMARY_MAX_LENGTH) {
      issues.push(`summary: expected at most ${PLUGIN_SUMMARY_MAX_LENGTH} characters`);
    }
  }
  if (plugin.manualRevocation !== void 0) {
    if (typeof plugin.manualRevocation !== "string" || plugin.manualRevocation.trim() === "") {
      issues.push("manualRevocation: expected a non-empty string when present");
    } else if (plugin.manualRevocation.length > PLUGIN_MANUAL_REVOCATION_MAX_LENGTH) {
      issues.push(
        `manualRevocation: expected at most ${PLUGIN_MANUAL_REVOCATION_MAX_LENGTH} characters`
      );
    }
  }
  if (plugin.revoke !== void 0 && typeof plugin.revoke !== "function") {
    issues.push("revoke: expected a function when present");
  }
  return issues;
}
var RESOURCE_NOUN_MAX_LENGTH = 40;
var RESOURCE_NOUN_WORD = /^[a-z0-9]+$/;
function isResourceNoun(word) {
  return word.split(/[ -]/).every((part) => RESOURCE_NOUN_WORD.test(part));
}
function resourceNounIssues(plugin) {
  const noun = plugin.resourceNoun;
  if (noun === void 0) return [];
  if (!isRecord(noun)) return ["resourceNoun: expected { one, other } when present"];
  const issues = [];
  for (const form of ["one", "other"]) {
    const word = noun[form];
    if (typeof word !== "string" || word.trim() === "") {
      issues.push(`resourceNoun.${form}: expected a non-empty string`);
    } else if (word.length > RESOURCE_NOUN_MAX_LENGTH) {
      issues.push(`resourceNoun.${form}: expected at most ${RESOURCE_NOUN_MAX_LENGTH} characters`);
    } else if (!isResourceNoun(word)) {
      issues.push(
        `resourceNoun.${form}: expected a lowercase noun (letters, digits, single spaces, hyphens), got '${word}'`
      );
    }
  }
  return issues;
}
var PLUGIN_MANUAL_REVOCATION_MAX_LENGTH = 400;
function toolIssues(plugin) {
  if (!isList(plugin.tools)) return ["tools: expected a list of McpToolDeclaration"];
  if (typeof plugin.id !== "string") return [];
  const issues = [];
  const prefix2 = toolPrefixFor(plugin.id);
  const seen = /* @__PURE__ */ new Set();
  plugin.tools.forEach((tool, i) => {
    if (!isRecord(tool) || typeof tool.name !== "string") {
      issues.push(`tools[${i}].name: expected a string`);
      return;
    }
    const name = tool.name;
    if (!name.startsWith(prefix2) || name.length === prefix2.length) {
      issues.push(`tools[${i}].name '${name}' must start with '${prefix2}'`);
    }
    if (seen.has(name)) issues.push(`tools[${i}].name '${name}' is declared twice`);
    seen.add(name);
    if (!isRecord(tool.inputSchema) || tool.inputSchema.type !== "object")
      issues.push(`tools[${i}].inputSchema.type must be 'object'`);
  });
  return issues;
}
function resourceCreatingToolIssues(plugin) {
  const declared = plugin.resourceCreatingTools;
  const reader = plugin.createdResources;
  if (reader !== void 0 && typeof reader !== "function") {
    return ["createdResources: expected a function when present"];
  }
  if (declared === void 0) return [];
  if (!isList(declared) || declared.length === 0) {
    return ["resourceCreatingTools: expected a non-empty list of tool names when present"];
  }
  const mcp = new Set(isList(plugin.tools) ? plugin.tools.map((t) => t?.name) : []);
  const issues = [];
  if (reader === void 0) {
    issues.push(
      "createdResources: required when resourceCreatingTools is declared (read the created resource from the answer)"
    );
  }
  const seen = /* @__PURE__ */ new Set();
  for (const tool of declared) {
    if (typeof tool !== "string" || !mcp.has(tool)) {
      issues.push(`resourceCreatingTools: '${String(tool)}' is not a tool of this plugin`);
    } else if (seen.has(tool)) {
      issues.push(`resourceCreatingTools: '${tool}' is listed twice`);
    }
    seen.add(tool);
  }
  return issues;
}
function secretArgumentIssues(plugin) {
  const masks = plugin.secretArguments;
  if (masks === void 0) return [];
  if (!isRecord(masks))
    return ["secretArguments: expected an object keyed by tool name when present"];
  const issues = [];
  const tools = isList(plugin.tools) ? plugin.tools : [];
  for (const [tool, names] of Object.entries(masks)) {
    const declared = tools.find((t) => t?.name === tool);
    if (!declared) {
      issues.push(`secretArguments['${tool}'] is not a tool of this plugin`);
      continue;
    }
    if (!Array.isArray(names) || names.length === 0) {
      issues.push(`secretArguments['${tool}']: expected a non-empty list of argument names`);
      continue;
    }
    const properties = declared.inputSchema.properties ?? {};
    for (const name of names) {
      if (typeof name !== "string" || !Object.hasOwn(properties, name)) {
        issues.push(`secretArguments['${tool}']: '${String(name)}' is not an argument of the tool`);
      }
    }
  }
  return issues;
}
function toolTitleIssues(plugin) {
  const titles = plugin.toolTitles;
  if (titles === void 0) return [];
  if (!isRecord(titles)) return ["toolTitles: expected an object keyed by tool name when present"];
  const tools = declaredToolNames(plugin);
  const issues = [];
  for (const [tool, title2] of Object.entries(titles)) {
    if (!tools.has(tool)) issues.push(`toolTitles['${tool}'] is not a tool of this plugin`);
    if (typeof title2 !== "string" || title2.trim().length === 0) {
      issues.push(`toolTitles['${tool}']: expected a non-empty string`);
      continue;
    }
    if (title2 !== title2.trim() || /\s{2,}|[\r\n]/.test(title2)) {
      issues.push(`toolTitles['${tool}']: expected a single line without surrounding spaces`);
    }
    if (title2.length > TOOL_TITLE_MAX_LENGTH) {
      issues.push(`toolTitles['${tool}']: expected at most ${TOOL_TITLE_MAX_LENGTH} characters`);
    }
    if (/[.!]$/.test(title2)) issues.push(`toolTitles['${tool}']: a title has no final period`);
    if (!/^[A-Z]/.test(title2)) {
      issues.push(`toolTitles['${tool}']: a title starts with a capital letter`);
    }
  }
  return issues;
}
function dataModelIssues(plugin) {
  if (!plugin.dataModel || typeof plugin.dataModel !== "object") return ["dataModel: missing"];
  const issues = [];
  if (plugin.dataModel.service !== plugin.id) {
    issues.push(`dataModel.service '${plugin.dataModel.service}' must equal the plugin id`);
  }
  issues.push(...validateDataModel(plugin.dataModel).map((m) => `dataModel: ${m}`));
  return issues;
}
function catalogIssues(plugin) {
  if (!plugin.catalog || typeof plugin.catalog !== "object") {
    return ["catalog: missing \u2014 load it with loadCatalogFile(catalogPathNextTo(import.meta.url))"];
  }
  const issues = [];
  if (plugin.catalog.service !== plugin.id) {
    issues.push(`catalog.service '${plugin.catalog.service}' must equal the plugin id`);
  }
  issues.push(...semanticIssues(plugin.catalog).map((m) => `catalog: ${m}`));
  if (isList(plugin.catalog.risks) && dataModelIssues(plugin).length === 0) {
    issues.push(...catalogPathIssues(plugin).map((m) => `catalog: ${m}`));
  }
  return issues;
}
function hookIssues(plugin) {
  const issues = [];
  for (const fn of ["classify", "execute", "discoverResources"]) {
    if (typeof plugin[fn] !== "function") issues.push(`${fn}: expected a function`);
  }
  for (const fn of ["envOf", "refresh"]) {
    if (plugin[fn] !== void 0 && typeof plugin[fn] !== "function")
      issues.push(`${fn}: expected a function when present`);
  }
  return issues;
}
function toolReasonIssues(reasons, tools, label) {
  if (reasons === void 0) return [];
  if (!isRecord(reasons)) return [`${label}: expected a record tool \u2192 reason`];
  const issues = [];
  for (const [tool, reason] of Object.entries(reasons)) {
    if (!tools.has(tool)) issues.push(`${label}: '${tool}' is not a tool of this plugin`);
    if (!isSentence(reason, CREDENTIAL_SENTENCE_MAX_LENGTH)) {
      issues.push(`${label}.${tool}: expected one sentence saying why`);
    }
  }
  return issues;
}
function excludedToolIssues(plugin) {
  const excluded = plugin.excludedTools;
  if (excluded === void 0) return [];
  if (!isRecord(excluded)) return ["excludedTools: expected a record tool \u2192 reason"];
  const declared = declaredToolNames(plugin);
  const issues = [];
  for (const [tool, reason] of Object.entries(excluded)) {
    if (declared.has(tool)) {
      issues.push(
        `excludedTools: '${tool}' is a declared tool of this plugin, it cannot be excluded`
      );
    }
    if (!isSentence(reason, CREDENTIAL_SENTENCE_MAX_LENGTH)) {
      issues.push(`excludedTools.${tool}: expected one sentence saying why`);
    }
  }
  return issues;
}
function sampleIssues(samples, tools) {
  const label = "examples";
  if (samples === void 0) return [];
  if (!isRecord(samples)) return [`${label}: expected a record tool \u2192 sample calls`];
  const issues = [];
  for (const [tool, calls] of Object.entries(samples)) {
    if (!tools.has(tool)) issues.push(`${label}: '${tool}' is not a tool of this plugin`);
    if (!isList(calls) || calls.length === 0) {
      issues.push(`${label}.${tool}: expected a non-empty list of sample calls`);
      continue;
    }
    calls.forEach((call, i) => {
      const at = `${label}.${tool}[${i}]`;
      if (!isRecord(call) || !isRecord(call.args)) {
        issues.push(`${at}.args: expected an object`);
        return;
      }
      if (call.resources !== void 0 && !isList(call.resources)) {
        issues.push(`${at}.resources: expected a list when present`);
      }
      if (call.expectDenied !== void 0 && typeof call.expectDenied !== "boolean") {
        issues.push(`${at}.expectDenied: expected a boolean when present`);
      }
    });
  }
  return issues;
}
function definePlugin(definition) {
  const issues = pluginIssues(definition);
  if (issues.length > 0) throw new PluginDefinitionError(String(definition.id), issues);
  return Object.freeze(definition);
}

// ../../_temp/work/toolchain/plugins/notion/src/identity.ts
var SERVICE_ID = "notion";
var API_TOKEN_FIELD = "api_token";
var prefix = toolPrefixFor(SERVICE_ID);
var TOOL = {
  listRoots: `${prefix}list_roots`,
  searchContent: `${prefix}search_content`,
  getPage: `${prefix}get_page`,
  listBlockChildren: `${prefix}list_block_children`,
  getDatabase: `${prefix}get_database`,
  getDataSource: `${prefix}get_data_source`,
  queryDataSource: `${prefix}query_data_source`,
  createPage: `${prefix}create_page`,
  updatePage: `${prefix}update_page`,
  appendBlocks: `${prefix}append_blocks`,
  updateBlock: `${prefix}update_block`,
  deleteBlock: `${prefix}delete_block`,
  trashPage: `${prefix}trash_page`,
  restorePage: `${prefix}restore_page`,
  createEntry: `${prefix}create_entry`,
  updateEntry: `${prefix}update_entry`,
  listComments: `${prefix}list_comments`,
  createComment: `${prefix}create_comment`
};

// ../../_temp/work/toolchain/plugins/notion/src/ids.ts
var DASHED = /^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/;
var UNDASHED = /^[0-9a-fA-F]{32}$/;
function notionId(value) {
  if (typeof value !== "string") return null;
  if (DASHED.test(value)) return value.toLowerCase();
  if (!UNDASHED.test(value)) return null;
  const hex = value.toLowerCase();
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
}
function malformedId(argument, value) {
  const hint = typeof value === "string" && /notion\.(so|site|com)/i.test(value) ? " (a page URL is not an id: pass the 32 hexadecimal characters at its end)" : "";
  return `${argument}: malformed Notion id${hint}`;
}
var CURSOR = /^[A-Za-z0-9-]{1,128}$/;
function cursor(value) {
  return typeof value === "string" && CURSOR.test(value) ? value : null;
}
var MAX_TEXT_LENGTH = 2e3;
function boundedInt(value, min, max) {
  return typeof value === "number" && Number.isInteger(value) && value >= min && value <= max ? value : null;
}
function resolveRoot(args, resources) {
  const own = resources.filter((r) => r.service === SERVICE_ID);
  if (args.root !== void 0) {
    const explicit = notionId(args.root);
    if (!explicit) return { denied: malformedId("root", args.root) };
    const found = own.find((r) => notionId(r.ref) === explicit);
    return found ? { ref: explicit, kind: rootKindOf(found) } : { denied: `root '${explicit}' is not selected in this mission` };
  }
  if (own.length === 1) {
    const only = notionId(own[0].ref);
    return only ? { ref: only, kind: rootKindOf(own[0]) } : { denied: "root: the mission resource is not a Notion id" };
  }
  return {
    denied: own.length === 0 ? "root: argument missing and the mission selects no Notion root" : `root: argument missing and the mission selects ${own.length} Notion roots \u2014 name one`
  };
}
function rootKindOf(resource) {
  const kind = resource.metadata?.kind;
  return kind === "page" || kind === "database" ? kind : null;
}

// ../../_temp/work/toolchain/plugins/notion/src/content.ts
var MAX_ARRAY_ITEMS = 100;
var MAX_BLOCKS_PER_REQUEST = 1e3;
var MAX_NESTING_LEVELS = 2;
var MAX_JSON_DEPTH = 24;
var CREATABLE_BLOCK_TYPES = /* @__PURE__ */ new Set([
  "audio",
  "bookmark",
  "breadcrumb",
  "bulleted_list_item",
  "callout",
  "code",
  "column",
  "column_list",
  "divider",
  "embed",
  "equation",
  "file",
  "heading_1",
  "heading_2",
  "heading_3",
  "heading_4",
  "image",
  "link_to_page",
  "numbered_list_item",
  "paragraph",
  "pdf",
  "quote",
  "synced_block",
  "tab",
  "table",
  "table_of_contents",
  "table_row",
  "to_do",
  "toggle",
  "video"
]);
var UPDATABLE_BLOCK_TYPES = /* @__PURE__ */ new Set([
  "audio",
  "bookmark",
  "bulleted_list_item",
  "callout",
  "code",
  "embed",
  "equation",
  "file",
  "heading_1",
  "heading_2",
  "heading_3",
  "heading_4",
  "image",
  "numbered_list_item",
  "paragraph",
  "pdf",
  "quote",
  "table",
  "table_row",
  "to_do",
  "toggle",
  "video"
]);
var CONTAINER_BLOCK_TYPES = /* @__PURE__ */ new Set(["child_page", "child_database"]);
var NOT_CREATABLE = {
  child_page: `create a page with ${TOOL.createPage}`,
  child_database: "databases are not created by this plugin",
  link_preview: "Notion does not create it through the block endpoints",
  meeting_notes: "Notion does not create it through the block endpoints",
  transcription: "Notion does not create it through the block endpoints",
  unsupported: "Notion does not create it through the block endpoints"
};
var READ_ONLY_PROPERTY_TYPES = /* @__PURE__ */ new Set([
  "button",
  "created_by",
  "created_time",
  "formula",
  "last_edited_by",
  "last_edited_time",
  "rollup",
  "unique_id",
  "verification"
]);
function noReferences() {
  return { pages: [], databases: [] };
}
function refer(refs, kind, id3) {
  if (refs && !refs[kind].includes(id3)) refs[kind].push(id3);
}
function checkJson(value, path, depth = 0) {
  if (depth > MAX_JSON_DEPTH) return `${path}: nested too deeply`;
  if (typeof value === "string") {
    return value.length > MAX_TEXT_LENGTH ? `${path}: longer than ${MAX_TEXT_LENGTH} characters (Notion's limit)` : null;
  }
  if (Array.isArray(value)) {
    if (value.length > MAX_ARRAY_ITEMS) {
      return `${path}: more than ${MAX_ARRAY_ITEMS} items (Notion's limit)`;
    }
    for (const [i, item] of value.entries()) {
      const issue = checkJson(item, `${path}[${i}]`, depth + 1);
      if (issue) return issue;
    }
    return null;
  }
  if (isRecord(value)) {
    if ("file_upload" in value || value.type === "file_upload") {
      return `${path}: file uploads are not available through this plugin`;
    }
    for (const [key, item] of Object.entries(value)) {
      const issue = checkJson(item, `${path}.${key}`, depth + 1);
      if (issue) return issue;
    }
    return null;
  }
  return null;
}
function checkRichText(value, path, refs) {
  if (!Array.isArray(value)) return `${path}: expected an array of rich text objects`;
  const limits = checkJson(value, path);
  if (limits) return limits;
  return mentionIssue(value, path, 0, refs);
}
function mentionIssue(value, path, depth, refs) {
  if (depth > MAX_JSON_DEPTH) return `${path}: nested too deeply`;
  if (Array.isArray(value)) {
    for (const [i, item] of value.entries()) {
      const issue = mentionIssue(item, `${path}[${i}]`, depth + 1, refs);
      if (issue) return issue;
    }
    return null;
  }
  if (!isRecord(value)) return null;
  if ("mention" in value) {
    const issue = checkMention(value.mention, `${path}.mention`, refs);
    if (issue) return issue;
  }
  for (const [key, item] of Object.entries(value)) {
    if (key === "mention") continue;
    const issue = mentionIssue(item, `${path}.${key}`, depth + 1, refs);
    if (issue) return issue;
  }
  return null;
}
var MENTION_TYPES = /* @__PURE__ */ new Set(["page", "database", "user", "date"]);
function checkMention(mention, path, refs) {
  if (!isRecord(mention) || typeof mention.type !== "string" || !MENTION_TYPES.has(mention.type)) {
    return `${path}.type: one of 'page', 'database', 'user', 'date'`;
  }
  const type = mention.type;
  for (const key of Object.keys(mention)) {
    if (key !== "type" && key !== type) return `${path}.${key}: not part of a '${type}' mention`;
  }
  const target = mention[type];
  if (!isRecord(target)) return `${path}.${type}: expected an object`;
  if (type === "date") return null;
  for (const key of Object.keys(target)) {
    if (key !== "id" && key !== "object") return `${path}.${type}.${key}: not part of a mention`;
  }
  const id3 = notionId(target.id);
  if (!id3) return malformedId(`${path}.${type}.id`, target.id);
  if (type === "page") refer(refs, "pages", id3);
  if (type === "database") refer(refs, "databases", id3);
  return null;
}
function checkLinkToPage(body, path, refs) {
  const field = body.type === "page_id" || body.type === "database_id" ? body.type : null;
  if (!field) return `${path}.type: 'page_id' or 'database_id'`;
  for (const key of Object.keys(body)) {
    if (key !== "type" && key !== field) return `${path}.${key}: not part of a '${field}' link`;
  }
  const id3 = notionId(body[field]);
  if (!id3) return malformedId(`${path}.${field}`, body[field]);
  refer(refs, field === "page_id" ? "pages" : "databases", id3);
  return null;
}
function checkChildren(value, path = "children", refs) {
  if (!Array.isArray(value)) return `${path}: expected an array of block objects`;
  const limits = checkJson(value, path);
  if (limits) return limits;
  return blocksIssue(value, path, 0, { count: 0, refs });
}
function blocksIssue(blocks, path, level, walk) {
  if (level > MAX_NESTING_LEVELS) {
    return `${path}: more than ${MAX_NESTING_LEVELS} levels of nesting in one request (Notion's limit)`;
  }
  for (const [i, block] of blocks.entries()) {
    walk.count += 1;
    if (walk.count > MAX_BLOCKS_PER_REQUEST) {
      return `${path}: more than ${MAX_BLOCKS_PER_REQUEST} blocks in one request (Notion's limit)`;
    }
    const where = `${path}[${i}]`;
    const checked2 = newBlock(block, where, walk.refs);
    if (typeof checked2 === "string") return checked2;
    const { type, body } = checked2;
    const nested = body.children;
    if (nested === void 0) continue;
    if (!Array.isArray(nested)) return `${where}.${type}.children: expected an array`;
    const deeper = blocksIssue(nested, `${where}.${type}.children`, level + 1, walk);
    if (deeper) return deeper;
  }
  return null;
}
function newBlock(block, path, refs) {
  if (!isRecord(block)) return `${path}: expected a block object`;
  const type = block.type;
  if (typeof type !== "string") return `${path}.type: required (the block type)`;
  if (type in NOT_CREATABLE) {
    return `${path}: a '${type}' block cannot be added here \u2014 ${NOT_CREATABLE[type]}`;
  }
  if (!CREATABLE_BLOCK_TYPES.has(type)) return `${path}.type: unknown block type '${type}'`;
  for (const key of Object.keys(block)) {
    if (key !== "type" && key !== "object" && key !== type) {
      return `${path}.${key}: not part of a '${type}' block`;
    }
  }
  if (block.object !== void 0 && block.object !== "block") {
    return `${path}.object: must be 'block'`;
  }
  const body = block[type];
  if (!isRecord(body)) return `${path}.${type}: expected an object`;
  return blockBodyIssue(type, body, `${path}.${type}`, refs) ?? { type, body };
}
function blockBodyIssue(type, body, path, refs) {
  if (type === "synced_block" && body.synced_from !== void 0 && body.synced_from !== null) {
    return `${path}.synced_from: a synced copy of another block is not created by this plugin (it would show content from wherever the original lives)`;
  }
  if (type === "link_to_page") return checkLinkToPage(body, path, refs);
  for (const [key, item] of Object.entries(body)) {
    if (key === "rich_text" || key === "caption") {
      const issue = checkRichText(item, `${path}.${key}`, refs);
      if (issue) return issue;
    }
  }
  return mentionIssue(body, path, 0, refs);
}
function checkBlockUpdate(type, content) {
  const refused = (reason) => ({ refused: reason });
  if (typeof type !== "string") return refused("type: required (the type of the block to rewrite)");
  if (CONTAINER_BLOCK_TYPES.has(type)) {
    return refused(
      `type: a '${type}' is changed with ${type === "child_page" ? TOOL.updatePage : "no tool of this plugin"}`
    );
  }
  if (!UPDATABLE_BLOCK_TYPES.has(type)) {
    return refused(`type: a '${type}' block cannot be rewritten here`);
  }
  if (!isRecord(content)) return refused(`content: expected the '${type}' object of the block`);
  if ("children" in content) {
    return refused(
      `content.children: a block\u2019s children are not rewritten; use ${TOOL.appendBlocks} or ${TOOL.deleteBlock}`
    );
  }
  const limits = checkJson(content, "content");
  if (limits) return refused(limits);
  const references = noReferences();
  const issue = blockBodyIssue(type, content, "content", references);
  return issue ? refused(issue) : { ok: { type, content, references } };
}
function checkProperties(value, references) {
  if (!isRecord(value)) return "properties: expected an object keyed by property name";
  const limits = checkJson(value, "properties");
  if (limits) return limits;
  for (const [name, property] of Object.entries(value)) {
    const path = `properties.${JSON.stringify(name)}`;
    if (!isRecord(property)) return `${path}: expected a property value object`;
    const keys = Object.keys(property).filter((k) => k !== "id" && k !== "type");
    const declared = typeof property.type === "string" ? [property.type] : [];
    for (const type of [...declared, ...keys]) {
      if (READ_ONLY_PROPERTY_TYPES.has(type)) {
        return `${path}: a '${type}' value is computed by Notion and cannot be set`;
      }
    }
    const relation = property.relation;
    if (relation !== void 0) {
      if (!Array.isArray(relation)) return `${path}.relation: expected an array`;
      for (const [i, target] of relation.entries()) {
        const id3 = isRecord(target) ? notionId(target.id) : null;
        if (!id3)
          return malformedId(`${path}.relation[${i}].id`, isRecord(target) ? target.id : target);
        refer(references, "pages", id3);
      }
    }
    const people = property.people;
    if (people !== void 0) {
      if (!Array.isArray(people)) return `${path}.people: expected an array`;
      for (const [i, person] of people.entries()) {
        if (!isRecord(person) || !notionId(person.id)) {
          return malformedId(`${path}.people[${i}].id`, isRecord(person) ? person.id : person);
        }
      }
    }
    for (const key of ["title", "rich_text"]) {
      if (property[key] === void 0) continue;
      const issue = checkRichText(property[key], `${path}.${key}`, references);
      if (issue) return issue;
    }
  }
  return null;
}
function checkIcon(value) {
  if (!isRecord(value)) return "icon: expected an icon object";
  const limits = checkJson(value, "icon");
  if (limits) return limits;
  switch (value.type) {
    case "emoji":
      return typeof value.emoji === "string" ? null : "icon.emoji: expected a string";
    case "icon":
      return isRecord(value.icon) && typeof value.icon.name === "string" ? null : "icon.icon.name: expected a string";
    case "external":
      return externalIssue(value, "icon");
    default:
      return "icon.type: one of 'emoji', 'icon', 'external'";
  }
}
function checkCover(value) {
  if (!isRecord(value)) return "cover: expected a cover object";
  const limits = checkJson(value, "cover");
  if (limits) return limits;
  if (value.type !== "external") return "cover.type: must be 'external'";
  return externalIssue(value, "cover");
}
function externalIssue(value, path) {
  for (const key of Object.keys(value)) {
    if (key !== "type" && key !== "external") return `${path}.${key}: not part of an external file`;
  }
  const external = value.external;
  if (!isRecord(external) || Object.keys(external).some((k) => k !== "url")) {
    return `${path}.external: expected { url }`;
  }
  const url = external.url;
  if (typeof url !== "string" || url.length > MAX_TEXT_LENGTH) {
    return `${path}.external.url: expected an https URL of at most ${MAX_TEXT_LENGTH} characters`;
  }
  try {
    if (new URL(url).protocol !== "https:") return `${path}.external.url: must be https`;
  } catch {
    return `${path}.external.url: not a URL`;
  }
  return null;
}

// ../../_temp/work/toolchain/plugins/notion/src/tools.ts
var ID_HELP = "A Notion id: 32 hexadecimal characters, with or without dashes.";
var root = {
  root: {
    type: "string",
    description: "Id of the shared root (page or database) the call works in, one of the roots of the mission (notion__list_roots). May be omitted when the mission has one root."
  }
};
var id = (description) => ({ type: "string", description: `${description} ${ID_HELP}` });
var pageSize = (fallback) => ({
  type: "integer",
  minimum: 1,
  maximum: 100,
  description: `Results per page, 1 to 100 (default ${fallback}).`
});
var startCursor = {
  type: "string",
  description: "The previous answer's next_cursor, to read the next page."
};
var richText = {
  type: "array",
  description: "Notion rich text objects, at most 100, each text at most 2000 characters.",
  items: { type: "object" }
};
var children = {
  type: "array",
  description: "Notion block objects ({ type, [type]: {...} }), at most 100, two levels of nesting, no file upload, no synced copy, no child_page or child_database.",
  items: { type: "object" }
};
var icon = {
  type: "object",
  description: 'Page icon: { type: "emoji", emoji }, { type: "icon", icon: { name, color } } or { type: "external", external: { url } } (https).'
};
var cover = {
  type: "object",
  description: 'Page cover: { type: "external", external: { url } } (https).'
};
var SILENT = " Sent silently: Notion notifies nobody of the change (database automations still run).";
var notionTools = [
  {
    name: TOOL.listRoots,
    description: "List the shared roots of this mission: the top-level pages and databases the agent may work in, with their id, title and kind. Sends no request to Notion.",
    inputSchema: { type: "object", properties: {} }
  },
  {
    name: TOOL.searchContent,
    description: "Search page and database titles within one root. Notion's search matches titles only, is not exhaustive and lags behind recent changes; results that cannot be shown to be under the root are left out. To find entries of a database, query its data source instead.",
    inputSchema: {
      type: "object",
      properties: {
        ...root,
        query: { type: "string", description: "Text to look for in titles." },
        object: {
          type: "string",
          enum: ["page", "data_source"],
          description: "Only pages, or only data sources (databases)."
        },
        sort: {
          type: "object",
          description: 'Notion sort: { direction: "ascending" | "descending", timestamp: "last_edited_time" }.'
        },
        page_size: pageSize(20),
        start_cursor: startCursor
      }
    }
  },
  {
    name: TOOL.getPage,
    description: "Read a page's properties (title, icon, cover, database values). Its content is read with notion__list_block_children. A relation or a rollup may look empty when the related pages are not shared with the account.",
    inputSchema: {
      type: "object",
      properties: { ...root, page_id: id("The page.") },
      required: ["page_id"]
    }
  },
  {
    name: TOOL.listBlockChildren,
    description: "Read the content of a page or a block: its child blocks, and with depth 2 or 3 their nested blocks in the same call (at most 500 blocks, 20 listings). Sub-pages are listed, not expanded.",
    inputSchema: {
      type: "object",
      properties: {
        ...root,
        block_id: id("The page or block whose content is read."),
        depth: {
          type: "integer",
          minimum: 1,
          maximum: 3,
          description: "Levels to read, 1 to 3 (default 1)."
        },
        page_size: pageSize(50),
        start_cursor: startCursor
      },
      required: ["block_id"]
    }
  },
  {
    name: TOOL.getDatabase,
    description: "Read a database: its title, its parent and the list of its data sources.",
    inputSchema: {
      type: "object",
      properties: { ...root, database_id: id("The database.") },
      required: ["database_id"]
    }
  },
  {
    name: TOOL.getDataSource,
    description: "Read a data source's schema: its properties and their types.",
    inputSchema: {
      type: "object",
      properties: { ...root, data_source_id: id("The data source.") },
      required: ["data_source_id"]
    }
  },
  {
    name: TOOL.queryDataSource,
    description: "Query the entries of a data source with a Notion filter and sorts. Returns pages (entries) only.",
    inputSchema: {
      type: "object",
      properties: {
        ...root,
        data_source_id: id("The data source."),
        filter: { type: "object", description: "Notion filter object." },
        sorts: { type: "array", description: "Notion sort objects.", items: { type: "object" } },
        page_size: pageSize(50),
        start_cursor: startCursor
      },
      required: ["data_source_id"]
    }
  },
  {
    name: TOOL.createPage,
    description: `Create a page under an existing page of the root, with a title and optional first content.${SILENT}`,
    inputSchema: {
      type: "object",
      properties: {
        ...root,
        parent_page_id: id("The page the new page goes under."),
        title: { type: "string", description: "Title of the new page (at most 2000 characters)." },
        children,
        icon,
        cover
      },
      required: ["parent_page_id", "title"]
    }
  },
  {
    name: TOOL.updatePage,
    description: `Change the title, icon or cover of a page (not a database entry: use notion__update_entry).${SILENT}`,
    inputSchema: {
      type: "object",
      properties: {
        ...root,
        page_id: id("The page."),
        title: { type: "string", description: "New title (at most 2000 characters)." },
        icon,
        cover
      },
      required: ["page_id"]
    }
  },
  {
    name: TOOL.appendBlocks,
    description: `Add blocks to a page or a block, at the end (default), at the start or after a given child block.${SILENT}`,
    inputSchema: {
      type: "object",
      properties: {
        ...root,
        block_id: id("The page or block that receives the new blocks."),
        children,
        position: {
          type: "string",
          enum: ["end", "start", "after_block"],
          description: "Where the blocks go (default end)."
        },
        after_block_id: id("With position after_block: the child block the new blocks follow.")
      },
      required: ["block_id", "children"]
    }
  },
  {
    name: TOOL.updateBlock,
    description: "Rewrite the content of one block (a paragraph, a heading, a to-do, a table row\u2026): give its type and the new object for that type. The block's children are not changed. Notion offers no silent mode here: a mention in the new text notifies the person it names.",
    inputSchema: {
      type: "object",
      properties: {
        ...root,
        block_id: id("The block."),
        type: {
          type: "string",
          description: "The type of the block, as Notion reports it (paragraph, to_do\u2026)."
        },
        content: {
          type: "object",
          description: "The new object for that type, e.g. { rich_text: [...], checked: true } for a to_do."
        }
      },
      required: ["block_id", "type", "content"]
    }
  },
  {
    name: TOOL.deleteBlock,
    description: "Move one block of a page (with the blocks nested in it) to the trash. Not a page: use notion__trash_page.",
    inputSchema: {
      type: "object",
      properties: { ...root, block_id: id("The block.") },
      required: ["block_id"]
    }
  },
  {
    name: TOOL.trashPage,
    description: `Move a page, and everything under it, to the trash. It can be restored with notion__restore_page.${SILENT}`,
    inputSchema: {
      type: "object",
      properties: { ...root, page_id: id("The page.") },
      required: ["page_id"]
    }
  },
  {
    name: TOOL.restorePage,
    description: `Bring a page back from the trash, with everything under it.${SILENT}`,
    inputSchema: {
      type: "object",
      properties: { ...root, page_id: id("The page.") },
      required: ["page_id"]
    }
  },
  {
    name: TOOL.createEntry,
    description: `Add an entry to a database: its data source and the property values. Relation targets must be under the same root.${SILENT}`,
    inputSchema: {
      type: "object",
      properties: {
        ...root,
        data_source_id: id("The data source of the database."),
        properties: {
          type: "object",
          description: "Notion property values, keyed by property name."
        },
        children,
        icon
      },
      required: ["data_source_id", "properties"]
    }
  },
  {
    name: TOOL.updateEntry,
    description: `Change property values of a database entry; a list value replaces the whole list. Relation targets must be under the same root.${SILENT}`,
    inputSchema: {
      type: "object",
      properties: {
        ...root,
        data_source_id: id("The data source the entry belongs to."),
        page_id: id("The entry."),
        properties: {
          type: "object",
          description: "Notion property values, keyed by property name."
        },
        icon
      },
      required: ["data_source_id", "page_id", "properties"]
    }
  },
  {
    name: TOOL.listComments,
    description: "Read the open (unresolved) comments on a page or a block.",
    inputSchema: {
      type: "object",
      properties: {
        ...root,
        block_id: id("The page or block."),
        page_size: pageSize(20),
        start_cursor: startCursor
      },
      required: ["block_id"]
    }
  },
  {
    name: TOOL.createComment,
    description: "Open a discussion on a page or a block, or reply to an open discussion of that page or block. Signed by the account; notifies the people it mentions.",
    inputSchema: {
      type: "object",
      properties: {
        ...root,
        block_id: id("The page or block the comment is on."),
        rich_text: richText,
        discussion_id: id("To reply: an open discussion of that page or block.")
      },
      required: ["block_id", "rich_text"]
    }
  }
];
var notionToolTitles = {
  [TOOL.listRoots]: "List the shared roots",
  [TOOL.searchContent]: "Search pages and databases",
  [TOOL.getPage]: "Read a page",
  [TOOL.listBlockChildren]: "Read a page's content",
  [TOOL.getDatabase]: "Read a database",
  [TOOL.getDataSource]: "Read a database's schema",
  [TOOL.queryDataSource]: "Query a database",
  [TOOL.createPage]: "Create a page",
  [TOOL.updatePage]: "Update a page",
  [TOOL.appendBlocks]: "Add content to a page",
  [TOOL.updateBlock]: "Rewrite a block of a page",
  [TOOL.deleteBlock]: "Delete a block of a page",
  [TOOL.trashPage]: "Move a page to the trash",
  [TOOL.restorePage]: "Bring a page back from the trash",
  [TOOL.createEntry]: "Add a database entry",
  [TOOL.updateEntry]: "Update a database entry",
  [TOOL.listComments]: "Read comments",
  [TOOL.createComment]: "Add a comment"
};

// ../../_temp/work/toolchain/plugins/notion/src/classify.ts
var DECLARED = declaredArgumentsOf(notionTools);
function undeclaredArgument(tool, args) {
  return undeclaredArgumentDenial(DECLARED, tool, args);
}
var DEFAULT_PAGE_SIZE = { search: 20, children: 50, query: 50, comments: 20 };
var OPS = new Map(
  Object.entries(TOOL).map(([op, name]) => [name, op])
);
function opOf(tool) {
  return OPS.get(tool) ?? null;
}
var Denied = class extends Error {
  constructor(reason) {
    super(reason);
    this.reason = reason;
    this.name = "Denied";
  }
  reason;
};
function deny(reason) {
  throw new Denied(reason);
}
function idArg(args, name) {
  return notionId(args[name]) ?? deny(malformedId(name, args[name]));
}
function optionalIdArg(args, name) {
  return args[name] === void 0 ? null : idArg(args, name);
}
function paged(args, fallback) {
  const pageSize2 = args.page_size === void 0 ? fallback : boundedInt(args.page_size, 1, 100) ?? deny("page_size: an integer from 1 to 100");
  const startCursor2 = args.start_cursor === void 0 ? null : cursor(args.start_cursor) ?? deny("start_cursor: malformed");
  return { pageSize: pageSize2, startCursor: startCursor2 };
}
function title(value, name) {
  if (typeof value !== "string" || value.length === 0)
    return deny(`${name}: expected a non-empty string`);
  if (value.length > MAX_TEXT_LENGTH)
    return deny(`${name}: longer than ${MAX_TEXT_LENGTH} characters (Notion's limit)`);
  return value;
}
function checked(issue) {
  if (issue) deny(issue);
}
function optional(value, check) {
  if (value !== void 0) checked(check(value));
  return value;
}
function sortOf(value) {
  if (value === void 0) return null;
  if (typeof value !== "object" || value === null || Array.isArray(value))
    return deny("sort: expected an object");
  const sort = value;
  for (const key of Object.keys(sort)) {
    if (key !== "direction" && key !== "timestamp")
      return deny(`sort.${key}: not part of a search sort`);
  }
  if (sort.direction !== "ascending" && sort.direction !== "descending") {
    return deny("sort.direction: 'ascending' or 'descending'");
  }
  if (sort.timestamp !== "last_edited_time")
    return deny("sort.timestamp: must be 'last_edited_time'");
  return sort;
}
function positionOf(args) {
  const position = args.position ?? "end";
  if (position === "after_block") {
    if (args.after_block_id === void 0)
      return deny("after_block_id: required with position after_block");
    return { type: "after_block", afterBlockId: idArg(args, "after_block_id") };
  }
  if (args.after_block_id !== void 0)
    return deny("after_block_id: only with position after_block");
  if (position === "end" || position === "start") return { type: position };
  return deny("position: one of 'end', 'start', 'after_block'");
}
function childrenOf(value, references) {
  if (value !== void 0) checked(checkChildren(value, "children", references));
  return value;
}
function readCall(tool, args, resources) {
  try {
    return readOrThrow(tool, args, resources);
  } catch (error) {
    if (error instanceof Denied) return { denied: error.reason };
    throw error;
  }
}
function readOrThrow(tool, args, resources) {
  const op = opOf(tool);
  if (op === null) return deny(`unknown tool '${tool}'`);
  if (op === "listRoots") return { op };
  const resolved = resolveRoot(args, resources);
  if ("denied" in resolved) return deny(resolved.denied);
  const root2 = resolved;
  switch (op) {
    case "searchContent": {
      const query = args.query === void 0 ? null : title(args.query, "query");
      const object = args.object ?? null;
      if (object !== null && object !== "page" && object !== "data_source") {
        return deny("object: 'page' or 'data_source'");
      }
      return {
        op,
        root: root2,
        query,
        object,
        sort: sortOf(args.sort),
        ...paged(args, DEFAULT_PAGE_SIZE.search)
      };
    }
    case "getPage":
      return {
        op,
        root: root2,
        pageId: idArg(args, "page_id")
      };
    case "listBlockChildren": {
      const depth = args.depth === void 0 ? 1 : boundedInt(args.depth, 1, 3) ?? deny("depth: an integer from 1 to 3");
      return {
        op,
        root: root2,
        blockId: idArg(args, "block_id"),
        depth,
        ...paged(args, DEFAULT_PAGE_SIZE.children)
      };
    }
    case "getDatabase":
      return {
        op,
        root: root2,
        databaseId: idArg(args, "database_id")
      };
    case "getDataSource":
      return {
        op,
        root: root2,
        dataSourceId: idArg(args, "data_source_id")
      };
    case "queryDataSource":
      return {
        op,
        root: root2,
        dataSourceId: idArg(args, "data_source_id"),
        filter: optional(
          args.filter,
          (v) => typeof v === "object" && v !== null && !Array.isArray(v) ? checkJson(v, "filter") : "filter: expected an object"
        ),
        sorts: optional(
          args.sorts,
          (v) => Array.isArray(v) ? checkJson(v, "sorts") : "sorts: expected an array"
        ),
        ...paged(args, DEFAULT_PAGE_SIZE.query)
      };
    case "createPage": {
      const references = noReferences();
      return {
        op,
        root: root2,
        parentPageId: idArg(args, "parent_page_id"),
        title: title(args.title, "title"),
        children: childrenOf(args.children, references),
        icon: optional(args.icon, checkIcon),
        cover: optional(args.cover, checkCover),
        references
      };
    }
    case "updatePage": {
      if (args.title === void 0 && args.icon === void 0 && args.cover === void 0) {
        return deny("update_page: give a title, an icon or a cover");
      }
      return {
        op,
        root: root2,
        pageId: idArg(args, "page_id"),
        title: args.title === void 0 ? null : title(args.title, "title"),
        icon: optional(args.icon, checkIcon),
        cover: optional(args.cover, checkCover)
      };
    }
    case "appendBlocks": {
      if (args.children === void 0) return deny("children: required");
      const references = noReferences();
      checked(checkChildren(args.children, "children", references));
      return {
        op,
        root: root2,
        blockId: idArg(args, "block_id"),
        children: args.children,
        position: positionOf(args),
        references
      };
    }
    case "updateBlock": {
      const blockId = idArg(args, "block_id");
      if (blockId === root2.ref)
        return deny(`block_id: the shared root itself \u2014 change a page with ${TOOL.updatePage}`);
      const update = checkBlockUpdate(args.type, args.content);
      if ("refused" in update) return deny(update.refused);
      return { op, root: root2, blockId, ...update.ok };
    }
    case "deleteBlock": {
      const blockId = idArg(args, "block_id");
      if (blockId === root2.ref) {
        return deny(
          `block_id: the shared root itself \u2014 a page goes to the trash with ${TOOL.trashPage}`
        );
      }
      return {
        op,
        root: root2,
        blockId
      };
    }
    case "trashPage": {
      const pageId = idArg(args, "page_id");
      if (pageId === root2.ref && root2.kind === "database") {
        return deny("page_id: the shared root is a database, which this plugin does not trash");
      }
      return {
        op,
        root: root2,
        pageId
      };
    }
    case "restorePage":
      return {
        op,
        root: root2,
        pageId: idArg(args, "page_id")
      };
    case "createEntry": {
      if (args.properties === void 0) return deny("properties: required");
      const references = noReferences();
      checked(checkProperties(args.properties, references));
      return {
        op,
        root: root2,
        dataSourceId: idArg(args, "data_source_id"),
        properties: args.properties,
        children: childrenOf(args.children, references),
        icon: optional(args.icon, checkIcon),
        references
      };
    }
    case "updateEntry": {
      if (args.properties === void 0) return deny("properties: required");
      const references = noReferences();
      checked(checkProperties(args.properties, references));
      return {
        op,
        root: root2,
        dataSourceId: idArg(args, "data_source_id"),
        pageId: idArg(args, "page_id"),
        properties: args.properties,
        icon: optional(args.icon, checkIcon),
        references
      };
    }
    case "listComments":
      return {
        op,
        root: root2,
        blockId: idArg(args, "block_id"),
        ...paged(args, DEFAULT_PAGE_SIZE.comments)
      };
    case "createComment": {
      if (args.rich_text === void 0) return deny("rich_text: required");
      const references = noReferences();
      checked(checkRichText(args.rich_text, "rich_text", references));
      if (Array.isArray(args.rich_text) && args.rich_text.length === 0) {
        return deny("rich_text: the comment is empty");
      }
      return {
        op,
        root: root2,
        blockId: idArg(args, "block_id"),
        richText: args.rich_text,
        discussionId: optionalIdArg(args, "discussion_id"),
        references
      };
    }
  }
}
function slicesOf(call, resources) {
  const s = (path) => parseSlice(`${SERVICE_ID}.${path}`);
  if (call.op === "listRoots") {
    const roots = resources.filter((r) => r.service === SERVICE_ID).map((r) => notionId(r.ref)).filter((ref) => ref !== null);
    return roots.map((ref) => s(`root[${ref}].R`));
  }
  const R = `root[${call.root.ref}]`;
  switch (call.op) {
    case "searchContent":
      return [
        ...call.object === "data_source" ? [] : [s(`${R}.page[*].R`)],
        ...call.object === "page" ? [] : [s(`${R}.data-source[*].R`)]
      ];
    case "getPage":
      return [s(`${R}.page[${call.pageId}].R`)];
    case "listBlockChildren":
      return [s(`${R}.block[${call.blockId}].R`)];
    case "getDatabase":
      return [s(`${R}.database[${call.databaseId}].R`)];
    case "getDataSource":
      return [s(`${R}.data-source[${call.dataSourceId}].R`)];
    case "queryDataSource":
      return [s(`${R}.data-source[${call.dataSourceId}].entry[*].R`)];
    case "createPage":
      return [s(`${R}.page[${call.parentPageId}].subpage.W`)];
    case "updatePage":
      return [s(`${R}.page[${call.pageId}].properties.W`)];
    case "appendBlocks":
      return [s(`${R}.block[${call.blockId}].children.W`)];
    case "updateBlock":
      return [s(`${R}.block[${call.blockId}].W`)];
    case "deleteBlock":
      return [s(`${R}.block[${call.blockId}].delete.W`)];
    case "trashPage":
      return [
        s(`${R}.page[${call.pageId}].trash.W`),
        ...call.pageId === call.root.ref ? [s(`${R}.root-trash.W`)] : []
      ];
    case "restorePage":
      return [s(`${R}.page[${call.pageId}].restore.W`)];
    case "createEntry":
      return [s(`${R}.data-source[${call.dataSourceId}].entry.W`)];
    case "updateEntry":
      return [s(`${R}.data-source[${call.dataSourceId}].entry[${call.pageId}].W`)];
    case "listComments":
      return [s(`${R}.block[${call.blockId}].comment[*].R`)];
    case "createComment":
      return [
        s(
          call.discussionId ? `${R}.block[${call.blockId}].comment[${call.discussionId}].W` : `${R}.block[${call.blockId}].comment.W`
        )
      ];
  }
}
function classifyNotion(tool, args, resources) {
  const undeclared = undeclaredArgument(tool, args);
  if (undeclared) return { denied: undeclared };
  const call = readCall(tool, args, resources);
  if ("denied" in call) return call;
  const slices = slicesOf(call, resources);
  if (slices.length === 0) return { denied: "list_roots: the mission selects no Notion root" };
  return { slices };
}

// ../../_temp/work/toolchain/plugins/notion/src/api.ts
var NOTION_API_BASE = "https://api.notion.com/v1";
var NOTION_VERSION = "2026-03-11";
function tokenOf(ctx) {
  const secret = expectCredentialKind(SERVICE_ID, ctx.credential, "api-key");
  const token = secret.fields[API_TOKEN_FIELD];
  if (!token) throw new Error(`${SERVICE_ID}: the credential has no '${API_TOKEN_FIELD}' field`);
  return token;
}
async function request(ctx, method, path, guard, options = {}) {
  const query = options.query && [...options.query].length > 0 ? `?${options.query.toString()}` : "";
  const seen = { retryAfter: null };
  const io = {
    fetch: async (...call) => {
      const res = await ctx.fetch(call[0], { ...call[1], redirect: "error" });
      seen.retryAfter = res.headers.get("retry-after");
      return res;
    },
    ...ctx.signal ? { signal: ctx.signal } : {}
  };
  try {
    return await httpJson(
      io,
      {
        url: `${NOTION_API_BASE}${path}${query}`,
        method,
        headers: { authorization: `Bearer ${tokenOf(ctx)}`, "notion-version": NOTION_VERSION },
        ...options.body !== void 0 ? { body: options.body } : {}
      },
      guard
    );
  } catch (err) {
    if (seen.retryAfter && err instanceof Error && !(err instanceof UpstreamProtocolError)) {
      err.message = `${err.message} (retry after ${seen.retryAfter} s)`;
    }
    throw err;
  }
}
async function readOrMissing(ctx, path, guard) {
  try {
    return await request(ctx, "GET", path, guard);
  } catch (err) {
    if (err instanceof UpstreamHttpError && err.status === 404) return null;
    throw err;
  }
}

// ../../_temp/work/toolchain/plugins/notion/src/credential.ts
var NOTION_ACCOUNTS_PAGE = "https://app.notion.com/developers/accounts";
async function verifyNotionToken(ctx) {
  const me = await request(ctx, "GET", "/users/me", anyJson);
  const bot = isRecord(me) && me.type === "bot" && isRecord(me.bot) ? me.bot : null;
  const owner = bot && isRecord(bot.owner) ? bot.owner : null;
  if (!bot || !owner || owner.type !== "workspace") {
    throw new CredentialRefusal(
      "Notion: this is not an internal account token. Paste the token of an internal account (Developer portal, Build, Internal accounts), not a personal access token.",
      401
    );
  }
  const name = typeof bot.workspace_name === "string" && bot.workspace_name.length > 0 ? bot.workspace_name : typeof bot.workspace_id === "string" ? bot.workspace_id : null;
  return { account: name, expiresAt: null };
}
var notionCredential = {
  kind: "api-key",
  label: "internal account token",
  createUrl: NOTION_ACCOUNTS_PAGE,
  fields: [
    {
      name: API_TOKEN_FIELD,
      label: "Internal account token",
      secret: true,
      required: true,
      placeholder: "ntn_\u2026",
      // Notion advises against validating its tokens with a pattern: bounded, no whitespace, nothing more.
      pattern: "^\\S{20,512}$",
      help: "The token of an internal account with every capability above, shared with every top-level page the agents may work in."
    }
  ],
  guide: {
    // The pages are shared before the paste, so the first discovery finds them.
    steps: [
      {
        do: "Open Notion's Developer portal and create an account in the workspace you want to connect (you must be a Workspace Owner); the internal account is the token, there is no app to install.",
        path: ["Build", "Internal accounts", "Create a new account"],
        url: NOTION_ACCOUNTS_PAGE
      },
      {
        do: "Tick every capability listed below, and choose No user information.",
        path: ["Configuration"]
      },
      {
        do: "Share every top-level page and database the agents may ever work in; sharing a page includes everything under it.",
        path: ["Content access", "Edit access"]
      },
      {
        do: "Share a page from Notion itself instead, if you prefer: open the page and add the account there.",
        path: ["\u2022\u2022\u2022", "Accounts", "Add account"]
      },
      { do: "Copy the token and paste it here.", path: ["Configuration"] }
    ],
    permissions: [
      {
        name: "Read content",
        access: "read",
        tools: [
          TOOL.listRoots,
          TOOL.searchContent,
          TOOL.getPage,
          TOOL.listBlockChildren,
          TOOL.getDatabase,
          TOOL.getDataSource,
          TOOL.queryDataSource
        ]
      },
      {
        name: "Insert content",
        access: "read-write",
        tools: [TOOL.createPage, TOOL.appendBlocks, TOOL.createEntry]
      },
      {
        name: "Update content",
        access: "read-write",
        tools: [
          TOOL.updatePage,
          TOOL.updateBlock,
          TOOL.deleteBlock,
          TOOL.trashPage,
          TOOL.restorePage,
          TOOL.updateEntry
        ]
      },
      { name: "Read comments", access: "read", tools: [TOOL.listComments] },
      { name: "Insert comments", access: "read-write", tools: [TOOL.createComment] }
    ],
    reach: {
      what: "Capabilities and shared pages",
      grant: "Every capability below, and every top-level page the agents may ever work in",
      why: "This gateway gives an agent only the pages and capabilities its mission names; a page not shared with the account is out of reach of every mission until you share it and refresh the account."
    },
    expiry: {
      kind: "none",
      reason: "Notion gives internal account tokens no expiry: delete the account in the Developer portal to end this account."
    },
    docsUrl: "https://developers.notion.com/guides/get-started/internal-accounts"
  },
  verify: verifyNotionToken
};

// ../../_temp/work/toolchain/plugins/notion/src/data-model.ts
var leaf = (name, parent, description) => ({
  name,
  parent,
  cardinalities: ["one"],
  description
});
var notionDataModel = {
  service: SERVICE_ID,
  planes: [
    {
      slug: "content",
      description: "The pages and databases shared with the account, their content, entries and comments.",
      entities: [
        {
          name: "root",
          parent: null,
          cardinalities: ["one"],
          description: "The resource : one top-level page or database shared with the account, and everything under it."
        },
        {
          name: "page",
          parent: "root",
          cardinalities: ["one", "unbounded"],
          description: "Any page under the root, the root page itself included."
        },
        leaf("subpage", "page", "Verb leaf : create a page under this page."),
        leaf("properties", "page", "Verb leaf : overwrite the page's title, icon or cover."),
        leaf("trash", "page", "Verb leaf : move the page, and everything under it, to the trash."),
        leaf("restore", "page", "Verb leaf : bring the page back from the trash."),
        {
          name: "block",
          parent: "root",
          cardinalities: ["one"],
          description: "Any block under the root (a page id is a block id too). A write on the block itself overwrites its content."
        },
        leaf("children", "block", "Verb leaf : append blocks under this block."),
        leaf("delete", "block", "Verb leaf : move the block to the trash."),
        {
          name: "comment",
          parent: "block",
          cardinalities: ["one", "unbounded"],
          description: "Comments on a block or a page ; identified by its discussion id for a reply, absent for a new discussion."
        },
        {
          name: "database",
          parent: "root",
          cardinalities: ["one"],
          description: "A database container under the root, or the root itself."
        },
        {
          name: "data-source",
          parent: "root",
          cardinalities: ["one", "unbounded"],
          description: "A data source (schema and entries) of a database under the root."
        },
        {
          name: "entry",
          parent: "data-source",
          cardinalities: ["one", "unbounded"],
          description: "An entry (row) of a data source ; absent for a creation."
        },
        leaf("root-trash", "root", "Verb leaf : the shared root page itself goes to the trash.")
      ]
    }
  ]
};

// ../../_temp/work/toolchain/plugins/notion/src/json.ts
function isResultList(value) {
  return isRecord(value) && isList(value.results);
}

// ../../_temp/work/toolchain/plugins/notion/src/parents.ts
var ENDPOINT = {
  page: "/pages",
  block: "/blocks",
  database: "/databases",
  data_source: "/data_sources"
};
var LABEL = {
  page: "page",
  block: "block",
  database: "database",
  data_source: "data source"
};
var KIND_OF = {
  page_id: "page",
  block_id: "block",
  database_id: "database",
  data_source_id: "data_source"
};
function parentRef(parent) {
  if (!isRecord(parent) || typeof parent.type !== "string") return { end: "unreadable" };
  if (parent.type === "workspace") return { end: "workspace" };
  if (parent.type === "agent_id") return { end: "agent" };
  const kind = KIND_OF[parent.type];
  if (!kind) return { end: "unreadable" };
  const id3 = notionId(parent[parent.type]);
  if (!id3) return { end: "unreadable" };
  if (kind !== "data_source" || parent.database_id === void 0) return { node: { kind, id: id3 } };
  const database = notionId(parent.database_id);
  return database ? { node: { kind, id: id3 }, database } : { end: "unreadable" };
}

// ../../_temp/work/toolchain/plugins/notion/src/discovery.ts
var MAX_SEARCH_PAGES = 20;
var MAX_DISCOVERED_ROOTS = 200;
function tooMany(message) {
  throw new Error(`${SERVICE_ID}: ${message}`);
}
function unexpected(message) {
  throw new UpstreamProtocolError(`Notion discovery: ${message}`);
}
function isSearchPage(value) {
  return isResultList(value) && typeof value.has_more === "boolean";
}
async function searchAll(ctx, value) {
  const found = [];
  let next = null;
  for (let page = 0; page < MAX_SEARCH_PAGES; page += 1) {
    const answer = await request(ctx, "POST", "/search", isSearchPage, {
      body: {
        filter: { property: "object", value },
        page_size: 100,
        ...next ? { start_cursor: next } : {}
      }
    });
    for (const result of answer.results) {
      if (!isRecord(result) || result.object !== value || !notionId(result.id)) {
        return unexpected(`unexpected ${value} in the search answer`);
      }
      if (result.in_trash !== true) found.push(result);
    }
    if (!answer.has_more) return found;
    next = cursor(answer.next_cursor) ?? unexpected("unexpected next_cursor in the search answer");
  }
  return tooMany(
    `search returned more than ${MAX_SEARCH_PAGES * 100} ${value === "page" ? "pages" : "data sources"}: share fewer top-level pages with the account`
  );
}
async function isTopLevel(ctx, parent, found) {
  const ref = parentRef(parent);
  if ("end" in ref) {
    if (ref.end === "workspace") return true;
    if (ref.end === "agent") return false;
    return unexpected("unexpected parent in the search answer");
  }
  const { kind, id: id3 } = ref.node;
  if (found.has(id3) || ref.database !== void 0 && found.has(ref.database)) return false;
  return await readOrMissing(ctx, `${ENDPOINT[kind]}/${id3}`, anyJson) === null;
}
function plainText(value) {
  if (!isList(value)) return "";
  return value.map((item) => isRecord(item) && typeof item.plain_text === "string" ? item.plain_text : "").join("").trim();
}
function pageTitle(page) {
  const properties = isRecord(page.properties) ? Object.values(page.properties) : [];
  const title2 = properties.find((p) => isRecord(p) && p.type === "title");
  return isRecord(title2) && plainText(title2.title) || "Untitled";
}
async function discoverNotionResources(ctx) {
  const pages = await searchAll(ctx, "page");
  const sources = await searchAll(ctx, "data_source");
  const databases = /* @__PURE__ */ new Map();
  for (const source of sources) {
    const parent = isRecord(source.parent) ? source.parent : {};
    const database = parent.type === "database_id" ? notionId(parent.database_id) : null;
    if (!database) return unexpected("unexpected data source parent (expected a database)");
    if (!databases.has(database)) {
      databases.set(database, { source, databaseParent: source.database_parent });
    }
  }
  const found = /* @__PURE__ */ new Set([
    ...pages.map((p) => notionId(p.id)),
    ...sources.map((s) => notionId(s.id)),
    ...databases.keys()
  ]);
  const roots = [];
  for (const page of pages) {
    if (await isTopLevel(ctx, page.parent, found)) {
      roots.push({
        service: SERVICE_ID,
        ref: notionId(page.id),
        displayName: pageTitle(page),
        metadata: { kind: "page" }
      });
    }
  }
  for (const [database, { source, databaseParent }] of databases) {
    const parent = databaseParent ?? await databaseParentOf(ctx, database);
    if (await isTopLevel(ctx, parent, found)) {
      roots.push({
        service: SERVICE_ID,
        ref: database,
        displayName: plainText(source.title) || "Untitled",
        metadata: { kind: "database" }
      });
    }
  }
  if (roots.length > MAX_DISCOVERED_ROOTS) {
    return tooMany(
      `more than ${MAX_DISCOVERED_ROOTS} top-level pages and databases are shared with the account`
    );
  }
  return roots;
}
async function databaseParentOf(ctx, database) {
  const answer = await request(ctx, "GET", `/databases/${database}`, isRecord);
  if (notionId(answer.id) !== database) return unexpected("unexpected database answer");
  return answer.parent;
}

// ../../_temp/work/toolchain/plugins/notion/src/ancestry.ts
var MAX_ANCESTRY_DEPTH = 16;
function above(kind, object) {
  const parent = parentRef(object.parent);
  if (!("node" in parent)) return { databases: [] };
  if (kind !== "data_source") {
    return { databases: parent.database ? [parent.database] : [], next: parent.node };
  }
  if (parent.node.kind !== "database") return { databases: [] };
  const database = parent.node.id;
  if (object.database_parent === void 0) return { databases: [], next: parent.node };
  const grand = parentRef(object.database_parent);
  return "node" in grand ? { databases: [database], next: grand.node } : { databases: [database] };
}
var Ancestry = class {
  constructor(ctx, root2) {
    this.ctx = ctx;
    this.root = root2;
    this.inside.add(root2);
  }
  ctx;
  root;
  inside = /* @__PURE__ */ new Set();
  outside = /* @__PURE__ */ new Set();
  requests = 0;
  /**
   * The object a call targets, read by its own `GET` : the first hop of its
   * walk. A failure is the service's answer to the agent's call, thrown.
   */
  async fetch(kind, id3) {
    this.requests += 1;
    const object = await request(this.ctx, "GET", `${ENDPOINT[kind]}/${id3}`, isRecord);
    if (notionId(object.id) !== id3) {
      throw new UpstreamProtocolError(
        `Notion GET ${ENDPOINT[kind]}/${id3}: the answer is not that ${LABEL[kind]}`
      );
    }
    return object;
  }
  /**
   * Proves `id` under the root, or declines the call. `first` is the
   * target's own answer, when read ; `budget`, when given, bounds the
   * requests and declines when it runs out (fail closed).
   */
  async prove(kind, id3, first, budget) {
    const verdict = await this.walk({ kind, id: id3 }, first, budget ?? null);
    if (verdict.verdict === "in") return;
    const where = `under the shared root '${this.root}' of this call`;
    throw new ExecutorRefusal(
      verdict.tooDeep ? `notion: ${LABEL[kind]} '${id3}' could not be shown to be ${where} within ${MAX_ANCESTRY_DEPTH} levels` : verdict.verdict === "unknown" ? `notion: ${LABEL[kind]} '${id3}' could not be shown to be ${where} within the requests this call may spend` : `notion: ${LABEL[kind]} '${id3}' is not ${where}`
    );
  }
  /** Whether `id` is under the root, within a budget of requests ; never declines. */
  async check(kind, id3, first, budget) {
    return (await this.walk({ kind, id: id3 }, first, budget)).verdict;
  }
  async walk(start, first, budget) {
    const visited = [];
    const met = [];
    const settle = (verdict) => {
      for (const id3 of met) (verdict === "in" ? this.inside : this.outside).add(id3);
      return { verdict };
    };
    let node = start;
    let object = first;
    for (; ; ) {
      if (this.inside.has(node.id)) return settle("in");
      if (this.outside.has(node.id) || visited.includes(node.id)) return settle("out");
      if (visited.length > MAX_ANCESTRY_DEPTH) return { verdict: "out", tooDeep: true };
      visited.push(node.id);
      met.push(node.id);
      if (!object) {
        if (budget) {
          if (budget.left <= 0) return { verdict: "unknown" };
          budget.left -= 1;
        }
        const path = `${ENDPOINT[node.kind]}/${node.id}`;
        this.requests += 1;
        const missingIsOut = visited.length > 1 || budget !== null;
        const answer = missingIsOut ? await readOrMissing(this.ctx, path, anyJson) : await request(this.ctx, "GET", path, anyJson);
        if (answer === null) return settle("out");
        object = isRecord(answer) ? answer : void 0;
      }
      if (!object || notionId(object.id) !== node.id) return settle("out");
      const step = above(node.kind, object);
      for (const database of step.databases) {
        if (this.inside.has(database)) return settle("in");
        met.push(database);
      }
      if (!step.next) return settle("out");
      node = step.next;
      object = void 0;
    }
  }
};

// ../../_temp/work/toolchain/plugins/notion/src/execute.ts
var MAX_SEARCH_VERIFY_REQUESTS = 25;
var MAX_BLOCKS_PER_CALL = 500;
var MAX_CHILD_REQUESTS = 20;
var MAX_REPLY_LOOKUP_PAGES = 5;
var MAX_REFERENCE_WALK_REQUESTS = 50;
var MAX_DELETE_SCAN_REQUESTS = 20;
var SILENT2 = { mode: "silent" };
function paging(pageSize2, startCursor2) {
  return { page_size: pageSize2, ...startCursor2 ? { start_cursor: startCursor2 } : {} };
}
function pagingQuery(pageSize2, startCursor2) {
  const query = new URLSearchParams({ page_size: String(pageSize2) });
  if (startCursor2) query.set("start_cursor", startCursor2);
  return query;
}
function commentQuery(blockId, pageSize2, startCursor2) {
  const query = new URLSearchParams({ block_id: blockId });
  for (const [key, value] of pagingQuery(pageSize2, startCursor2)) query.set(key, value);
  return query;
}
function given(fields) {
  return Object.fromEntries(
    Object.entries(fields).filter(([, value]) => value !== void 0 && value !== null)
  );
}
function titleProperty(title2) {
  return { title: { title: [{ type: "text", text: { content: title2 } }] } };
}
function executeNotion(ctx, tool, args) {
  return declining(async () => {
    const undeclared = undeclaredArgument(tool, args);
    if (undeclared) return refusalResult(undeclared);
    const call = readCall(tool, args, ctx.resources);
    if ("denied" in call) return refusalResult(call.denied);
    if (call.op === "listRoots") return jsonResult({ roots: rootsOf(ctx.resources) });
    const walk = new Ancestry(ctx, call.root.ref);
    return jsonResult(await run(ctx, walk, call));
  });
}
function rootsOf(resources) {
  return resources.filter((r) => r.service === SERVICE_ID).map((r) => ({
    id: notionId(r.ref),
    title: r.displayName,
    kind: typeof r.metadata?.kind === "string" ? r.metadata.kind : null
  }));
}
async function run(ctx, walk, call) {
  switch (call.op) {
    case "searchContent":
      return search(ctx, walk, call);
    case "getPage": {
      const page = await walk.fetch("page", call.pageId);
      await walk.prove("page", call.pageId, page);
      return page;
    }
    case "getDatabase": {
      const database = await walk.fetch("database", call.databaseId);
      await walk.prove("database", call.databaseId, database);
      return database;
    }
    case "getDataSource": {
      const source = await walk.fetch("data_source", call.dataSourceId);
      await walk.prove("data_source", call.dataSourceId, source);
      return source;
    }
    case "listBlockChildren":
      return listChildren(ctx, walk, call);
    case "queryDataSource":
      await walk.prove("data_source", call.dataSourceId);
      return request(ctx, "POST", `/data_sources/${call.dataSourceId}/query`, anyJson, {
        body: {
          ...given({ filter: call.filter, sorts: call.sorts }),
          ...paging(call.pageSize, call.startCursor),
          result_type: "page"
        }
      });
    case "createPage":
      await walk.prove("page", call.parentPageId);
      await proveReferences(walk, call.references);
      return request(ctx, "POST", "/pages", anyJson, {
        body: {
          parent: { type: "page_id", page_id: call.parentPageId },
          properties: titleProperty(call.title),
          ...given({ children: call.children, icon: call.icon, cover: call.cover }),
          notifications: SILENT2
        }
      });
    case "updatePage": {
      const page = await walk.fetch("page", call.pageId);
      await walk.prove("page", call.pageId, page);
      const parent = isRecord(page.parent) ? page.parent.type : void 0;
      if (parent === "data_source_id" || parent === "database_id") {
        throw new ExecutorRefusal(
          `notion: page '${call.pageId}' is an entry of a database \u2014 change it with ${TOOL.updateEntry}`
        );
      }
      return request(ctx, "PATCH", `/pages/${call.pageId}`, anyJson, {
        body: {
          ...call.title !== null ? { properties: titleProperty(call.title) } : {},
          ...given({ icon: call.icon, cover: call.cover }),
          notifications: SILENT2
        }
      });
    }
    case "appendBlocks": {
      await proveBlockAndOriginal(walk, call.blockId);
      if (call.position.type === "after_block")
        await walk.prove("block", call.position.afterBlockId);
      await proveReferences(walk, call.references);
      const position = call.position.type === "end" ? {} : call.position.type === "start" ? { position: { type: "start" } } : {
        position: { type: "after_block", after_block: { id: call.position.afterBlockId } }
      };
      return request(ctx, "PATCH", `/blocks/${call.blockId}/children`, anyJson, {
        body: { children: call.children, ...position, notifications: SILENT2 }
      });
    }
    case "updateBlock": {
      const block = await walk.fetch("block", call.blockId);
      await walk.prove("block", call.blockId, block);
      if (block.type !== call.type) {
        throw new ExecutorRefusal(
          `notion: block '${call.blockId}' is a '${String(block.type)}', not a '${call.type}' \u2014 give its own type`
        );
      }
      await proveReferences(walk, call.references);
      return request(ctx, "PATCH", `/blocks/${call.blockId}`, anyJson, {
        body: { [call.type]: call.content }
      });
    }
    case "deleteBlock": {
      const block = await walk.fetch("block", call.blockId);
      await walk.prove("block", call.blockId, block);
      if (typeof block.type === "string" && CONTAINER_BLOCK_TYPES.has(block.type)) {
        throw new ExecutorRefusal(
          block.type === "child_page" ? `notion: block '${call.blockId}' is a page \u2014 move it to the trash with ${TOOL.trashPage}` : `notion: block '${call.blockId}' is a database, which this plugin does not delete`
        );
      }
      if (block.has_children !== false && syncedOriginOf(block) === null) {
        await refuseNestedContainers(ctx, call.blockId);
      }
      return request(ctx, "DELETE", `/blocks/${call.blockId}`, anyJson);
    }
    case "trashPage":
    case "restorePage": {
      const page = await walk.fetch("page", call.pageId);
      await walk.prove("page", call.pageId, page);
      return request(ctx, "PATCH", `/pages/${call.pageId}`, anyJson, {
        body: { in_trash: call.op === "trashPage", notifications: SILENT2 }
      });
    }
    case "createEntry":
      await walk.prove("data_source", call.dataSourceId);
      await proveReferences(walk, call.references);
      return request(ctx, "POST", "/pages", anyJson, {
        body: {
          parent: { type: "data_source_id", data_source_id: call.dataSourceId },
          properties: call.properties,
          ...given({ children: call.children, icon: call.icon }),
          notifications: SILENT2
        }
      });
    case "updateEntry": {
      const page = await walk.fetch("page", call.pageId);
      await walk.prove("page", call.pageId, page);
      const parent = isRecord(page.parent) ? page.parent : {};
      if (parent.type !== "data_source_id" || notionId(parent.data_source_id) !== call.dataSourceId) {
        throw new ExecutorRefusal(
          `notion: page '${call.pageId}' is not an entry of the data source '${call.dataSourceId}'`
        );
      }
      await proveReferences(walk, call.references);
      return request(ctx, "PATCH", `/pages/${call.pageId}`, anyJson, {
        body: { properties: call.properties, ...given({ icon: call.icon }), notifications: SILENT2 }
      });
    }
    case "listComments":
      await walk.prove("block", call.blockId);
      return request(ctx, "GET", "/comments", anyJson, {
        query: commentQuery(call.blockId, call.pageSize, call.startCursor)
      });
    case "createComment":
      return comment(ctx, walk, call);
  }
}
async function proveReferences(walk, references) {
  const budget = { left: MAX_REFERENCE_WALK_REQUESTS };
  for (const id3 of references.pages) await walk.prove("page", id3, void 0, budget);
  for (const id3 of references.databases) await walk.prove("database", id3, void 0, budget);
}
async function refuseNestedContainers(ctx, blockId) {
  const queue = [blockId];
  let listings = 0;
  while (queue.length > 0) {
    const parent = queue.shift();
    let startCursor2 = null;
    do {
      if (listings >= MAX_DELETE_SCAN_REQUESTS) {
        throw new ExecutorRefusal(
          `notion: block '${blockId}' holds more nested content than one call checks (${MAX_DELETE_SCAN_REQUESTS} listings) \u2014 delete its parts one by one`
        );
      }
      listings += 1;
      const listed = await request(
        ctx,
        "GET",
        `/blocks/${parent}/children`,
        isResultList,
        {
          query: pagingQuery(100, startCursor2)
        }
      );
      for (const child2 of listed.results) {
        const id3 = isRecord(child2) ? notionId(child2.id) : null;
        if (!isRecord(child2) || !id3) {
          throw new UpstreamProtocolError("Notion: unexpected block in a block list");
        }
        if (typeof child2.type === "string" && CONTAINER_BLOCK_TYPES.has(child2.type)) {
          throw new ExecutorRefusal(
            `notion: block '${blockId}' contains ${child2.type === "child_page" ? "a page" : "a database"} ('${id3}'), which deleting it would trash \u2014 move the page to the trash with ${TOOL.trashPage}, or delete the other blocks one by one`
          );
        }
        if (child2.has_children !== false && syncedOriginOf(child2) === null) queue.push(id3);
      }
      startCursor2 = listed.has_more === true ? cursor(listed.next_cursor) : null;
      if (listed.has_more === true && !startCursor2) {
        throw new UpstreamProtocolError("Notion: unexpected next_cursor in a block list");
      }
    } while (startCursor2);
  }
}
function syncedOriginOf(block) {
  if (block.type !== "synced_block" || !isRecord(block.synced_block)) return null;
  const from = block.synced_block.synced_from;
  if (from === null || from === void 0) return null;
  const original = isRecord(from) ? notionId(from.block_id) : null;
  return original ? { original } : { unreadable: true };
}
async function proveBlockAndOriginal(walk, blockId) {
  const block = await walk.fetch("block", blockId);
  await walk.prove("block", blockId, block);
  const origin = syncedOriginOf(block);
  if (origin && "unreadable" in origin) {
    throw new ExecutorRefusal(
      `notion: block '${blockId}' is a synced copy whose original cannot be read`
    );
  }
  if (origin) await walk.prove("block", origin.original);
  return block;
}
async function search(ctx, walk, call) {
  const answer = await request(ctx, "POST", "/search", isResultList, {
    body: {
      ...given({ query: call.query, sort: call.sort }),
      ...call.object ? { filter: { property: "object", value: call.object } } : {},
      ...paging(call.pageSize, call.startCursor)
    }
  });
  const budget = { left: MAX_SEARCH_VERIFY_REQUESTS };
  const shown = [];
  for (const result of answer.results) {
    const kind = isRecord(result) ? result.object === "page" ? "page" : result.object === "data_source" ? "data_source" : null : null;
    const id3 = isRecord(result) ? notionId(result.id) : null;
    if (!kind || !id3 || !isRecord(result)) continue;
    if (await walk.check(kind, id3, result, budget) === "in") shown.push(result);
  }
  return {
    results: shown,
    next_cursor: answer.next_cursor ?? null,
    has_more: answer.has_more ?? false,
    ...answer.request_status !== void 0 ? { request_status: answer.request_status } : {}
  };
}
async function listChildren(ctx, walk, call) {
  await proveBlockAndOriginal(walk, call.blockId);
  const first = await request(ctx, "GET", `/blocks/${call.blockId}/children`, isResultList, {
    query: pagingQuery(call.pageSize, call.startCursor)
  });
  if (call.depth === 1) return first;
  const state = {
    budget: { left: MAX_CHILD_REQUESTS },
    blocks: first.results.length,
    notExpanded: []
  };
  const results = await expand(ctx, walk, first.results, call.depth - 1, state);
  return {
    ...first,
    results,
    ...state.notExpanded.length > 0 ? { not_expanded: state.notExpanded } : {}
  };
}
async function expand(ctx, walk, blocks, levels, state) {
  const out = [];
  for (const block of blocks) {
    if (!isRecord(block) || block.has_children !== true || levels <= 0) {
      out.push(block);
      continue;
    }
    const id3 = notionId(block.id);
    const why = await whyNotExpanded(walk, block, id3, state);
    if (why || !id3) {
      state.notExpanded.push({ id: String(block.id), reason: why ?? "malformed id" });
      out.push(block);
      continue;
    }
    state.budget.left -= 1;
    const listed = await request(ctx, "GET", `/blocks/${id3}/children`, isResultList, {
      query: pagingQuery(100, null)
    });
    const room = MAX_BLOCKS_PER_CALL - state.blocks;
    const kept = listed.results.slice(0, Math.max(0, room));
    state.blocks += kept.length;
    const nested = await expand(ctx, walk, kept, levels - 1, state);
    out.push({
      ...block,
      children: nested,
      ...listed.has_more === true || kept.length < listed.results.length ? { children_has_more: true } : {}
    });
  }
  return out;
}
async function whyNotExpanded(walk, block, id3, state) {
  if (!id3) return "malformed id";
  if (typeof block.type === "string" && CONTAINER_BLOCK_TYPES.has(block.type)) {
    return "a sub-page or a database: read it with its own call";
  }
  if (state.budget.left <= 0) return `more than ${MAX_CHILD_REQUESTS} requests in one call`;
  if (state.blocks >= MAX_BLOCKS_PER_CALL)
    return `more than ${MAX_BLOCKS_PER_CALL} blocks in one call`;
  const origin = syncedOriginOf(block);
  if (origin && "unreadable" in origin) return "a synced copy whose original cannot be read";
  if (!origin) return null;
  const verdict = await walk.check("block", origin.original, void 0, state.budget);
  if (verdict === "out") return "a synced copy whose original is not under this root";
  if (verdict === "unknown") return `more than ${MAX_CHILD_REQUESTS} requests in one call`;
  return state.budget.left <= 0 ? `more than ${MAX_CHILD_REQUESTS} requests in one call` : null;
}
async function comment(ctx, walk, call) {
  const target = await walk.fetch("block", call.blockId);
  await walk.prove("block", call.blockId, target);
  await proveReferences(walk, call.references);
  if (call.discussionId) {
    await requireOpenDiscussion(ctx, call.blockId, call.discussionId);
    return request(ctx, "POST", "/comments", anyJson, {
      body: { discussion_id: call.discussionId, rich_text: call.richText }
    });
  }
  const parent = target.type === "child_page" ? { page_id: call.blockId } : { block_id: call.blockId };
  return request(ctx, "POST", "/comments", anyJson, { body: { parent, rich_text: call.richText } });
}
async function requireOpenDiscussion(ctx, blockId, discussionId) {
  let startCursor2 = null;
  for (let page = 0; page < MAX_REPLY_LOOKUP_PAGES; page += 1) {
    const query = commentQuery(blockId, 100, startCursor2);
    const listed = await request(ctx, "GET", "/comments", isResultList, { query });
    if (listed.results.some((c) => isRecord(c) && notionId(c.discussion_id) === discussionId))
      return;
    const next = cursor(listed.next_cursor);
    if (listed.has_more !== true || !next) break;
    startCursor2 = next;
  }
  throw new ExecutorRefusal(
    `notion: discussion '${discussionId}' is not an open discussion of '${blockId}'`
  );
}

// ../../_temp/work/toolchain/plugins/notion/src/examples.ts
var id2 = (digit) => `${digit.repeat(8)}-${digit.repeat(4)}-4${digit.repeat(3)}-8${digit.repeat(3)}-${digit.repeat(12)}`;
var ROOT = id2("1");
var PAGE = id2("2");
var BLOCK = id2("4");
var DB = id2("5");
var DS = id2("6");
var ENTRY = id2("7");
var OTHER_ROOT = id2("8");
var DISCUSSION = id2("a");
var EXAMPLE_PAGE_ROOT = {
  service: SERVICE_ID,
  ref: ROOT,
  displayName: "Handbook",
  metadata: { kind: "page" }
};
var EXAMPLE_DB_ROOT = {
  service: SERVICE_ID,
  ref: DB,
  displayName: "Tasks",
  metadata: { kind: "database" }
};
var text = (content) => [{ type: "text", text: { content } }];
var notionExamples = samplesOn([EXAMPLE_PAGE_ROOT], {
  [TOOL.listRoots]: [{ args: {}, resources: [EXAMPLE_PAGE_ROOT, EXAMPLE_DB_ROOT] }],
  [TOOL.searchContent]: [
    { args: { root: ROOT, query: "roadmap", object: "page" } },
    { args: { query: "roadmap" } },
    { args: { root: OTHER_ROOT, query: "roadmap" }, expectDenied: true }
  ],
  [TOOL.getPage]: [{ args: { root: ROOT, page_id: PAGE } }],
  [TOOL.listBlockChildren]: [{ args: { root: ROOT, block_id: PAGE, depth: 2 } }],
  [TOOL.getDatabase]: [{ args: { root: DB, database_id: DB }, resources: [EXAMPLE_DB_ROOT] }],
  [TOOL.getDataSource]: [{ args: { root: DB, data_source_id: DS }, resources: [EXAMPLE_DB_ROOT] }],
  [TOOL.queryDataSource]: [
    { args: { root: DB, data_source_id: DS, page_size: 10 }, resources: [EXAMPLE_DB_ROOT] }
  ],
  [TOOL.createPage]: [{ args: { root: ROOT, parent_page_id: PAGE, title: "Weekly plan" } }],
  [TOOL.updatePage]: [{ args: { root: ROOT, page_id: PAGE, title: "Renamed plan" } }],
  [TOOL.appendBlocks]: [
    {
      args: {
        root: ROOT,
        block_id: PAGE,
        children: [{ type: "paragraph", paragraph: { rich_text: text("Hello") } }],
        position: "start"
      }
    }
  ],
  [TOOL.updateBlock]: [
    {
      args: {
        root: ROOT,
        block_id: BLOCK,
        type: "paragraph",
        content: { rich_text: text("Rewritten") }
      }
    },
    { args: { root: ROOT, block_id: ROOT, type: "paragraph", content: {} }, expectDenied: true }
  ],
  [TOOL.deleteBlock]: [{ args: { root: ROOT, block_id: BLOCK } }],
  [TOOL.trashPage]: [
    { args: { root: ROOT, page_id: PAGE } },
    // The root page itself : `page-trash` and `root-trash`.
    { args: { root: ROOT, page_id: ROOT } }
  ],
  [TOOL.restorePage]: [{ args: { root: ROOT, page_id: PAGE } }],
  [TOOL.createEntry]: [
    {
      args: { root: DB, data_source_id: DS, properties: { Name: { title: text("Task") } } },
      resources: [EXAMPLE_DB_ROOT]
    }
  ],
  [TOOL.updateEntry]: [
    {
      args: {
        root: DB,
        data_source_id: DS,
        page_id: ENTRY,
        properties: { Status: { status: { name: "Done" } } }
      },
      resources: [EXAMPLE_DB_ROOT]
    }
  ],
  [TOOL.listComments]: [{ args: { root: ROOT, block_id: PAGE } }],
  [TOOL.createComment]: [
    { args: { root: ROOT, block_id: PAGE, rich_text: text("Looks good") } },
    { args: { root: ROOT, block_id: PAGE, rich_text: text("Agreed"), discussion_id: DISCUSSION } }
  ]
});

// ../../_temp/work/toolchain/plugins/notion/src/icon.ts
var NOTION_ICON = "M4.459 4.208c.746.606 1.026.56 2.428.466l13.215-.793c.28 0 .047-.28-.046-.326L17.86 1.968c-.42-.326-.981-.7-2.055-.607L3.01 2.295c-.466.046-.56.28-.374.466zm.793 3.08v13.904c0 .747.373 1.027 1.214.98l14.523-.84c.841-.046.935-.56.935-1.167V6.354c0-.606-.233-.933-.748-.887l-15.177.887c-.56.047-.747.327-.747.933zm14.337.745c.093.42 0 .84-.42.888l-.7.14v10.264c-.608.327-1.168.514-1.635.514-.748 0-.935-.234-1.495-.933l-4.577-7.186v6.952L12.21 19s0 .84-1.168.84l-3.222.186c-.093-.186 0-.653.327-.746l.84-.233V9.854L7.822 9.76c-.094-.42.14-1.026.793-1.073l3.456-.233 4.764 7.279v-6.44l-1.215-.139c-.093-.514.28-.887.747-.933zM1.936 1.035l13.31-.98c1.634-.14 2.055-.047 3.082.7l4.249 2.986c.7.513.934.653.934 1.213v16.378c0 1.026-.373 1.634-1.68 1.726l-15.458.934c-.98.047-1.448-.093-1.962-.747l-3.129-4.06c-.56-.747-.793-1.306-.793-1.96V2.667c0-.839.374-1.54 1.447-1.632z";
var NOTION_ICON_COLOR = "#000000";

// ../../_temp/work/toolchain/plugins/notion/src/index.ts
var notionCatalog = loadCatalogFile(catalogPathNextTo(import.meta.url));
var notionPlugin = definePlugin({
  id: SERVICE_ID,
  displayName: "Notion",
  icon: NOTION_ICON,
  iconColor: NOTION_ICON_COLOR,
  resourceNoun: { one: "page or database", other: "pages and databases" },
  // Always equal to `version` in this plugin's package.json (a test checks it).
  version: "0.2.0",
  description: "Read and edit the pages, page content, databases and comments of the Notion pages shared with an internal account.",
  summary: "One account is one internal account of a Notion workspace, connected with its token. One resource is one top-level page or database shared with that account, with everything under it. Notion has no environments: moving a page to the trash and deleting a block are permissions of their own. Writes are sent silently, so Notion notifies nobody.",
  manualRevocation: "In Notion's Developer portal, open the account and refresh its token on the Configuration tab, or remove the account from the shared pages (\u2022\u2022\u2022 menu, Accounts).",
  docsUrl: "https://github.com/vaubaan/gateway/blob/main/docs/handbook/services/notion.md",
  tools: notionTools,
  toolTitles: notionToolTitles,
  examples: notionExamples,
  dataModel: notionDataModel,
  catalog: notionCatalog.catalog,
  credential: notionCredential,
  classify: classifyNotion,
  // No environment : no `envOf` hook, no env-scoped risk.
  execute: executeNotion,
  discoverResources: discoverNotionResources
});
var index_default = notionPlugin;
export {
  API_TOKEN_FIELD,
  EXAMPLE_DB_ROOT,
  EXAMPLE_PAGE_ROOT,
  MAX_ANCESTRY_DEPTH,
  MAX_BLOCKS_PER_CALL,
  MAX_CHILD_REQUESTS,
  MAX_DISCOVERED_ROOTS,
  MAX_REPLY_LOOKUP_PAGES,
  MAX_SEARCH_PAGES,
  MAX_SEARCH_VERIFY_REQUESTS,
  NOTION_ACCOUNTS_PAGE,
  NOTION_API_BASE,
  NOTION_VERSION,
  SERVICE_ID,
  TOOL,
  classifyNotion,
  index_default as default,
  discoverNotionResources,
  executeNotion,
  notionCatalog,
  notionDataModel,
  notionExamples,
  notionId,
  notionPlugin,
  notionTools,
  readCall,
  slicesOf,
  undeclaredArgument,
  verifyNotionToken
};
/*! Bundled license information:

js-yaml/dist/js-yaml.mjs:
  (*! js-yaml 5.5.0 https://github.com/nodeca/js-yaml @license MIT *)
*/
